-- -------------------------------------------~
SET SQL_QUOTE_SHOW_CREATE = 1~
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0~
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0~
-- -------------------------------------------~
-- -------------------------------------------~
-- START BACKUP~
-- -------------------------------------------~
-- -------------------------------------------~
-- TABLE `action`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `action`~
CREATE TABLE IF NOT EXISTS `action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `comment` text,
  `subject` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `degree_program`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `degree_program`~
CREATE TABLE IF NOT EXISTS `degree_program` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `degreeName` varchar(255) NOT NULL,
  `shortName` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `friendship`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `friendship`~
CREATE TABLE IF NOT EXISTS `friendship` (
  `inviter_id` int(11) NOT NULL,
  `friend_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `acknowledgetime` int(11) DEFAULT NULL,
  `requesttime` int(11) DEFAULT NULL,
  `updatetime` int(11) DEFAULT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`inviter_id`,`friend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `membership`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `membership`~
CREATE TABLE IF NOT EXISTS `membership` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `order_date` int(11) NOT NULL,
  `end_date` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `payment_date` int(11) DEFAULT NULL,
  `subscribed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `message`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `message`~
CREATE TABLE IF NOT EXISTS `message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(10) unsigned NOT NULL,
  `from_user_id` int(10) unsigned NOT NULL,
  `to_user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text,
  `message_read` tinyint(1) NOT NULL,
  `answered` tinyint(1) DEFAULT NULL,
  `draft` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `payment`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `payment`~
CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `permission`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `permission`~
CREATE TABLE IF NOT EXISTS `permission` (
  `principal_id` int(11) NOT NULL,
  `subordinate_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('user','role') NOT NULL,
  `action` int(11) NOT NULL,
  `template` tinyint(1) NOT NULL,
  `comment` text,
  PRIMARY KEY (`principal_id`,`subordinate_id`,`type`,`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `privacysetting`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `privacysetting`~
CREATE TABLE IF NOT EXISTS `privacysetting` (
  `user_id` int(10) unsigned NOT NULL,
  `message_new_friendship` tinyint(1) NOT NULL DEFAULT '1',
  `message_new_message` tinyint(1) NOT NULL DEFAULT '1',
  `message_new_profilecomment` tinyint(1) NOT NULL DEFAULT '1',
  `appear_in_search` tinyint(1) NOT NULL DEFAULT '1',
  `show_online_status` tinyint(1) NOT NULL DEFAULT '1',
  `log_profile_visits` tinyint(1) NOT NULL DEFAULT '1',
  `ignore_users` varchar(255) DEFAULT NULL,
  `public_profile_fields` bigint(15) unsigned DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `profile`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `profile`~
CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `privacy` enum('protected','private','public') NOT NULL DEFAULT 'protected',
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `show_friends` tinyint(1) DEFAULT '1',
  `allow_comments` tinyint(1) DEFAULT '1',
  `email` varchar(255) DEFAULT '',
  `regno` varchar(45) DEFAULT '',
  `year_of_study` int(11) NOT NULL DEFAULT '0',
  `middle_name` varchar(45) DEFAULT '',
  `staff_id` varchar(45) DEFAULT '',
  `phone` varchar(45) DEFAULT '',
  `degreeID` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `profile_comment`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `profile_comment`~
CREATE TABLE IF NOT EXISTS `profile_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `profile_field`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `profile_field`~
CREATE TABLE IF NOT EXISTS `profile_field` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `hint` text NOT NULL,
  `field_type` varchar(50) NOT NULL DEFAULT '',
  `field_size` int(3) NOT NULL DEFAULT '0',
  `field_size_min` int(3) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(255) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  `related_field_name` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `profile_visit`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `profile_visit`~
CREATE TABLE IF NOT EXISTS `profile_visit` (
  `visitor_id` int(11) NOT NULL,
  `visited_id` int(11) NOT NULL,
  `timestamp_first_visit` int(11) NOT NULL,
  `timestamp_last_visit` int(11) NOT NULL,
  `num_of_visits` int(11) NOT NULL,
  PRIMARY KEY (`visitor_id`,`visited_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_announcement`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_announcement`~
CREATE TABLE IF NOT EXISTS `pt_announcement` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `timePosted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_application`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_application`~
CREATE TABLE IF NOT EXISTS `pt_application` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `registrationNo` varchar(45) NOT NULL,
  `companyID` int(5) NOT NULL,
  `ptType` tinyint(2) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'this shows the status of the application 1 for active or recent and 0 for inactive or past',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_arrival_note`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_arrival_note`~
CREATE TABLE IF NOT EXISTS `pt_arrival_note` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `registrationNo` varchar(45) NOT NULL,
  `documentName` varchar(100) NOT NULL,
  `submissionTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL DEFAULT 'Active',
  `ptType` tinyint(2) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_arrival_note2`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_arrival_note2`~
CREATE TABLE IF NOT EXISTS `pt_arrival_note2` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `registrationNo` varchar(45) DEFAULT NULL,
  `ptStartDate` date DEFAULT NULL,
  `submissionDate` date DEFAULT NULL,
  `studentPosition` varchar(100) DEFAULT NULL,
  `workingHours` int(5) NOT NULL,
  `workingDays` int(5) NOT NULL,
  `companyID` int(5) DEFAULT NULL,
  `trainerName` varchar(45) DEFAULT NULL,
  `trainerPosition` varchar(45) DEFAULT NULL,
  `trainerEmail` varchar(50) NOT NULL,
  `trainerPhoneNumber` varchar(45) DEFAULT NULL,
  `ptType` int(2) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_company`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_company`~
CREATE TABLE IF NOT EXISTS `pt_company` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `companyName` varchar(255) NOT NULL,
  `region` int(5) NOT NULL,
  `district` int(5) NOT NULL,
  `locationDescr` varchar(255) NOT NULL,
  `vacancy` int(5) NOT NULL,
  `phoneNumber` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_contact_person`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_contact_person`~
CREATE TABLE IF NOT EXISTS `pt_contact_person` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `companyID` int(5) NOT NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `phoneNumber` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_coordinator`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_coordinator`~
CREATE TABLE IF NOT EXISTS `pt_coordinator` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `staffID` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_districts`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_districts`~
CREATE TABLE IF NOT EXISTS `pt_districts` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `regionID` int(11) NOT NULL,
  `district` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_documents`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_documents`~
CREATE TABLE IF NOT EXISTS `pt_documents` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `registrationNo` varchar(45) NOT NULL,
  `documentName` varchar(100) NOT NULL,
  `submissionTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comments` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_regions`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_regions`~
CREATE TABLE IF NOT EXISTS `pt_regions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `region` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_remarks`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_remarks`~
CREATE TABLE IF NOT EXISTS `pt_remarks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `companyID` int(5) NOT NULL,
  `project_activities` varchar(255) NOT NULL,
  `studentRemarks` text NOT NULL,
  `companyRemarks` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_selection`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_selection`~
CREATE TABLE IF NOT EXISTS `pt_selection` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `registrationID` varchar(45) NOT NULL,
  `region` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_status`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_status`~
CREATE TABLE IF NOT EXISTS `pt_status` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `registrationNo` varchar(45) NOT NULL,
  `companyID` varchar(255) NOT NULL,
  `supervisorID` varchar(45) DEFAULT NULL,
  `ptType` tinyint(2) NOT NULL,
  `status` varchar(15) NOT NULL,
  `pStatus` varchar(50) NOT NULL DEFAULT 'Not yet supervised',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_summary`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_summary`~
CREATE TABLE IF NOT EXISTS `pt_summary` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `registrationNo` varchar(50) NOT NULL,
  `supervisorID` int(5) NOT NULL,
  `officerMarks` float NOT NULL,
  `logbookMarks` float NOT NULL,
  `supervisorMarks` float NOT NULL,
  `reportMarks` float NOT NULL,
  `totalMarks` float NOT NULL,
  `ptReportTitle` varchar(255) NOT NULL,
  `studentRemarks` text NOT NULL,
  `dateVisited` date NOT NULL,
  `ptType` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `pt_supervisor`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `pt_supervisor`~
CREATE TABLE IF NOT EXISTS `pt_supervisor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `staffID` int(11) NOT NULL,
  `supervisionRegion` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `role`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `role`~
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `membership_priority` int(11) DEFAULT NULL,
  `price` double DEFAULT NULL COMMENT 'Price (when using membership module)',
  `duration` int(11) DEFAULT NULL COMMENT 'How long a membership is valid',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `subsystem`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `subsystem`~
CREATE TABLE IF NOT EXISTS `subsystem` (
  `subsystemID` int(11) NOT NULL AUTO_INCREMENT,
  `subsysName` varchar(45) NOT NULL,
  `url` varchar(255) NOT NULL,
  `iconUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`subsystemID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `tbl_database_autobackup`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `tbl_database_autobackup`~
CREATE TABLE IF NOT EXISTS `tbl_database_autobackup` (
  `backupId` int(11) NOT NULL AUTO_INCREMENT,
  `backupDate` date NOT NULL,
  `dbName` varchar(200) NOT NULL,
  `dbSize` varchar(200) NOT NULL,
  PRIMARY KEY (`backupId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `tbl_menu`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `tbl_menu`~
CREATE TABLE IF NOT EXISTS `tbl_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `link` varchar(200) NOT NULL,
  `title` varchar(500) NOT NULL,
  `body` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1~

-- -------------------------------------------~
-- TABLE `translation`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `translation`~
CREATE TABLE IF NOT EXISTS `translation` (
  `message` varbinary(255) NOT NULL,
  `translation` varchar(255) NOT NULL,
  `language` varchar(5) NOT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`message`,`language`,`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `user`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `user`~
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `salt` varchar(128) NOT NULL,
  `activationKey` varchar(128) NOT NULL DEFAULT '',
  `createtime` int(11) NOT NULL DEFAULT '0',
  `lastvisit` int(11) NOT NULL DEFAULT '0',
  `lastaction` int(11) NOT NULL DEFAULT '0',
  `lastpasswordchange` int(11) NOT NULL DEFAULT '0',
  `failedloginattempts` int(11) NOT NULL DEFAULT '0',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `student` tinyint(1) NOT NULL DEFAULT '0',
  `staff` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `notifyType` enum('None','Digest','Instant','Threshold') DEFAULT 'Instant',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `user_group_message`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `user_group_message`~
CREATE TABLE IF NOT EXISTS `user_group_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `author_id` int(11) unsigned NOT NULL,
  `group_id` int(11) unsigned NOT NULL,
  `createtime` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `user_role`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `user_role`~
CREATE TABLE IF NOT EXISTS `user_role` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `usergroup`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `usergroup`~
CREATE TABLE IF NOT EXISTS `usergroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) NOT NULL,
  `participants` text,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE `usergroup_role`~
-- -------------------------------------------~
DROP TABLE IF EXISTS `usergroup_role`~
CREATE TABLE IF NOT EXISTS `usergroup_role` (
  `usergroup_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`usergroup_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8~

-- -------------------------------------------~
-- TABLE DATA action~
-- -------------------------------------------~
INSERT INTO `action` (`id`,`title`,`comment`,`subject`) VALUES
('1','message_write','','')~
INSERT INTO `action` (`id`,`title`,`comment`,`subject`) VALUES
('2','message_receive','','')~
INSERT INTO `action` (`id`,`title`,`comment`,`subject`) VALUES
('3','user_create','','')~
INSERT INTO `action` (`id`,`title`,`comment`,`subject`) VALUES
('4','user_update','','')~
INSERT INTO `action` (`id`,`title`,`comment`,`subject`) VALUES
('5','user_remove','','')~
INSERT INTO `action` (`id`,`title`,`comment`,`subject`) VALUES
('6','user_admin','','')~



-- -------------------------------------------~
-- TABLE DATA degree_program~
-- -------------------------------------------~
INSERT INTO `degree_program` (`id`,`degreeName`,`shortName`) VALUES
('1','Bsc Telecommunication Engineering','TE')~
INSERT INTO `degree_program` (`id`,`degreeName`,`shortName`) VALUES
('2','Bsc Electronics science and Communication','ESC')~
INSERT INTO `degree_program` (`id`,`degreeName`,`shortName`) VALUES
('3','Bsc Computer Engineering & IT','CIT')~
INSERT INTO `degree_program` (`id`,`degreeName`,`shortName`) VALUES
('4','Bsc Computer Science','CS')~



-- -------------------------------------------~
-- TABLE DATA payment~
-- -------------------------------------------~
INSERT INTO `payment` (`id`,`title`,`text`) VALUES
('1','Prepayment','')~
INSERT INTO `payment` (`id`,`title`,`text`) VALUES
('2','Paypal','')~



-- -------------------------------------------~
-- TABLE DATA permission~
-- -------------------------------------------~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','0','user','3','1','Can create a user into the system.')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','0','user','4','1','Can update the user present into the system.')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','0','role','4','0','')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','0','role','5','0','')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','0','role','6','0','')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','1','role','1','0','')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('1','1','role','3','1','Able to create users')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('2','0','role','1','0','Users can write messages')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('2','0','role','2','0','Users can receive messages')~
INSERT INTO `permission` (`principal_id`,`subordinate_id`,`type`,`action`,`template`,`comment`) VALUES
('2','0','role','3','0','Users are able to view visits of his profile')~



-- -------------------------------------------~
-- TABLE DATA privacysetting~
-- -------------------------------------------~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('0','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('1','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('2','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('3','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('4','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('5','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('6','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('7','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('8','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('9','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('10','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('11','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('12','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('13','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('14','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('15','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('20','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('23','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('24','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('25','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('27','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('29','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('30','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('34','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('44','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('46','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('49','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('56','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('57','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('58','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('59','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('60','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('61','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('62','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('63','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('64','1','1','1','1','1','1','','')~
INSERT INTO `privacysetting` (`user_id`,`message_new_friendship`,`message_new_message`,`message_new_profilecomment`,`appear_in_search`,`show_online_status`,`log_profile_visits`,`ignore_users`,`public_profile_fields`) VALUES
('65','1','1','1','1','1','1','','')~



-- -------------------------------------------~
-- TABLE DATA profile~
-- -------------------------------------------~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('1','1','2013-05-29 18:22:42','protected','admin','admin','1','1','webmaster@example.com','','1','','','+255717900016','0')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('2','2','2013-05-29 18:22:57','protected','demo','demo','1','1','demo@example.com','','1','D','','3456789','0')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('3','3','2013-05-29 18:23:06','protected','Charles','Innocent','1','1','innocentruge@gmail.com','','1','R','','+255717900016','0')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('4','4','2013-06-19 08:07:44','protected','MASHAKA  ','GWALIWA ','1','1','testing@yahoo.com','2007-04-05297','1','P','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('5','5','2013-06-19 08:07:44','protected','ALLY','MFAUME','1','1','testing@yahoo.com','2009-04-00234','1','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('6','6','2013-06-19 08:07:44','protected','AMON',' ELIBARIKI','1','1','testing@yahoo.com','2009-04-00277','1','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('7','7','2013-06-19 08:07:44','protected','AYOUB',' MESHACK','1','1','testing@yahoo.com','2009-04-00387','1','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('8','8','2013-06-19 08:07:44','protected','BEN','EDWARD','1','1','testing@yahoo.com','2009-04-00462','1','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('9','9','2013-06-19 08:07:44','protected','CHOTAMAWE','JAMES','1','1','testing@yahoo.com','2009-04-00691','1','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('10','10','2013-06-19 08:07:44','protected','FAUSTIN',' GOLDER','1','1','testing@yahoo.com','2009-04-00977','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('11','11','2013-06-19 08:07:44','protected','GABRIEL','GODFREY','1','1','testing@yahoo.com','2009-04-01054','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('12','12','2013-06-19 08:07:44','protected','HUSSEIN',' MASOUD','1','1','testing@yahoo.com','2009-04-01296','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('13','13','2013-06-19 08:07:44','protected','ISACK','KANTANTE','1','1','testing@yahoo.com','2009-04-01337','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('14','14','2013-06-19 08:07:44','protected','JAMES',' SULU','1','1','testing@yahoo.com','2009-04-01407','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('15','15','2013-06-19 08:07:44','protected','JAMES',' JOSEPH','1','1','testing@yahoo.com','2009-04-01517','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('16','16','2013-06-19 08:07:44','protected','JOSEPH',' MARIAGORETH','1','1','testing@yahoo.com','2009-04-01526','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('17','17','2013-06-19 08:07:44','protected','JUMA',' OMARY','1','1','testing@yahoo.com','2009-04-01601','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('18','18','2013-06-19 08:07:44','protected','JUMA','PETER','1','1','testing@yahoo.com','2009-04-01603','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('19','19','2013-06-19 08:07:44','protected','KAHEREWA',' MWASI','1','1','testing@yahoo.com','2009-04-01677','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('20','20','2013-06-19 08:07:44','protected','KAMAGE',' GOLDEN','1','1','testing@yahoo.com','2009-04-01733','1','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('21','21','2013-06-19 08:07:44','protected','KASANGA',' PAUL ','1','1','testing@yahoo.com','2009-04-01791','1','J','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('22','22','2013-06-19 08:07:44','protected','KASONGOYO',' ISAAC ','1','1','testing@yahoo.com','2009-04-01805','2','A','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('23','23','2013-06-19 08:07:44','protected','KILAJA',' ANETH','1','1','testing@yahoo.com','2009-04-01971','2','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('24','24','2013-06-19 08:07:44','protected','KILENZA',' FADHILI','1','1','testing@yahoo.com','2009-04-01986','2','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('25','25','2013-06-19 08:07:44','protected','KINDOLE',' FADHILI','1','1','testing@yahoo.com','2009-04-02039','2','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('26','26','2013-06-19 08:07:44','protected','KITOMARY',' DAVID','1','1','testing@yahoo.com','2009-04-02109','2','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('27','27','2013-06-19 08:07:44','protected','KOMBO','FATMA ','1','1','testing@yahoo.com','2009-04-02163','2','S','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('28','28','2013-06-19 08:07:44','protected','KUMALIJA',' ELHARD ','1','1','testing@yahoo.com','2009-04-02183','2','J','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('29','29','2013-06-19 08:07:44','protected','KUNDA',' MTUI','1','1','testing@yahoo.com','2009-04-02185','2','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('30','30','2013-06-19 08:07:44','protected','LUFYAGILA',' BESTON','1','1','testing@yahoo.com','2009-04-02347','2','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('31','31','2013-06-19 08:07:44','protected','LYATUU',' WILSON','1','1','testing@yahoo.com','2009-04-02426','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('32','32','2013-06-19 08:07:44','protected','MANG\'ENYA',' JIMMY','1','1','testing@yahoo.com','2009-04-02636','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('33','33','2013-06-19 08:07:44','protected','MANGI',' ARNOLD','1','1','testing@yahoo.com','2009-04-02638','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('34','34','2013-06-19 08:07:44','protected','MASAMU',' JEMIMA','1','1','testing@yahoo.com','2009-04-02714','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('35','35','2013-06-19 08:07:44','protected','MASSAMU',' NELSON','1','1','testing@yahoo.com','2009-04-02747','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('36','36','2013-06-19 08:07:44','protected','MASSATI',' NTINDIKIHI','1','1','testing@yahoo.com','2009-04-02750','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('37','37','2013-06-19 08:07:44','protected','MHIDZE','CLAVERFRED','1','1','testing@yahoo.com','2009-04-03092','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('38','38','2013-06-19 08:07:44','protected','MOHAMED',' MOHAMED ','1','1','testing@yahoo.com','2009-04-03325','2','S','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('39','39','2013-06-19 08:07:44','protected','MOHAMMED',' SALIMA','1','1','testing@yahoo.com','2009-04-03342','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('40','40','2013-06-19 08:07:44','protected','MPUTI',' GERALD','1','1','testing@yahoo.com','2009-04-03417','2','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('41','41','2013-06-19 08:07:44','protected','MSHIU','LEON','1','1','testing@yahoo.com','2009-04-03493','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('42','42','2013-06-19 08:07:44','protected','MUSTAFA',' AWADHI','1','1','testing@yahoo.com','2009-04-03683','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('43','43','2013-06-19 08:07:44','protected','MYULA',' OSCAR','1','1','testing@yahoo.com','2009-04-03944','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('44','44','2013-06-19 08:07:44','protected','NG\'HOMI','VITUS ','1','1','testing@yahoo.com','2009-04-04105','3','R','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('45','45','2013-06-19 08:07:44','protected','NGIMBWA','PETER ','1','1','testing@yahoo.com','2009-04-04113','3','C','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('46','46','2013-06-19 08:07:44','protected','NKWABI',' BAHATI','1','1','testing@yahoo.com','2009-04-04216','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('47','47','2013-06-19 08:07:44','protected','RENATUS','VEDASTUS','1','1','testing@yahoo.com','2009-04-04570','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('48','48','2013-06-19 08:07:44','protected','SABU','STEVEN','1','1','testing@yahoo.com','2009-04-04669','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('49','49','2013-06-19 08:07:44','protected','SAMSON','WILBROAD','1','1','testing@yahoo.com','2009-04-04754','3','','','+255719457834','1')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('50','50','2013-06-19 08:07:44','protected','SELEMANI','RAMADHANI','1','1','testing@yahoo.com','2009-04-04850','3','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('51','51','2013-06-19 08:07:44','protected','SENGE',' FARIDA','1','1','testing@yahoo.com','2009-04-04863','3','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('52','52','2013-06-19 08:07:44','protected','SOTERY','RICHARD','1','1','testing@yahoo.com','2009-04-05031','3','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('53','53','2013-06-19 08:07:44','protected','STEPHEN',' EDWARD','1','1','testing@yahoo.com','2009-04-05052','3','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('54','54','2013-06-19 08:07:44','protected','TIRA',' CASIAN ','1','1','testing@yahoo.com','2009-04-05160','3','N','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('55','55','2013-06-19 08:07:44','protected','WAMBURA',' MASWE','1','1','testing@yahoo.com','2009-04-05259','3','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('56','56','2013-06-19 08:07:44','protected','KAKANDE',' LEONARD','1','1','testing@yahoo.com','2009-04-05865','3','','','+255719457834','2')~
INSERT INTO `profile` (`id`,`user_id`,`timestamp`,`privacy`,`lastname`,`firstname`,`show_friends`,`allow_comments`,`email`,`regno`,`year_of_study`,`middle_name`,`staff_id`,`phone`,`degreeID`) VALUES
('57','57','0000-00-00 00:00:00','protected','Mwase','Christine','1','1','cmwase@ieee.org','','0','','678888/90','+255717900017','0')~



-- -------------------------------------------~
-- TABLE DATA profile_field~
-- -------------------------------------------~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('1','email','E-Mail','','VARCHAR','255','0','1','','','','CEmailValidator','','0','3','','0')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('2','firstname','First name','','VARCHAR','255','0','1','','','','','','0','3','','0')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('3','lastname','Last name','','VARCHAR','255','0','1','','','','','','0','3','','0')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('4','middle_name','Initials','','VARCHAR','45','0','0','','','','','','0','1','','0')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('5','staff_id','Staff Identification','','VARCHAR','45','0','1','','','','','','0','1','','1')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('7','regno','Registration Number','','VARCHAR','45','0','1','','','','','','0','1','','2')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('8','year_of_study','Year of Study','','INTEGER','0','0','1','','','','','','0','1','','2')~
INSERT INTO `profile_field` (`id`,`varname`,`title`,`hint`,`field_type`,`field_size`,`field_size_min`,`required`,`match`,`range`,`error_message`,`other_validator`,`default`,`position`,`visible`,`related_field_name`,`type`) VALUES
('9','phone','Phone Number','','VARCHAR','45','0','0','','','','','','0','1','','0')~



-- -------------------------------------------~
-- TABLE DATA profile_visit~
-- -------------------------------------------~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('1','2','1367763781','1367763781','1')~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('1','3','1361034669','1361034685','2')~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('2','1','1361381900','1361381926','2')~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('2','3','1361082311','1361082311','1')~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('3','1','1361034797','1361034898','2')~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('3','2','1361034806','1361034806','1')~
INSERT INTO `profile_visit` (`visitor_id`,`visited_id`,`timestamp_first_visit`,`timestamp_last_visit`,`num_of_visits`) VALUES
('34','17','1361299977','1361299977','1')~



-- -------------------------------------------~
-- TABLE DATA pt_announcement~
-- -------------------------------------------~
INSERT INTO `pt_announcement` (`id`,`title`,`body`,`timePosted`,`archived`) VALUES
('1','PT chance for 1st year','I take this opportunity to inform all first year students that PT places are available at ZANTEL TZ
','2013-05-10 01:03:09','0')~
INSERT INTO `pt_announcement` (`id`,`title`,`body`,`timePosted`,`archived`) VALUES
('3',' Android Developmet','I take this opportunity to inform all  students that there will be a training on android development!!
','2013-05-10 01:06:23','0')~
INSERT INTO `pt_announcement` (`id`,`title`,`body`,`timePosted`,`archived`) VALUES
('4','Joomla Training ','I take this opportunity to inform all  students that there will be a session conducted by Mr Innocent Charles on Joomla CMS.
','2013-05-10 01:07:10','0')~



-- -------------------------------------------~
-- TABLE DATA pt_application~
-- -------------------------------------------~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('1','2009-04-02163','2','2','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('2','2009-04-04105','6','3','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('3','2009-04-00234','7','1','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('4','2009-04-01517','6','1','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('5','2009-04-01986','3','2','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('6','2009-04-02347','1','2','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('7','2009-04-01733','2','1','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('8','2009-04-05865','3','3','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('9','2009-04-04754','6','3','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('10','2009-04-04216','5','3','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('11','2007-04-05297','9','1','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('12','2009-04-00277','5','1','1')~
INSERT INTO `pt_application` (`ID`,`registrationNo`,`companyID`,`ptType`,`status`) VALUES
('13','2009-04-00387','4','1','1')~



-- -------------------------------------------~
-- TABLE DATA pt_arrival_note~
-- -------------------------------------------~
INSERT INTO `pt_arrival_note` (`ID`,`registrationNo`,`documentName`,`submissionTime`,`status`,`ptType`) VALUES
('1','2009-04-00234','2009-04-00234-agile web application development with yii 1.1 and php5.pdf','2013-06-13 21:25:20','Active','1')~



-- -------------------------------------------~
-- TABLE DATA pt_arrival_note2~
-- -------------------------------------------~
INSERT INTO `pt_arrival_note2` (`ID`,`registrationNo`,`ptStartDate`,`submissionDate`,`studentPosition`,`workingHours`,`workingDays`,`companyID`,`trainerName`,`trainerPosition`,`trainerEmail`,`trainerPhoneNumber`,`ptType`) VALUES
('4','2009-04-04105','2013-07-01','2013-05-09','Network Engineer','8','5','6','Ismail Mohamed','Network Engineer','jama@kasema.com','+255787907845','3')~



-- -------------------------------------------~
-- TABLE DATA pt_company~
-- -------------------------------------------~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('1','RugeCorp','4','18','located at urban areas','4','+255732140048','rugecorp@gmail.com','1','Second year students')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('2','Duxte LTD','1','1','It is near mwenge bus stop! on the road to coca cola','6','+255732140048','admin@duxte.com','1','All students')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('3','ICTPack Solutions','3','5','Arusha town ','7','+255732140048','admin@wasomionline.com','1','Third year only')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('4','Beta Solutions','2','15','Near, University of Dodoma','0','+255732140048','admin@yahoo.com','1','First year only')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('5','Google Corporation','6','31','This is in Hai near Moshi','4','+44896734','info@gmail.com','1','Third year students')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('6','SDM TZ','1','1','Kinondoni near studio','4','+255732140048','info@sdmtz.com','1','All students')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('7','IT FARM','1','1','Located near ESARP','1','+255732140048','admin@itdo.com','1','Second year students only')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('8','CoICT','1','1','Near Togo tower!!','7','+255787909056','coict@yahoo.com','1','For all students')~
INSERT INTO `pt_company` (`ID`,`companyName`,`region`,`district`,`locationDescr`,`vacancy`,`phoneNumber`,`email`,`status`,`comments`) VALUES
('9','Kamata INC','3','4','Arusha mjini ','5','+255787909056','lala@kamata.com','1','All students')~



-- -------------------------------------------~
-- TABLE DATA pt_contact_person~
-- -------------------------------------------~
INSERT INTO `pt_contact_person` (`ID`,`companyID`,`firstname`,`lastname`,`phoneNumber`,`email`) VALUES
('1','8','Sophia','Nahoza','+255908978','s@yahoo.com')~
INSERT INTO `pt_contact_person` (`ID`,`companyID`,`firstname`,`lastname`,`phoneNumber`,`email`) VALUES
('2','9','Victoria','Masalu','+255908978','vicky@kamata.com')~
INSERT INTO `pt_contact_person` (`ID`,`companyID`,`firstname`,`lastname`,`phoneNumber`,`email`) VALUES
('3','3','Ismail','Mohamed','+255908978','sumag@yahoo.com')~
INSERT INTO `pt_contact_person` (`ID`,`companyID`,`firstname`,`lastname`,`phoneNumber`,`email`) VALUES
('4','2','Kalunde','Kihongosi','+255908978','kkihongosi@gmail.com')~



-- -------------------------------------------~
-- TABLE DATA pt_coordinator~
-- -------------------------------------------~
INSERT INTO `pt_coordinator` (`ID`,`staffID`) VALUES
('1','3')~



-- -------------------------------------------~
-- TABLE DATA pt_districts~
-- -------------------------------------------~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('1','1','Kinondoni')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('2','1','Ilala')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('3','1','Temeke')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('4','3','Arumeru')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('5','3','Arusha')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('6','3','Karatu')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('7','3','Longido')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('8','3','Monduli')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('9','3','Ngorongoro')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('10','2','Bahi')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('11','2','Dodoma urban')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('12','2','Kongwa')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('13','2','Kondoa')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('14','2','Mpwapwa')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('15','2','Chamwino')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('16','4','Biharamulo')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('17','4','Bukoba Rural')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('18','4','Bukoba Urban')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('19','4','Karagwe')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('20','4','Misenyi')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('21','4','Muleba')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('22','4','Ngara')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('23','5','Chunya')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('24','5','Ileje')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('25','5','Kyela')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('26','5','Mbarali')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('27','5','Mbeya Urban')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('28','5','Mbeya Rural')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('29','5','Mbozi')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('30','5','Rungwe')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('31','6','Hai')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('32','6','Moshi Rural')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('33','6','Moshi Urban')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('34','6','Mwanga')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('35','6','Rombo')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('36','6','Same')~
INSERT INTO `pt_districts` (`ID`,`regionID`,`district`) VALUES
('37','6','Siha')~



-- -------------------------------------------~
-- TABLE DATA pt_documents~
-- -------------------------------------------~
INSERT INTO `pt_documents` (`ID`,`registrationNo`,`documentName`,`submissionTime`,`comments`) VALUES
('1','2009-04-00234','2009-04-00234-Inno-UD0001.pdf','2013-04-25 17:08:14','Edit the following area in you report 
the paragraph, line spacing between paragraph')~



-- -------------------------------------------~
-- TABLE DATA pt_regions~
-- -------------------------------------------~
INSERT INTO `pt_regions` (`ID`,`region`) VALUES
('1','Dar es Salaam')~
INSERT INTO `pt_regions` (`ID`,`region`) VALUES
('2','Dodoma')~
INSERT INTO `pt_regions` (`ID`,`region`) VALUES
('3','Arusha')~
INSERT INTO `pt_regions` (`ID`,`region`) VALUES
('4','Kagera')~
INSERT INTO `pt_regions` (`ID`,`region`) VALUES
('5','Mbeya')~
INSERT INTO `pt_regions` (`ID`,`region`) VALUES
('6','Kilimanjaro')~



-- -------------------------------------------~
-- TABLE DATA pt_selection~
-- -------------------------------------------~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('1','2009-04-00234','1')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('2','2009-04-04105','3')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('3','2009-04-01296','5')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('4','2009-04-00977','2')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('5','2009-04-02163','1')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('6','2009-04-01517','3')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('7','2009-04-01986','5')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('8','2009-04-02347','4')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('9','2009-04-01733','1')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('10','2009-04-05865','6')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('11','2009-04-04754','2')~
INSERT INTO `pt_selection` (`ID`,`registrationID`,`region`) VALUES
('12','2009-04-04216','5')~



-- -------------------------------------------~
-- TABLE DATA pt_status~
-- -------------------------------------------~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('1','2009-04-01986','3','57','2','Active','Supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('2','2009-04-05865','3','57','3','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('3','2009-04-02163','2','57','2','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('4','2009-04-01733','2','2','1','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('5','2009-04-04216','5','2','3','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('6','2009-04-00234','7','57','2','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('7','2009-04-04105','6','57','3','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('8','2009-04-00234','9','57','1','Done','Supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('9','2009-04-01517','6','57','1','Active','Not yet supervised')~
INSERT INTO `pt_status` (`ID`,`registrationNo`,`companyID`,`supervisorID`,`ptType`,`status`,`pStatus`) VALUES
('10','2009-04-02347','1','57','2','Active','Not yet supervised')~



-- -------------------------------------------~
-- TABLE DATA pt_summary~
-- -------------------------------------------~
INSERT INTO `pt_summary` (`id`,`registrationNo`,`supervisorID`,`officerMarks`,`logbookMarks`,`supervisorMarks`,`reportMarks`,`totalMarks`,`ptReportTitle`,`studentRemarks`,`dateVisited`,`ptType`) VALUES
('1','2009-04-01517','57','9','17','8','53','87','Implementation of Database system','good','2013-06-02','1')~



-- -------------------------------------------~
-- TABLE DATA pt_supervisor~
-- -------------------------------------------~
INSERT INTO `pt_supervisor` (`ID`,`staffID`,`supervisionRegion`) VALUES
('1','57','Dar es Salaam')~
INSERT INTO `pt_supervisor` (`ID`,`staffID`,`supervisionRegion`) VALUES
('2','2','Arusha')~



-- -------------------------------------------~
-- TABLE DATA role~
-- -------------------------------------------~
INSERT INTO `role` (`id`,`title`,`description`,`membership_priority`,`price`,`duration`) VALUES
('1','Super Administrator','This is the framework super administrator','0','0','0')~
INSERT INTO `role` (`id`,`title`,`description`,`membership_priority`,`price`,`duration`) VALUES
('2','Administrator','This is the normal administrator','0','0','0')~
INSERT INTO `role` (`id`,`title`,`description`,`membership_priority`,`price`,`duration`) VALUES
('3','Student','This is the normal student ','0','0','0')~
INSERT INTO `role` (`id`,`title`,`description`,`membership_priority`,`price`,`duration`) VALUES
('4','Staff','This is the normal staff','0','0','0')~
INSERT INTO `role` (`id`,`title`,`description`,`membership_priority`,`price`,`duration`) VALUES
('5','TE4','This is the group of fourth year TE students!','','','')~



-- -------------------------------------------~
-- TABLE DATA subsystem~
-- -------------------------------------------~
INSERT INTO `subsystem` (`subsystemID`,`subsysName`,`url`,`iconUrl`) VALUES
('1','userGroups','/ete/userGroups','/ete/images/sample.png')~
INSERT INTO `subsystem` (`subsystemID`,`subsysName`,`url`,`iconUrl`) VALUES
('6','userGroups','/ete/userGroups','/ete/images/sample.png')~



-- -------------------------------------------~
-- TABLE DATA tbl_menu~
-- -------------------------------------------~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('1','','Home','<div style=\"TEXT-ALIGN: left\" class=\"main\" align=\"center\"><b>
<div style=\"TEXT-ALIGN: left; FONT-WEIGHT: normal\" class=\"main\" align=\"center\"><strong><em>Welcome to</em>&nbsp;<em>the</em> JOB PORTAL <em>of &nbsp;</em></strong><b><div class=\"main\" align=\"center\" style=\"text-align: left; font-weight: normal; display: inline !important; \"><strong><font size=\"4\">ENRICH AFRICA (T) LIMITED</font></strong></div></b></div>
<div style=\"TEXT-ALIGN: left; FONT-WEIGHT: normal\" class=\"main\" align=\"center\"><strong><font size=\"5\">&nbsp;&nbsp;</font></strong><font size=\"2\"><span style=\"FONT-FAMILY: \'Berlin Sans FB\'; FONT-SIZE: 19px\" class=\"Apple-style-span\">......... a gateway for job seekers</span><span style=\"FONT-FAMILY: \'Berlin Sans FB\'; FONT-SIZE: 14pt; FONT-WEIGHT: normal\">&nbsp;&amp;</span><span style=\"FONT-FAMILY: \'Berlin Sans FB\'; FONT-SIZE: 14pt; VERTICAL-ALIGN: baseline; FONT-WEIGHT: normal\">&nbsp;a </span><span style=\"FONT-FAMILY: \'Berlin Sans FB\'; FONT-SIZE: 14pt; FONT-WEIGHT: normal\">tool for employers</span></font></div><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><font class=\"Apple-style-span\" color=\"#0066ff\" size=\"6\" face=\"\'Berlin Sans FB\'\"><span style=\"FONT-SIZE: 19px\" class=\"Apple-style-span\">
<p style=\"MARGIN-TOP: 0pt; TEXT-INDENT: 0in; MARGIN-BOTTOM: 0pt; MARGIN-LEFT: 0in\"><br></p></span></font></span>
<div style=\"TEXT-ALIGN: left; FONT-WEIGHT: normal\" class=\"main\" align=\"center\"><strong><font face=\"Georgia\"><em><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">Looking for a&nbsp;</span>better job<span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">? &nbsp;Just&nbsp;</span>graduated<span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">&nbsp;from school? &nbsp;New to&nbsp;</span><font class=\"Apple-style-span\">job market</font><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">?</span></em></font></strong></div>
<div style=\"TEXT-ALIGN: left; FONT-WEIGHT: normal\" class=\"main\" align=\"center\"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><font face=\"Georgia\"><em>This is the place for you !</em></font></span></strong></div>
<div style=\"TEXT-ALIGN: left; FONT-WEIGHT: normal\" class=\"main\" align=\"center\"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><br><font face=\"Georgia\"><em></em></font></span></strong></div>
<div style=\"TEXT-ALIGN: left; FONT-WEIGHT: normal\" class=\"main\" align=\"center\"><font face=\"Georgia\"><em><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">Welcome to the Job Seekers. Here is an easy way&nbsp;</span></strong><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">to search for the Jobs.&nbsp;<a href=\"http://enrich.elimuguide.co.tz/index.php?q=9de4a97425678c5b1288aa70c1669a64\">Just register</a>&nbsp;and forget....&nbsp;</span></strong></em></font><b><div class=\"main\" align=\"center\" style=\"text-align: left; display: inline !important; \"><div class=\"main\" align=\"center\" style=\"text-align: left; font-weight: normal; display: inline !important; \"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><font face=\"Georgia\"><em>We shall try for you.&nbsp;</em></font></span></strong></div></div></b></div><div style=\"text-align: left; \" class=\"main\" align=\"center\"><div style=\"text-align: left; font-weight: normal; \" class=\"main\" align=\"center\"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><font face=\"Georgia\"><em><br>Or you may wish to apply online!!! You are Welcome&nbsp;<br><br>Welcome to Employers looking for staff with quality&nbsp;<br>Please&nbsp;</em></font><a href=\"http://enrich.elimuguide.co.tz/index.php?q=815b08a0599121ba2d886a9a68888381\"><font class=\"Apple-style-span\" color=\"#000000\"><font face=\"Georgia\"><em></em></font><font face=\"Georgia\"><em>register and post your requirements</em></font></font></a><font face=\"Georgia\"><em>.&nbsp;We shall do the rest</em></font></span></strong></div><div style=\"text-align: left; font-weight: normal; \" class=\"main\" align=\"center\"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><font face=\"Georgia\"><em><br></em></font></span></strong></div><div style=\"text-align: left; font-weight: normal; \" class=\"main\" align=\"center\"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><font face=\"Georgia\"><em>.........................................................................................................................................................</em></font></span></strong></div>
<div style=\"text-align: left; font-weight: normal; \" class=\"main\" align=\"center\"><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\"><em><font face=\"Georgia\"></font></em></span></strong>&nbsp;</div>
<div style=\"text-align: left; \" class=\"main\" align=\"center\">Please visit our other pages, for</div><div style=\"text-align: left; \" class=\"main\" align=\"center\"><i>Hot Jobs</i><span class=\"Apple-style-span\" style=\"font-weight: normal;\"> - Current Jobs that we are looking for immediate placement</span></div><div style=\"text-align: left; \" class=\"main\" align=\"center\"><i>HR Services</i><span class=\"Apple-style-span\" style=\"font-weight: normal; \"> - Our other Services</span></div><div style=\"text-align: left; \" class=\"main\" align=\"center\"><i>Our Profile</i><span class=\"Apple-style-span\" style=\"font-weight: normal; \"> - All about ourselves</span></div><div style=\"text-align: left; \" class=\"main\" align=\"center\"><i>Contact us</i><span class=\"Apple-style-span\" style=\"font-weight: normal; \"> - to find our contact information and route map to our office</span></div><div style=\"text-align: left; font-weight: normal; \" class=\"main\" align=\"center\"><b><div class=\"main\" align=\"center\" style=\"text-align: left; display: inline !important; \"><div class=\"main\" align=\"center\" style=\"text-align: left; font-weight: normal; display: inline !important; \"><br></div></div></b></div><div style=\"text-align: left; font-weight: normal; \" class=\"main\" align=\"center\"><b><div class=\"main\" align=\"center\" style=\"text-align: left; \"><div class=\"main\" align=\"center\" style=\"text-align: left; font-weight: normal; \"><strong><span class=\"Apple-style-span\" style=\"font-weight: normal; \"><font face=\"Georgia\"><em>.........................................................................................................................................................</em></font></span></strong></div></div></b></div></div></b></div><div style=\"TEXT-ALIGN: left\" class=\"main\" align=\"center\">
<div style=\"TEXT-ALIGN: left\" class=\"main\" align=\"center\"><strong><br></strong></div><div style=\"TEXT-ALIGN: left\" class=\"main\" align=\"center\"><strong>TIPS TO JOB SEEKERS</strong></div>
<div style=\"TEXT-ALIGN: left\" class=\"main\" align=\"center\"><strong><br></strong></div>
<div><strong><span style=\"FONT-WEIGHT: normal\" class=\"Apple-style-span\">1. Focus on learning and bother not for earning. Growth will follow sooner or later&nbsp;</span></strong></div></div>
<div>2. Look for better opening that gives you opportunity to learn even if you were to join for a very small remunaration. Your hardwork and experience will earn you in arrears.<br>3. Day dreaming will fetch you nothing. Be practical. Just the qualification will not earn you millions but it is your worth to the employer. Look at yourself, then the empoyer would look at you. Know what you are worth and keep improving yourself.<br>4. Self confidence speaks for itself. It is you who talks if not your self confidence. The result is pathetic. Only way to improve self confidence is through learning and hardwork.<br><br><br><strong>TIPS TO EMPLOYERS</strong> <br><br>1. Employees\' participation in the management is the current concept of success. When every employee feels himself/herself as part of organization and work, the Organisation will achieve tremendous growth and prosperity. <br>2. Delegation of authority together with responsibilities and the trust (even at the cost of initial problems) reposed are the elements to make every employee a part of the organization. <br>3. If you are a professionally organized Company, every employee with average skills &amp; above will perform and turn into your profit making asset.<br>4. If you are poorly organized, you will kill efficiency of your staff and blame them. <br></div><br><br>
<div><br></div>
<div><br><span style=\"FONT-SIZE: 10px\">Disclaimer - We shall not be binding to anyone subscribing, using, registering with the website orsending profiles to the website to provide any service whatsoever. It is purely at the convenience and discreteion of the website owner, that is Enrich Africa (T) Ltd</span> </div>','2011-03-22')~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('3','','Profile','<p class=\"MsoNormalCxSpFirst\" style=\"line-height:normal\"><b><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">ENRICH AFRICA (T) Ltd. is a premier institute
for HR Consultancy &amp; Solutions, Talent Sourcing &amp;</span></b><b><span lang=\"FR\" style=\"mso-ansi-language:FR\"> Placement<o:p></o:p></span></b></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">We are a team of
passionate HR Professionals with considerable experience across various
sectors.<span style=\"mso-spacerun:yes\">&nbsp;</span></span></b></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\"><span style=\"mso-spacerun:yes\"></span></span></b>Employers have been looking for skillful staff, efficient managers and responsible and committed executives from the local resources but experience the scarce.&nbsp; On the other hand there are thousands of qualified people wandering without jobs, who with proper training and career guidance could very well fit in those positions.&nbsp; The Institute comes into existence to match both.&nbsp; The end result is the cost cutting and better output for the employer and bright future for the youth.</p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><p class=\"MsoNormalCxSpFirst\" style=\"line-height:normal\"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\"><br></span></b></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height:normal\"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">Our Vision<o:p></o:p></span></b></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">To emerge as a leading HR Services provider in
East Africa anchored on values of honesty, dignity, transparency and diversity.
<o:p></o:p></span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><o:p>&nbsp;</o:p></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">Our Mission<o:p></o:p></span></b></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">To create value and competitive advantage for
our clients by striving for excellence in every thing we do and delivering on
our promises.&nbsp;</span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">To provide professional, process driven &amp; sustainable
HR solutions for betterment of workplaces.</span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">To ensure satisfaction of employer and employee
by providing the right environment for the right talent.</span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">To develop and motivate our people and reward
their contribution, to enable them to deliver an exceptional service every
time. We foster an entrepreneurial spirit that gives us freedom to challenge
conventional thinking. </span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\"><o:p>&nbsp;</o:p></span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">Our Strengths</span><o:p></o:p></b></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">We have a job portal with a large and fast
expanding data base<o:p></o:p></span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">We have our sister concern in India which is
networked with 5 top job portals and specialize in Middle East and Africa
placements. </span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">We have the data base of expats working in
Tanzania.<span style=\"mso-spacerun:yes\">&nbsp; </span></span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">We are an association of experienced HR
professionals with wide areas of expertise.<span style=\"mso-spacerun:yes\">&nbsp;
</span>We collectively work on projects for the best output. </span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height:normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\">We work in close liaison and guidance with
Government Officials from various departments where necessary and assist our
clients.&nbsp;</span></p></p>','2011-03-22')~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('4','','Hr services','<p><b><span style=\"FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: rgb(51,51,51); FONT-SIZE: 12px\" class=\"Apple-style-span\"></span></b></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; \"><span class=\"Apple-style-span\" style=\"font-weight: 800;\"><font class=\"Apple-style-span\" size=\"4\">Following are some of our regular Services that we offer to our Clients. &nbsp;We can however offer other HR Services not stated on request from our Clients. &nbsp;</font></span></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; \"><span class=\"Apple-style-span\" style=\"font-weight: 800;\"><br></span></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; \"><span class=\"Apple-style-span\" style=\"font-weight: 800;\"><font class=\"Apple-style-span\" size=\"4\">Staff Recruitment - Tanzanian nationals - for all positions and categories</font></span></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; \"></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; font-weight: 800; \"><sup><font class=\"Apple-style-span\" size=\"3\">We pick up suitable candidates from our data base, screen,
short list and provide the best possible.</font></sup></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sup><font class=\"Apple-style-span\" size=\"3\">We provide career
guidance to Job Seekers</font></sup></p>

<p class=\"MsoNormal\" style=\"line-height: normal; font-weight: 800; \"><sup><font class=\"Apple-style-span\" size=\"3\">We assist wherever necessary to Job Seekers as well as employers.</font></sup></p><p class=\"MsoNormal\" style=\"line-height: normal; \"></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; font-weight: 800; \"><b><span lang=\"EN-US\"><font class=\"Apple-style-span\" size=\"3\"><br></font></span></b></p><p class=\"MsoNormalCxSpFirst\" style=\"line-height: normal; font-weight: 800; \"><font class=\"Apple-style-span\" size=\"4\"><b><span lang=\"EN-US\"><font class=\"Apple-style-span\">Staff Recruitment –
Expats</font></span></b><span lang=\"EN-US\"><font class=\"Apple-style-span\"> – for expert
positions in any vertical</font></span></font></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">For those positions where locals
are scarce, we assist our clients in sourcing Expatriates. &nbsp;We are one of best sources available in Tanzania.</font></sub></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\"><br></span></b></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><b><span lang=\"EN-US\"><font class=\"Apple-style-span\" size=\"4\">Total Outsourcing -
Foreign Experts on short assignments</font><o:p></o:p></span></b></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">We source Expatriates who are experts.</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">We provide complete administrative support, involving logistics, work permits/Visas, Accommodation, payment of salaries etc.</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">Please call us on for more information.&nbsp;</font></sub></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; \"><span class=\"Apple-style-span\" style=\"font-weight: 800; \"><b style=\"mso-bidi-font-weight:
normal\"><span lang=\"EN-US\" style=\"mso-ansi-language:EN-US\"><br></span></b></span></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; \"><font class=\"Apple-style-span\" size=\"4\"><span class=\"Apple-style-span\" style=\"font-weight: 800; \"><b><span lang=\"EN-US\">HR Consultancy</span></b></span><span class=\"Apple-style-span\" style=\"font-weight: 800; \"><span lang=\"EN-US\"> – We provide,</span></span></font></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">Skills and Competencies assessment</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">Identification of KRAs/KPIs and Gap Analysis</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">Performance Management Systems</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">Job Analysis and Descriptions</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\"><br></font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; \"><span class=\"Apple-style-span\" style=\"font-weight: 800; \"><b><span lang=\"EN-US\"><font class=\"Apple-style-span\" size=\"4\">Other Services</font></span></b></span></p>

<p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">We guide and assist our clients concerning
labour regulations.</font></sub></p><p class=\"MsoNormalCxSpMiddle\" style=\"line-height: normal; font-weight: 800; \"><sub><font class=\"Apple-style-span\" size=\"3\">We guide and assist our clients in processing Work Permits</font></sub></p><p></p><p></p><p></p>','2011-03-22')~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('5','','Contact us','<table border=\"0\" cellspacing=\"0\" cellpadding=\"15\" width=\"100%\">
<tbody>
<tr>
<td>
<p class=\"headings\" align=\"justify\">Contact Us </p>
<p><strong>Postal address:&nbsp;</strong></p><p>PO Box 32718, Dar es Salaam TANZANIA</p>
<p><strong>Physical address:</strong> <br>Plot No. 15, Behind Oil Com Fuel Station, Changombe Road, Dar es Salaam, TANZANIA</p>
<p><strong>Email ID:</strong> <a href=\"mailto:hrd@enrichafrica.org\">hrd@enrichafrica.org</a>&nbsp;or <a href=\"mailto:admin@enrichafrica.org\">admin@enrichafrica.org</a> </p>
<p>&nbsp;</p>
<p align=\"center\"><a href=\"images/routemap_05.jpg\">Click here to view routemap </a></p>
<p align=\"center\"><a href=\"images/routemap_05.jpg\"><img border=\"0\" alt=\"Routemap\" src=\"images/routemap_05.jpg\" width=\"175\" height=\"97\"></a></p></td></tr>
<tr>
<td>&nbsp;</td></tr></tbody></table>','2011-03-22')~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('6','','Facilities','<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"15\">     
        <tbody><tr>
            <td><p align=\"justify\" class=\"headings\">COURSES</p>
				<p align=\"center\">&nbsp; </p>
                <p align=\"center\">&nbsp;</p>
                <p align=\"center\">&nbsp;</p>
                <p align=\"center\">Very soon we will update this page, Please visit again. </p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"right\"><a href=\"courses.html#courseoff\">Top</a>ˆ</p>                 
        	</td>
        </tr> 
        </tbody></table>','2010-10-26')~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('7','','Duration','<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"15\">     
        <tbody><tr>
            <td><p align=\"justify\" class=\"headings\">COURSES</p>
				<p align=\"center\">&nbsp; </p>
                <p align=\"center\">&nbsp;</p>
                <p align=\"center\">&nbsp;</p>
                <p align=\"center\">Very soon we will update this page, Please visit again. </p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                </td></tr></tbody></table><br>','2010-10-26')~
INSERT INTO `tbl_menu` (`menu_id`,`link`,`title`,`body`,`date`) VALUES
('8','','Special Package','<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"15\">     
        <tr>
            <td><p align=\"justify\" class=\"headings\">COURSES</p>
				<p align=\"center\">&nbsp; </p>
                <p align=\"center\">&nbsp;</p>
                <p align=\"center\">&nbsp;</p>
                <p align=\"center\">Very soon we will update this page, Please visit again. </p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"center\" class=\"text_bold_blue2\">&nbsp;</p>
                <p align=\"right\"><a href=\"courses.html#courseoff\">Top</a>&#710;</p>                 
        	</td>
        </tr> 
        </table>','0000-00-00')~



-- -------------------------------------------~
-- TABLE DATA translation~
-- -------------------------------------------~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('About','Über','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('About','Acerca','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('About','me concernant ??','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('About','Info','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('About','Info','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Access control','Zugangskontrolle','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Access control','Control de acceso','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Access control','Controle d acces','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Access control','Controllo accesso','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Action','Aktion','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Action','Acción','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Action','Action','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Action','Azione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Actions','Aktionen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Actions','Acciones','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Actions','Actions','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Actions','Azioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activated','erstmalig Aktiviert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activated','Activado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activated','PremiÃ¨re activation de votre compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activated','Attivato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active','Aktiv','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active','Activo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active','Actif','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active','Attiv','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active','Aktiv','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active','ÐÐºÑ‚Ð¸Ð²Ð¸Ñ€Ð¾Ð²Ð°Ð½','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active - First visit','Aktiv - erster Besuch','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active - First visit','Activo - Primera visita','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active - First visit','Actif - premiÃ¨re visite','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active - First visit','Attivo - Priva visita','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active users','Aktive Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active users','Usuarios activos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active users','Utiliateurs actifs','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active users','Utenti attivi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Active users','Aktywni uÅ¼ytkownicy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activities','Aktivitäten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activities','Actividades','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activities','ActivitÃ©s','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Activities','AttivitÃ ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Add as a friend','Zur Kontaktliste hinzufügen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Add as a friend','Agregar como amigo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Add as a friend','Ajouter Ã  ma liste de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Add as a friend','Aggiungi un contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin inbox','Administratorposteingang','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin inbox','Bandeja de entrada de Admin','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin inbox','Boite e-mail de l administrateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin inbox','Admin - Posta in arrivo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin inbox','ZarzÄ…dzaj skrzynkÄ… odbiorczÄ…','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin sent messages','Gesendete Nachrichten des Administrators','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin sent messages','Mensajes enviados de Admin','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin sent messages','E-mail envoyÃ© par l administrateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin sent messages','Admin - Messaggi inviati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin sent messages','WiadomoÅ›ci wysÅ‚ane przez administratora','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users','Administratoren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users','Usuarios administradores','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users','Administrateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users','Utenti admin','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users','Administratorzy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users can not be deleted!','Administratoren können nicht gelöscht werden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users can not be deleted!','¡No se pueden eliminar los usuarios Administradores!','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users can not be deleted!','UN compte administrateur ne peut pas Ãªtre supprimÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users can not be deleted!','Utente admin non cancellabile!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Admin users can not be deleted!','Nie moÅ¼na usunÄ…Ä‡ konta administratora','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('All','Alle','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('All','Todos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('All','Ade tous','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('All','Tutto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allow profile comments','Profilkommentare erlauben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allow profile comments','Permitir comentarios en perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allow profile comments','Autoriser les commentaires de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allow profile comments','Consenti commenti profili','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed are lowercase letters and digits.','Erlaubt sind Kleinbuchstaben und Ziffern.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed are lowercase letters and digits.','Se permiten letras minúsculas y dígitos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed are lowercase letters and digits.','Seules les minuscule et les chiffres sont autorisÃ©s.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed are lowercase letters and digits.','Sono consentiti lettere minuscole e numeri.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed are lowercase letters and digits.','Erlaubt sind Kleinbuchstaben und Ziffern.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed lowercase letters and digits.','Consenti lettere minuscole e numeri.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed lowercase letters and digits.','Ð”Ð¾Ð¿ÑƒÑÐºÐ°ÑŽÑ‚ÑÑ ÑÑ‚Ñ€Ð¾Ñ‡Ð½Ñ‹Ðµ Ð±ÑƒÐºÐ²Ñ‹ Ð¸ Ñ†Ð¸Ñ„Ñ€Ñ‹.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed roles','Erlaubte Rollen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed roles','Roles permitidos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed roles','Permission rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed roles','Ruoli autorizzati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed roles','DostÄ™pne role','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed users','Erlaubte Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed users','Usuarios permitidos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed users','Permission utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed users','Utenti autorizzati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Allowed users','DostÄ™pni uÅ¼ytkownicy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Already exists.','Existiert bereits.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Already exists.','Ya existe.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Already exists.','Existe dÃ©jÃ .','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Already exists.','GiÃ  esistente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Already exists.','Existiert bereits.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Already exists.','Ð£Ð¶Ðµ ÑÑƒÑ‰ÐµÑÑ‚Ð²ÑƒÐµÑ‚.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while saving your changes','Es ist ein Fehler aufgetreten.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while saving your changes','Ocurrió un error al guardar los cambios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while saving your changes','Une erreur est survenue.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while saving your changes','Si Ã¨ verificato un errore durante il salvataggio delle modifiche.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while saving your changes','WystÄ…piÅ‚ bÅ‚Ä…d podczas zapisywania Twoich zmian.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while uploading your avatar image','Ein Fehler ist beim hochladen ihres Profilbildes aufgetreten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while uploading your avatar image','Ha ocurrido un error al cargar una imagen de tu avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while uploading your avatar image','Une erreur est survenue lors du chargement de votre photo de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('An error occured while uploading your avatar image','Si Ã¨ verificato un errore durante il caricamento dell\'immagine','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Answer','Antworten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Answer','Respuesta ','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Appear in search','In der Suche erscheinen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Appear in search','Aparecen en la b','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Appear in search','Je souhaite apparaitre dans les rÃ©sultats de recherche','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Appear in search','Mostra nelle ricerche','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you really sure you want to delete your Account?','Sind Sie Sicher, dass Sie Ihren Zugang löschen wollen?','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you really sure you want to delete your Account?','¿Seguro que desea eliminar su cuenta?','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you really sure you want to delete your Account?','Etes vous sur de vouloir supprimer votre compte?','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you really sure you want to delete your Account?','Sicuro di voler cancellare il tuo account?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you really sure you want to delete your Account?','Czy jesteÅ› pewien, Å¼e chcesz usunÄ…Ä‡ konto?','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to delete this item?','Sind Sie sicher, dass Sie dieses Element wirklich löschen wollen? ','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to delete this item?','¿Seguro desea eliminar este elemento?','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to delete this item?','Etes vous sur de supprimÃ© cet elÃ©ment? ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to delete this item?','Sicuro di cancellare questo elemento?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to delete this item?','Ð’Ñ‹ Ð´ÐµÐ¹ÑÑ‚Ð²Ð¸Ñ‚ÐµÐ»ÑŒÐ½Ð¾ Ñ…Ð¾Ñ‚Ð¸Ñ‚Ðµ ÑƒÐ´Ð°Ð»Ð¸Ñ‚ÑŒ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ?','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to remove this comment from your profile?','Sind Sie sicher, dass sie diesen Kommentar entfernen wollen?','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to remove this comment from your profile?','¿Estás seguro que deseas borrar este comentario?','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to remove this comment from your profile?','Etes vous sur de vouloir supprimer ce commentaire?','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure to remove this comment from your profile?','Sicuro di voler eliminare il commento dal tuo profilo?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure you want to remove this friend?','Sind Sie sicher, dass Sie diesen Kontakt aus ihrer Liste entfernen wollen?','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure you want to remove this friend?','','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure you want to remove this friend?','ÃŠtes vous sur de vouloir suprimer ce membre de votre liste de contact?','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Are you sure you want to remove this friend?','Sicuro di voler rimuovere questo contatto?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Assign this role to new users automatically','Rolle automatisch an neue Benutzer zuweisen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Assign this role to new users automatically','Asignar esta funci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Assign this role to new users automatically','RÃ´le automatique pour un nouveau membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Assign this role to new users automatically','Assegna questo ruolo automaticamente ai nuovi utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Automatically extend subscription','Mitgliedschaft automatisch verlängern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Avatar image','Profilbild','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Avatar image','Tu Avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Avatar image','Image de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Avatar image','Avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back','Zurück','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back','Volver','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back','Retour','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back','Indietro','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to inbox','Zurück zum Posteingang','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to inbox','Volver a la bandeja de entrada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to inbox','Retour Ã  la boite mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to inbox','Torna alla posta in arrivo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to my Profile','Zurück zu meinem Profil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to my Profile','Volver a mi Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to my Profile','Retour Ã  mon profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to my Profile','Torna al mio profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to profile','Zurück zum Profil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to profile','Volver a perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to profile','Retour au profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to profile','Torna al mio profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Back to profile','ZurÃ¼ck zum Profil','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned','Verbannt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned','Excluido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned','Membre banni','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned','Bannato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned','Verbannt','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned','Ð—Ð°Ð±Ð»Ð¾ÐºÐ¸Ñ€Ð¾Ð²Ð°Ð½','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned users','Gesperrte Benuter','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned users','Usuarios excluidos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned users','Utilisateur bloquÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned users','Utenti bannati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Banned users','Zbanowani uÅ¼ytkownicy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse','Durchsuchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse','Navegar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse groups','Buscar grupos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse logged user activities','Benutzeraktivitäten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse logged user activities','Consultar bitácora de actividades del usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse logged user activities','ActivitÃ© des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse logged user activities','Naviga attivitÃ  utenti loggati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse memberships','Mitgliedschaften kaufen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse memberships','Ver membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse memberships','Mitgliedschaften kaufen ??','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse memberships','Naviga iscrizioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user activities','Tätigkeitenhistorie','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user activities','Examinar las actividades del usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user activities','ActivitÃ© de mon compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user activities','Naviga attivitÃ  utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user groups','Benutzergruppen durchsuchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user groups','Buscar grupos de usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user groups','Rechercher dans un grouppe d utilisateurs','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse user groups','Naviga gruppi utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse usergroups','Gruppen durchsuchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse usergroups','Ver Grupos de Usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse usergroups','Rechercher dans les grouppes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse usergroups','Naviga gruppi utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse users','Benutzer durchsuchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse users','Buscar usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse users','Rechercher dans la liste des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Browse users','Naviga utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel','Abbrechen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel','Cancelar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel','Annuler','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel','Cancella','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel deletion','Löschvorgang abbrechen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel deletion','Cancelar eliminación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel deletion','Stopper la suppression','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel deletion','Annulla cancellazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel deletion','Anuluj usuwanie','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel request','Anfrage zurückziehen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel request','Cancelar pedido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel request','Annuler la demande de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel request','Cancella richiesta','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cancel subscription','Mitgliedschaft beenden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Cannot set password. Try again.','No pudimos guardar tu contraseña. Inténtalo otra vez','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Category','Kategorie','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Category','Categor','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change Password','Ð˜Ð·Ð¼ÐµÐ½Ð¸Ñ‚ÑŒ Ð¿Ð°Ñ€Ð¾Ð»ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change admin Password','Administratorpasswort ändern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change admin Password','Cambiar contraseña de Admin','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change admin Password','Changer le mot de passe de l administrateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change admin Password','Modifica password admin','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change admin Password','ZmieÅ„ hasÅ‚o administratora','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change password','Passwort ändern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change password','Cambiar contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change password','Modification du mot de ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change password','Cambia password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Change password','Passwort Ã¤ndern','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes','Änderungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes','Cambios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes','Modification','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes','Modifiche','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes','Zmiany','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes are saved','Änderungen wurden gespeichert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes are saved','Cambios guardados','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes are saved','Les modifications ont bien Ã©tÃ© enregistrÃ©es.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes are saved','Modifiche salvate.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes are saved','Zmiany zostaÅ‚y zapisane.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes is saved.','Änderungen wurde gespeichert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes is saved.','Cambio guardado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes is saved.','Modifications mÃ©morisÃ©es.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes is saved.','Modifiche salvate','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Changes is saved.','Ð˜Ð·Ð¼ÐµÐ½ÐµÐ½Ð¸Ñ ÑÐ¾Ñ…Ñ€Ð°Ð½ÐµÐ½Ñ‹.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Choose All','Alle auswählen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Choose All','Seleccionar todos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Choose All','SÃ©lectioner tout','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Choose All','Scegli tutti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Choose All','Wybierz wszystkie','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('City','Stadt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('City','Ciudad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('City','Ville','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('City','CittÃ ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('City','Miasto','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Click here to respond to {username}','Klicke hier, um {username} zu antworten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Column Field type in the database.','Spaltentyp in der Datenbank','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Column Field type in the database.','Columna tipo de Campo en la base de datos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Column Field type in the database.','Type de la colone dans la banque de donnÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Column Field type in the database.','Tipo di colonna nel database','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Column Field type in the database.','Spaltentyp in der Datenbank','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Comment','Kommentar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Comment','Comentario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Comment','Commentaire','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Comment','Commento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose','Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose','Componer','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose','Ecrire un message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose','Scrivi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose new message','Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose new message','Crear mensaje nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose new message','Ecrire un nouveau message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Compose new message','Scrivi nuovo messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Composing new message','Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Composing new message','Creando mensaje nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Composing new message','Ecrire un nouveau message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Composing new message','Scrittura nuovo messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm','Bestätigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm','Confirmar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm','Confirmer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm','Conferma','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm deletion','Löschvorgang bestätigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm deletion','Confirmar eliminación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm deletion','Confirmation de suppression','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm deletion','Conferma cancellazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirm deletion','PotwierdÅº usuwanie','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirmation pending','Bestätigung ausstehend','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirmation pending','Esperando confirmación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirmation pending','Confirmation en attente','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Confirmation pending','In attesa di conferma','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Content','Inhalt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Content','Contenido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Content','Texte du message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Content','Contenuto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create','Anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create','Crear','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create','CÃ©er','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create','Aggiungi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create','Dodaj','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create','ÐÐ¾Ð²Ñ‹Ð¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Action','Crea azione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Profile Field','Profilfeld anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Profile Field','Crear Campo de Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Profile Field','Nouveau champ de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Profile Field','Aggiungi campo Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Profile Field','Dodaj pole profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Profile Field','Ð”Ð¾Ð±Ð°Ð²Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Role','Rolle anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Role','Crear Rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Role','CrÃ©er un rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Role','Crea ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Role','Dodaj rolÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create User','Benutzer anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create User','Crear Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create User','CrÃ©er un nouvel utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create User','Nuovo utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create User','ÐÐ¾Ð²Ñ‹Ð¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Usergroup','Neue Gruppe erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Usergroup','Crear un grupo de usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create Usergroup','Crea gruppo utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create my profile','Mein Profil anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create my profile','Crear mi perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create my profile','Crea profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new Translation','Neue Übersetzung erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new Translation','Crear nueva traducción','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new User','Neuen Benutzer anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new User','Crear nuevo usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new Usergroup','Neue Gruppe erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new Usergroup','Crear nuevo grupo de usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new action','Neue Aktion','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new action','Crear acción nueva','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new action','Nouvelle action','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new action','Nuova azione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new field group','Neue Feldgruppe erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new field group','Crear campo de grupo nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new field group','CrÃ©er un nouveau champs dans le groupe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new field group','Nuovo campo gruppo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new field group','Dodaj nowÄ… grupÄ™ pÃ³l','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new payment type','Neue Zahlungsart hinzufügen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new payment type','Crear nueva forma de pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new payment type','CrÃ©er un nouveau mode de paiement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new payment type','Nuovo tipo pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new role','Neue Rolle anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new role','Crear rol nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new role','CrÃ©er un nouveau rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new role','Nuovo ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new role','Dodaj nowÄ… rolÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new settings profile','Neues Einstellungsprofil erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new settings profile','Crear ajuste de perfil nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new settings profile','crÃ©er une nouvelle configuration de profil.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new settings profile','Nuova opzion profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new settings profile','Dodaj nowe ustawienia profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new user','Crear usuario nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new user','CrÃ©er un nouveau membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new user','Nuovo utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new user','Dodaj nowego uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new usergroup','Neue Gruppe erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new usergroup','Crear un nuevo grupo de usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new usergroup','CrÃ©er un nouveau grouppe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create new usergroup','Nuovo usergroup','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create payment type','Zahlungsart anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create payment type','Crear el tipo de pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create payment type','Crea tipo pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile field','Ein neues Profilfeld erstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile field','Crear campo de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile field','CrÃ©er un nouveau champ de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile field','Crea campo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile field','Dodaj pole do profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile fields group','Crear grupo de campos de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile fields group','Nuovo gruppo di campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create profile fields group','Dodaj grupÄ™ pÃ³l do profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create role','Neue Rolle anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create role','Crear rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create role','CrÃ©er un nouveau rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create role','Crea ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create role','Dodaj rolÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create user','Benutzer anlegen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create user','Crear usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create user','CrÃ©er un membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create user','Crea utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Create user','Dodaj uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Date','Datum','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Date','Fecha','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Date','Date','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Date','Data','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Date','Data','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Default','Default','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Default','Predeterminado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Default','Default','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Default','Predefinito','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Default','ÐŸÐ¾ ÑƒÐ¼Ð¾Ð»Ñ‡Ð°Ð½Ð¸ÑŽ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete Account','Zugang löschen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete Account','Eliminar Cuenta','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete Account','Supprimer le compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete Account','Cancella account','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete Profile Field','Cancella campo Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete Profile Field','Ð£Ð´Ð°Ð»Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete User','Benutzer löschen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete User','Eliminar Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete User','Supprimer le membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete User','Cancella utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete User','Ð£Ð´Ð°Ð»Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete account','Zugang löschen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete account','Eliminar cuenta','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete account','Supprimer ce compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete account','Cancella account','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete account','UsuÅ„ konto','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete file','Cancella file','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete message','Nachricht löschen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete message','Eliminar mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete message','Supprimer le message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Delete message','Cancella messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deleted','Gelöscht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deleted','Eliminado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deleted','SupprimÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deleted','Cancella','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deny','Ablehnen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deny','Negar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deny','Refuser','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Deny','Vietao','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Description','Beschreibung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Description','Descripción','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Description','Description','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Description','Descrizione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Description','Opis','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different users logged in today','Anzahl der heute angemeldeten Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different users logged in today','Diferentes usuarios iniciaron sesión hoy','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different users logged in today','Nombre d utilisateurs inscrits/connectÃ©s aujourd hui.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different users logged in today','Numero di utenti connessi oggi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different users logged in today','Liczba dzisiejszych unikalnych logowaÅ„','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different viewn Profiles','Insgesamt betrachtete Profile','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different viewn Profiles','Perfiles diferentes vistos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different viewn Profiles','Total des profils consultÃ©s','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Different viewn Profiles','Visualizzazioni profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of fields.','Reihenfolgenposition, in der das Feld angezeigt wird','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of fields.','Mostrar orden de los campos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of fields.','Ordre de position dans laquelle le champ apparaitra','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of fields.','Mostra ordine dei campi.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of fields.','KolejnoÅ›Ä‡ wyÅ›wietlania pÃ³l.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of fields.','ÐŸÐ¾Ñ€ÑÐ´Ð¾Ðº Ð¾Ñ‚Ð¾Ð±Ñ€Ð°Ð¶ÐµÐ½Ð¸Ñ Ð¿Ð¾Ð»ÐµÐ¹.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of group.','Anzeigereihenfolge der Gruppe.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of group.','Mostrar orden del grupo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of group.','Annonces ordonnÃ©es du grouppe.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of group.','Ordine di visualizzazione del gruppo.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Display order of group.','WyÅ›wietl kolejnoÅ›Ä‡ grup.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not appear in search','Nicht in der Suche erscheinen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not appear in search','No aparecer en la b','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not appear in search','Ne pas paraitre dans les rÃ©sultat de recherche','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not appear in search','Non mostrare nelle ricerche','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show my online status','Status verstecken','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show my online status','No mostrar mi estado de conexi','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show my online status','Ne pas rendre mon profil visible lorsque je suis en ligne','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show my online status','Non mostrare il mio stato online','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show the owner of a profile when i visit him','Niemandem zeigen, wen ich besucht habe','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show the owner of a profile when i visit him','No se repite el due','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show the owner of a profile when i visit him','Ne pas montrer les profils que j ai visitÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Do not show the owner of a profile when i visit him','Non mostrare al proprietario quando visito il suo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Downgrade to {role}','Wechsle auf {role}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Duration in days','Gültigkeitsdauer in Tagen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Duration in days','Duraci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Duration in days','ValiditÃ© en jours','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Duration in days','Durata in giorni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-Mail address','E-Mail Adresse','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-Mail address','Correo electrónico','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-Mail address','Adresse e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-Mail address','Indirizzo email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-Mail already in use. If you have not registered before, please contact our System administrator.','Este correo ya está siendo usado por alguien. Si no te habías registrado antes entonces contáctanos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-mail','E-mail','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-mail','Correo electrónico','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-mail','E-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-mail','E-mail','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-mail','Mejl','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('E-mail','Ð­Ð»ÐµÐºÑ‚Ñ€Ð¾Ð½Ð½Ð°Ñ Ð¿Ð¾Ñ‡Ñ‚Ð°','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit','Bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit','Editar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit','Editer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit','Modifica','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit','Bearbeiten','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit','Ð ÐµÐ´Ð°ÐºÑ‚Ð¸Ñ€Ð¾Ð²Ð°Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit personal data','Persönliche Daten bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit personal data','Editar datos personales','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit personal data','Modifier mes donnÃ©es personnelles','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit personal data','Modifica dati personali','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile','Profil bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile','Editar perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile','Editer le profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile','Modifica profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile','Meine Profildaten bearbeiten','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile','Ð ÐµÐ´Ð°ÐºÑ‚Ð¸Ñ€Ð¾Ð²Ð°Ð½Ð¸Ðµ Ð¿Ñ€Ð¾Ñ„Ð¸Ð»Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile field','Profilfeld bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile field','Editar campo del perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile field','Editer les champ du profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile field','Modifica campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit profile field','Profilfeld bearbeiten','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit text','Modifica testo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit this role','Diese Rolle bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit this role','Editar este rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit this role','Modifier ce rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit this role','Modifica questo ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Edit this role','ZmieÅ„ tÄ™ rolÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is incorrect.','E-Mail ist nicht korrekt.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is incorrect.','Email incorrecto','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is incorrect.','L adresse e-mail est incorrecte.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is incorrect.','Email non corretta.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is incorrect.','Mejl jest niepoprawny.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is incorrect.','ÐŸÐ¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÑŒ Ñ Ñ‚Ð°ÐºÐ¸Ð¼ ÑÐ»ÐµÐºÑ‚Ñ€Ð¾Ð½Ñ‹Ð¼ Ð°Ð´Ñ€ÐµÑÐ¾Ð¼ Ð½Ðµ Ð·Ð°Ñ€ÐµÐ³Ð¸ÑÑ‚Ñ€Ð¸Ñ€Ð¾Ð²Ð°Ð½.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Email is not set when trying to send Registration Email','Debes colocar el correo electrónico para enviar el correo de registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Captcha','Captcha Überprüfung aktivieren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Captcha','Habilitar Captcha','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Captcha','Activer le controle par Captcha','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Captcha','Attiva Captcha','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Captcha','WÅ‚Ä…cz Captcha','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Email Activation','Aktivierung per E-Mail einschalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Email Activation','Habilitar Activación por Email','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Email Activation','Activer l activation par e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Email Activation','Attiva attivazione via Email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Email Activation','WÅ‚Ä…cz aktywacjÄ™ mejlem','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Profile History','Profilhistorie einschalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Profile History','Habilitar Historial de Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Profile History','Activer le protocole des profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Profile History','Attiva storico Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Profile History','WÅ‚Ä…cz historiÄ™ profilÃ³w','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Recovery','Wiederherstellung einschalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Recovery','Habilitar Recuperación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Recovery','Activer la restauration','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Recovery','Attiva rispristino','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Recovery','WÅ‚Ä…cz odzyskiwanie haseÅ‚','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Registration','Registrierung einschalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Registration','Habilitar Registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Registration','Activer l enregistrement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Registration','Attiva registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Enable Registration','WÅ‚Ä…cz rejestracjÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('End date','Enddatum','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('End date','Fecha final','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('End date','Data scadenza','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ends at','Endet am','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ends at','Termina en','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ends at','Scade il','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error Message','Fehlermeldung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error Message','Mensaje de Error','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error Message','Message d erreur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error Message','Messaggio d\'errore','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error Message','Ð¡Ð¾Ð¾Ð±Ñ‰ÐµÐ½Ð¸Ðµ Ð¾Ð± Ð¾ÑˆÐ¸Ð±ÐºÐµ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error message when Validation fails.','Fehlermeldung falls die Validierung fehlschlägt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error message when Validation fails.','Mensaje de error cuando la Validación falla','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error message when Validation fails.','Message d erreur pour le cas ou la validation Ã©choue','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error message when Validation fails.','Messaggio d\'errore se fallisce la validazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error message when you validate the form.','Messaggio d\'errore durante la validazione del form.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error message when you validate the form.','Ð¡Ð¾Ð¾Ð±Ñ‰ÐµÐ½Ð¸Ðµ Ð¾Ð± Ð¾ÑˆÐ¸Ð±ÐºÐµ Ð¿Ñ€Ð¸ Ð¿Ñ€Ð¾Ð²ÐµÑ€ÐºÐµ Ñ„Ð¾Ñ€Ð¼Ñ‹.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error while processing new avatar image : {error_message}; File was uploaded without resizing','Das Bild konnte nicht richtig skaliert werden: {error_message}. Es wurde trotzdem erfolgreich hochgeladen und in ihrem Profil aktiviert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error while processing new avatar image : {error_message}; File was uploaded without resizing','Error al procesar la imagen nuevo avatar: {mensaje_error}; El archivo se ha subido sin cambiar el tama','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error while processing new avatar image : {error_message}; File was uploaded without resizing','L image n a pas pu Ãªtre retaillÃ©e automatiquement lors du chargement. : {error_message}. elle a Ã©tÃ© cependant chargÃ©e avec succÃ¨s et activÃ©e dans votre profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Error while processing new avatar image : {error_message}; File was uploaded without resizing','Errore processando il nuovo avatar: {error_message}. File caricato senza ridimensionamento.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Expired','Abgelaufen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Expired','Caducado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field','Feld','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field','Campo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field','Champ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field','Campo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field','Pole','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size','Feldgröße','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size','Tamaño del Campo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size','Longueur du champ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size','Dimensione campo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size','Ð Ð°Ð·Ð¼ÐµÑ€ Ð¿Ð¾Ð»Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size min','min Feldgröße','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size min','Tamaño mínimo del campo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size min','longueur du champ minimum','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size min','Dimesione minima campo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Size min','ÐœÐ¸Ð½Ð¸Ð¼Ð°Ð»ÑŒÐ½Ð¾Ðµ Ð·Ð½Ð°Ñ‡ÐµÐ½Ð¸Ðµ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Type','Feldtyp','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Type','Tipo de Campo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Type','Type du champ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Type','Tipo campo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field Type','Ð¢Ð¸Ð¿ Ð¿Ð¾Ð»Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field group','Feldgruppe','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field group','Grupo de Campos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field group','Champ des groupes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field group','Campi gruppo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field group','Grupa pÃ³l','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field name on the language of \"sourceLanguage\".','Feldname in der Ursprungssprache','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field name on the language of \"sourceLanguage\".','Nombre del campo en el idioma \"sourceLanguage\".','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field name on the language of \"sourceLanguage\".','Non du champ dans la langue standard','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field name on the language of \"sourceLanguage\".','Nome campo per il linguaggio di \"sourceLanguage\".','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field name on the language of \"sourceLanguage\".','Feldname in der Ursprungssprache','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field name on the language of \"sourceLanguage\".','ÐÐ°Ð·Ð²Ð°Ð½Ð¸Ðµ Ð¿Ð¾Ð»Ñ Ð½Ð° ÑÐ·Ñ‹ÐºÐµ \"sourceLanguage\".','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size','Feldgröße','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size','Tamaño del campo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size','Longueur du champ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size','Dimensione campo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size','FeldgrÃ¶ÃŸe','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size column in the database.','Dimensione campo nel database','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size column in the database.','Ð Ð°Ð·Ð¼ÐµÑ€ Ð¿Ð¾Ð»Ñ ÐºÐ¾Ð»Ð¾Ð½ÐºÐ¸ Ð² Ð±Ð°Ð·Ðµ Ð´Ð°Ð½Ð½Ñ‹Ñ…','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size in the database.','Feldgröße in der Datenbank','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size in the database.','Tamaño del campo en la base de datos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size in the database.','Longueur du champ dans la banque de donnÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size in the database.','Dimensione campo nel database','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field size in the database.','FeldgrÃ¶ÃŸe in der Datenbank','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type','Feldtyp','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type','Tipo de campo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type','Type de champ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type','Tipo campo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type','Feldtyp','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type column in the database.','Tipo campo nel database.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Field type column in the database.','Ð¢Ð¸Ð¿ Ð¿Ð¾Ð»Ñ ÐºÐ¾Ð»Ð¾Ð½ÐºÐ¸ Ð² Ð±Ð°Ð·Ðµ Ð´Ð°Ð½Ð½Ñ‹Ñ….','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Fields with * are required.','Los campos con * son obligatorios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Fields with <span class=\"required\">*</span> are required.','Felder mit <span class=\"required\">*</span> sind Pflichtfelder.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First Name','Nome','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First Name','Ð˜Ð¼Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First name','Vorname','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First name','Nombre','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First name','PrÃ©nom','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First name','Cognome','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('First name','Vorname','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('For all','Für alle','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('For all','Para todos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('For all','Pour tous','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('For all','Per tutti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('For all','Ð”Ð»Ñ Ð²ÑÐµÑ…','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Form validation error','Error en la validación del formulario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends','Kontakte','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends','Amigos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends','Mes contacts','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends','Contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends of {username}','Kontakte von {username}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends of {username}','Amigos de {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends of {username}','Contact de {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friends of {username}','Contatti di {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship','Kontakt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship','Amistades','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship','Contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship','Contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship confirmed','Freundschaft bestätigt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship confirmed','Amistad confirmada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship confirmed','Demande de contact confirmÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship confirmed','Contatto confermato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship rejected','Kontaktanfrage abgelehnt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship rejected','La amistad rechazada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship rejected','Demande de contact refusÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship rejected','Amizicia rigettata','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request already sent','Kontaktbestätigung ausstehend','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request already sent','Ya se envió la solicitud de amistad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request already sent','En attente de confirmation','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request already sent','Richiesta di contatto giÃ  inviata','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request for {username} has been sent','Kontaktanfrage an {username} gesendet','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request for {username} has been sent','La solicitud de amistad a {username} ha sido enviada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request for {username} has been sent','Demande de contact envoyÃ©e Ã  {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request for {username} has been sent','Inviata richiesta di contatto a {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request has been rejected','Kontaktanfrage zurückgewiesen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request has been rejected','Solicitud de amistad rechazada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request has been rejected','Votre demande de contact a Ã©tÃ© rejetÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Friendship request has been rejected','Richiesta di contatto respinta','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('From','Von','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('From','Desde','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('From','De','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('From','Da','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('From','Od','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('General','Allgemein','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('General',' General ','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('General','Generale','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Generate Demo Data','Zufallsbenutzer erzeugen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Generate Demo Data','Genera datos de prueba','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Generate Demo Data','GÃ©nÃ©rer un compte membre-dÃ©mo','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Generate Demo Data','Genera dati demo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Go to profile of {username}','Zum Profil von {username}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Go to profile of {username}','Ir al perfil de {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Go to profile of {username}','Voir le profil de {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Go to profile of {username}','Vai al profilo di {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Grant permission','Berechtigung zuweisen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Grant permission','Otorgar permiso','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Grant permission','Attribuer une permission ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Grant permission','Assegna permesso','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group Name','Gruppenname','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group Name','Nombre de grupo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group Name','Nom du groupe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group Name','Nome gruppo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group Name','Nazwa grupy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group name on the language of \"sourceLanguage\".','Gruppenname in der Basissprache.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group name on the language of \"sourceLanguage\".','Nombre del grupo en el idioma \"sourceLanguage\".','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group name on the language of \"sourceLanguage\".','Nom du groupe dans la langue principale.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group name on the language of \"sourceLanguage\".','Il nome del gruppo nella lingua di base.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group name on the language of \"sourceLanguage\".','Nazwa grupy w jÄ™zyku uÅ¼ytkownika.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group owner','Gruppeneigentümer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group owner','Dueño del grupo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group owner','PropriÃ©taire du grouppe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group owner','Proprietario gruppo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group title','Titel der Gruppe','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group title','Título del grupo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group title','Titre du grouppe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Group title','Titolo gruppo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Having','Anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Having','Teniendo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Having','Annonce','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Having','Visualizza','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Hidden','Verstecken','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Hidden','Escondido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Hidden','CachÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Hidden','Nascosto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Hidden','Ð¡ÐºÑ€Ñ‹Ñ‚','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How expensive is a membership?','Preis der Mitgliedschaft','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How expensive is a membership?','','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How expensive is a membership?','Prix de l abbonement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How expensive is a membership?','Quanto costa l\'iscrizione?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How many days will the membership be valid after payment?','Wie viele Tage ist die Mitgliedschaft nach Zahlungseingang gültig?','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How many days will the membership be valid after payment?','','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How many days will the membership be valid after payment?','Nombre de jours pour la validitÃ© d un abbonement aprÃ¨s paiement?','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('How many days will the membership be valid after payment?','Quanti giorni Ã¨ valida l\'iscrizione dopo il pagamento?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignore','Ignorieren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignore','Ignorar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignore','Ignorer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignore','Ignora','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignored users','Ignorierliste','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignored users','Usuarios ignorados','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignored users','Liste noire','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ignored users','Utenti ignorati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Inactive users','Inaktive Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Inactive users','Usuarios inactivos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Inactive users','Utilisateur inactif','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Inactive users','Utenti inattivi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Inactive users','Nieaktywni uÅ¼ytkownicy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL','El enlace de activación que usaste es incorrecto','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL.','Falsche Aktivierungs URL.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL.','URL de activación incorrecta.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL.','Le lien d activation de votre compte est incorrect ou pÃ©rimÃ©. Consultez notre FAQ: mot clÃ©= inscription ou contactez gratuitement notre Help-Center en ligne sur la page d aide.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL.','URL di attivazione incorretto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL.','Falsche Aktivierungs URL.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect activation URL.','ÐÐµÐ¿Ñ€Ð°Ð²Ð¸Ð»ÑŒÐ½Ð°Ñ ÑÑÑ‹Ð»ÐºÐ° Ð°ÐºÑ‚Ð¸Ð²Ð°Ñ†Ð¸Ð¸ ÑƒÑ‡ÐµÑ‚Ð½Ð¾Ð¹ Ð·Ð°Ð¿Ð¸ÑÐ¸.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect password (minimal length 4 symbols).','Falsches Passwort (minimale Länge 4 Zeichen).','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect password (minimal length 4 symbols).','Contraseña incorrecta (debe tener mínimo 4 caracteres).','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect password (minimal length 4 symbols).','Mot de passe incorrect (longueur minimal de 4 charactÃ¨res).','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect password (minimal length 4 symbols).','Password sbagliata (lunga almeno 4 caratteri).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect password (minimal length 4 symbols).','Falsches Passwort (minimale LÃ¤nge 4 Zeichen).','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect password (minimal length 4 symbols).','ÐœÐ¸Ð½Ð¸Ð¼Ð°Ð»ÑŒÐ½Ð°Ñ Ð´Ð»Ð¸Ð½Ð° Ð¿Ð°Ñ€Ð¾Ð»Ñ 4 ÑÐ¸Ð¼Ð²Ð¾Ð»Ð°.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect recovery link.','Recovery link ist falsch.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect recovery link.','Enlace de recuperación que usaste es incorrecto','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect recovery link.','Le lien de restauration est incorrect ou pÃ©rimÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect recovery link.','Link ripristino incorretto.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect recovery link.','Recovery link ist falsch.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect recovery link.','ÐÐµÐ¿Ñ€Ð°Ð²Ð¸Ð»ÑŒÐ½Ð°Ñ ÑÑÑ‹Ð»ÐºÐ° Ð²Ð¾ÑÑ‚Ð°Ð½Ð¾Ð²Ð»ÐµÐ½Ð¸Ñ Ð¿Ð°Ñ€Ð¾Ð»Ñ.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect symbol\'s. (A-z0-9)','Im Benutzernamen sind nur Buchstaben und Zahlen erlaubt.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect symbol\'s. (A-z0-9)','Caracteres incorrectos. (A-z0-9)','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect symbol\'s. (A-z0-9)','Pour le choix de votre nom d utilisateur seules les lettres de l alphabet et les chiffres sont acceptÃ©s .','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect symbol\'s. (A-z0-9)','Sono consentiti solo lettere e numeri','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect symbol\'s. (A-z0-9)','Im Benutzernamen sind nur Buchstaben und Zahlen erlaubt.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect symbol\'s. (A-z0-9)','Ð’ Ð¸Ð¼ÐµÐ½Ð¸ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ Ð´Ð¾Ð¿ÑƒÑÐºÐ°ÑŽÑ‚ÑÑ Ñ‚Ð¾Ð»ÑŒÐºÐ¾ Ð»Ð°Ñ‚Ð¸Ð½ÑÐºÐ¸Ðµ Ð±ÑƒÐºÐ²Ñ‹ Ð¸ Ñ†Ð¸Ñ„Ñ€Ñ‹.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect username (length between 3 and 20 characters).','Falscher Benutzername (Länge zwischen 3 und 20 Zeichen).','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect username (length between 3 and 20 characters).','Nombre de usuario incorrecto (debe tener longitud entre 3 y 20 caracteres)','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect username (length between 3 and 20 characters).','Nom d utilisateur incorrect (Longueur comprise entre 3 et 20 charactÃ¨res).','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect username (length between 3 and 20 characters).','Username errato (lunghezza tra i 3 e i 20 caratteri).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect username (length between 3 and 20 characters).','Falscher Benutzername (LÃ¤nge zwischen 3 und 20 Zeichen).','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Incorrect username (length between 3 and 20 characters).','Ð”Ð»Ð¸Ð½Ð° Ð¸Ð¼ÐµÐ½Ð¸ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ Ð¾Ñ‚ 3 Ð´Ð¾ 20 ÑÐ¸Ð¼Ð²Ð¾Ð»Ð¾Ð².','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Instructions have been sent to you. Please check your email.','Weitere Anweisungen wurden an ihr E-Mail Postfach geschickt. Bitte prüfen Sie ihre E-Mails','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Instructions have been sent to you. Please check your email.','Se enviarion instrucciones a tu correo. Por favor, ve tu cuenta de correo.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Instructions have been sent to you. Please check your email.','Merci pour votre inscription.Controlez votre boite e-mail, le code d activation de votre compte vous a Ã©tÃ© envoyÃ© par e-mail. *IMPORTANT:pour le cas ou notre e-mail ne vous serais pas parvenu, il est possible que notre e-mail ai Ã©tÃ© filtrÃ© par votre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Instructions have been sent to you. Please check your email.','Istruzioni inviate per email. Controlla la tua casella di posta elettronica.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Invalid recovery key','Fehlerhafter Wiederherstellungsschlüssel','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Invalid recovery key','Clave de recuperaci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Invitation','Einladung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Invitation','Invitaciones','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Invitation','Invitation','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Invitation','Invito','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Is membership possible','Mitgliedschaft möglich?','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Is membership possible','','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Is membership possible','Inscription possible?','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Is membership possible','Iscrizione possibile?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Join group','Beitreten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Join group','Unirse al grupo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Join group','Collega al gruppo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Jump to profile','Zum Profil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Jump to profile','Ir al perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Jump to profile','Consulter le profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Jump to profile','Vai al profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Language','Sprache','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Language','Idioma','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Language','	Langue','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Language','Lingua','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last Name','Cognome','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last Name','Ð¤Ð°Ð¼Ð¸Ð»Ð¸Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last name','Nachname','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last name','Apellido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last name','Nom de famille','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last name','Nome','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last name','Nachname','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last visit','Letzter Besuch','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last visit','òltima visita','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last visit','DernÃ¨re visite','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last visit','Ultima visita','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last visit','Letzter Besuch','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Last visit','ÐŸÐ¾ÑÐ»ÐµÐ´Ð½Ð¸Ð¹ Ð²Ð¸Ð·Ð¸Ñ‚','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Leave group','Gruppe verlassen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let me appear in the search','Ich möchte in der Suche erscheinen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let me appear in the search','Perm','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let me appear in the search','Je ne souhaite pas apparaitre dans les rÃ©sultats des moteurs de recherche','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let me appear in the search','Mostrami nei risultati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let the user choose in privacy settings','Den Benutzer entscheiden lassen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let the user choose in privacy settings','Permita que el usuario elija en la configuraci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let the user choose in privacy settings','Laisser l utilisateur choisir lui-mÃªme','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Let the user choose in privacy settings','Consentire all\'utente di scegliere le impostazioni della privacy','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Letters are not case-sensitive.','Zwischen Groß-und Kleinschreibung wird nicht unterschieden.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Letters are not case-sensitive.','Las letras nos son sensibles a mayúsculas y minúsculas.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Letters are not case-sensitive.','Aucune importance ne sera apportÃ©e aux minuscules ou majuscules.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Letters are not case-sensitive.','La ricerca non Ã¨ case sensitive.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Letters are not case-sensitive.','Zwischen GroÃŸ-und Kleinschreibung wird nicht unterschieden.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Letters are not case-sensitive.','Ð ÐµÐ³Ð¸ÑÑ‚Ñ€ Ð·Ð½Ð°Ñ‡ÐµÐ½Ð¸Ðµ Ð½Ðµ Ð¸Ð¼ÐµÐµÑ‚.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List Profile Field','Lista campi Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List Profile Field','Ð¡Ð¿Ð¸ÑÐ¾Ðº','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List User','Lista utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List User','Ð¡Ð¿Ð¸ÑÐ¾Ðº Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÐµÐ¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List roles','Rollen anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List roles','Listar roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List roles','liste des rÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List roles','Lista ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List roles','Lista rÃ³l','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List user','Benutzer auflisten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List user','Listar usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List user','Liste complÃ¨tes des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List user','Lista utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List user','Benutzer auflisten','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List users','Benutzer anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List users','Listar usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List users','Liste des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List users','Lista utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('List users','Lista uÅ¼ytkownikÃ³w','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Log profile visits','Meine Profilbesuche anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Log profile visits','Registrarse visitas al perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Log profile visits','Voir les statistiques des visiteurs de mon profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Log profile visits','Log visite profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logged in as','Angemeldet als','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logged in as','Conectado como','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logged in as','ConnectÃ© en tant que','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logged in as','Loggato come','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login','Anmeldung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login','Iniciar sesión','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login','Inscription','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login','Entra','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login','Logowanie','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login','Ð’Ñ…Ð¾Ð´','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login Type','Anmeldungsart','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login Type','Tipo de inicio de sesión','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login Type','Mode de connection','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login Type','Tipo login','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login Type','Rodzaj logowania','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed by Email and Username','Anmeldung per Benutzername oder E-Mail adresse','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed by Email and Username','Inicio de sesión por Email y Nombre de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed by Email and Username','Connection avec le nom d utilisateur ou adresse e-mail.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed by Email and Username','Login con il nome utente o l\'indirizzo e-mail','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed by Email and Username','Logowanie przez nazwÄ™ lub mejl','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Email','Anmeldung nur per E-Mail adresse','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Email','Inicio de sesión sólo por Email','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Email','COnnection avec l adresse e-mail seulement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Email','Login solo tramite email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Email','Logowanie poprzez mejl','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Username','Anmeldung nur per Benutzername','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Username','Inicio de sesión sólo por Nombre de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Username','Connection avec le nom d utilisateur seulement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Username','Login solo tramite username','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login allowed only by Username','Logowanie poprzez nazwÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login is not possible with the given credentials','Anmeldung mit den angegebenen Werten nicht möglich','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Login is not possible with the given credentials','Inicio de sesi','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logout','Abmelden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logout','Cerrar sesión','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logout','DÃ©connection','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logout','Esci','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logout','Wyloguj','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Logout','Ð’Ñ‹Ð¹Ñ‚Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost Password?','Password dimenticata?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost Password?','Ð—Ð°Ð±Ñ‹Ð»Ð¸ Ð¿Ð°Ñ€Ð¾Ð»ÑŒ?','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost password?','Passwort vergessen?','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost password?','¿Olvidó la contraseña?','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost password?','Mot de passe oubliÃ©?','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost password?','Password dimenticata?','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Lost password?','Passwort vergessen?','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mail send method','Nachrichtenversandmethode','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mail send method','Método de envío de correo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mail send method','Mode d envoie des messages','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mail send method','Metodo invio mail','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mail send method','Metoda wysyÅ‚ania mejli','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Make {field} public available','Das Feld {field} öffentlich machen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Make {field} public available','Haga {field} disponible al p','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Make {field} public available','Rendre publique le champ {field}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Make {field} public available','Rendi pubblico il campo {field}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage','Verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage','Administrar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage','Gestion','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage','Gestione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage','Ð£Ð¿Ñ€Ð°Ð²Ð»ÐµÐ½Ð¸Ðµ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Actions','Gestione azioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Field','Profilfeld verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Field','Administrar Campos de Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Field','GÃ©rer le champ de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Field','Gestione campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Field','ZarzÄ…dzaj polem profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Field','ÐÐ°ÑÑ‚Ñ€Ð¾Ð¹ÐºÐ° Ð¿Ð¾Ð»ÐµÐ¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Fields','Profilfelder verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Fields','Administrar Campos de Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Fields','GÃ©rer les champs de profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Fields','Gestione campi Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Fields','ZarzÄ…dzaj polami profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profile Fields','ÐÐ°ÑÑ‚Ñ€Ð¾Ð¹ÐºÐ° Ð¿Ð¾Ð»ÐµÐ¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profiles','Profile verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profiles','Administrar Perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profiles','GÃ©rer les profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Profiles','Gestione profili','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Roles','Rollenverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Roles','Administrar Roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Roles','Gestion des rÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Roles','Gestione Ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Roles','ZarzÄ…dzaj rolami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage User','Benutzerverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage User','Administrar Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage User','Gestion utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage User','Gestione utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage User','Benutzerverwaltung','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage User','Ð£Ð¿Ñ€Ð°Ð²Ð»ÐµÐ½Ð¸Ðµ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÑÐ¼Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Users','Benutzerverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Users','Administrar Usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Users','Gestion des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage Users','Gestione utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage field groups','Feldgruppen verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage field groups','Administrar grupos de campos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage field groups','GÃ©rer les champs des groupes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage field groups','Gestione campo gruppi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage field groups','ZarzÄ…dzaj grupami pÃ³l','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage friends','Freundschaftsverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage friends','Administrar amigos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage friends','Gestion des contacts','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage friends','Gestione contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage my users','Meine Benutzer verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage my users','Administrar mis usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage my users','GÃ©rer mes membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage my users','Gestione utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage my users','ZarzÄ…dzaj moimi uÅ¼ytkownikami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage payments','Zahlungsarten verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage payments','Gesti','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage payments','Gestione pagamenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage permissions','Berechtigungen verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage permissions','Administrar los permisos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage permissions','Gestione permessi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile Fields','Profilfelder verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile Fields','Administrar Campos de Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile Fields','GÃ©rer les champs du profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile Fields','Gestione campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile Fields','Profilfelder verwalten','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile field groups','Administrar grupos de campos de perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile field groups','GÃ©rer les champs des profils de grouppes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile field groups','Gestione campo profilo gruppi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile field groups','ZarzÄ…dzaj grupami pÃ³l w profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields','Profilfelder verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields','Gesti','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields','GÃ©rer les champs de profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields','Gestione campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields','ZarzÄ…dzaj polami profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields groups','Gestione campi profilo gruppi ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profile fields groups','ZarzÄ…dzaj grupami pÃ³l w profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profiles','Profile verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profiles','Administrar perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profiles','GÃ©rer les profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profiles','Gestione profili','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage profiles','ZarzÄ…dzaj profilem','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage roles','Rollen verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage roles','Adminsitrar roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage roles','GÃ©rer les rÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage roles','Gestione Ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage roles','ZarzÄ…dzaj rolami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage text settings','Texteinstellungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage text settings','Administrar configuración de texto','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage text settings','Option de texte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage text settings','Impostazioni di testo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage this profile','dieses Profil bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage this profile','Administrar este perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage this profile','Modifier ce profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage this profile','Modifica profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage this profile','ZarzÄ…dzaj tym profilem','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage user Groups','Benutzergruppen verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage user Groups','Administrar Grupos de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage user Groups','Gerer les utilisateurs des grouppes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage user Groups','Gestine gruppi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage users','Benutzer verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage users','Administrar usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage users','GÃ©rer les membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage users','Gestione utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Manage users','ZarzÄ…dzaj uÅ¼ytkownikaki','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mange Profile Field','Mange Profil Field','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mange Profile Field','Administrar Campo del Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mange Profile Field','Gestione campo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mark as read','Als gelesen markieren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mark as read','Marcar como le','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mark as read','Marquer comme lu','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Mark as read','Segna come letto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Match','Treffer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Match','Combinar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Match','RÃ©sultat','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Match','Corrispondenza (RegExp)','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Match','Ð¡Ð¾Ð²Ð¿Ð°Ð´ÐµÐ½Ð¸Ðµ (RegExp)','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership','Mitgliedschaft','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership','Membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership','Devenir membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership','Iscrizione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership ends at: {date}','Mitgliedschaft endet am: {date}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership ends at: {date}','Membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership ends at: {date}','Iscrizione termina il: {date}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership has not been payed yet','Zahlungseingang noch nicht erfolgt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership has not been payed yet','La membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership has not been payed yet','Iscrizione non pagata','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership payed at: {date}','Zahlungseingang erfolgt am: {date}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership payed at: {date}','Membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Membership payed at: {date}','Iscrizione pagata il: {date}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Memberships','Mitgliedschaften','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Memberships','Membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Memberships','Iscrizioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message','Nachricht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message','Mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message','Message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message','Messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" has been sent to {to}','Nachricht \"{message}\" wurde an {to} gesendet','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" has been sent to {to}','Mensaje \"{message}\" ha sido enviada a {to}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" has been sent to {to}','Message \"{message}\" a Ã©tÃ© envoyÃ© {to} ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" has been sent to {to}','Messaggio \"{message}\" Ã¨ stato inviato a {to}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" was marked as read','Nachricht \"{message}\" wurde als gelesen markiert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" was marked as read','Mensaje \"{message}\" se ha marcado como le','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" was marked as read','Message \"{message}\" marquer comme lu.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message \"{message}\" was marked as read','Messaggio \"{message}\" Ã¨ stato contrassegnato come letto.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message count','Anzahl Nachrichten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message count','Recuento de mensajes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from','Nachricht von','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from','Mensaje del','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from','Message de','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from','Messaggio da','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from ','Nachricht von ','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from ','Mensaje de','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from ','Message de ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from ','Messaggio da ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Message from ','Nachricht von ','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messages','Nachrichten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messages','Mensajes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messages','Message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messages','Messagi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messages','WiadomoÅ›ci','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messaging system','Nachrichtensystem','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messaging system','Sistema de mensajes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messaging system','Message-Board','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messaging system','Sistema messaggistica','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Messaging system','System wiadomoÅ›ci','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Minimal password length 4 symbols.','Minimale Länge des Passworts 4 Zeichen.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Minimal password length 4 symbols.','Mínimo 4 caracteres para la contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Minimal password length 4 symbols.','La longueur de votre mot de passe doit comporter au moins quatre charactÃ¨res.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Minimal password length 4 symbols.','Lunghezza minima password di 4 caratteri.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Minimal password length 4 symbols.','Minimale LÃ¤nge des Passworts 4 Zeichen.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Minimal password length 4 symbols.','ÐœÐ¸Ð½Ð¸Ð¼Ð°Ð»ÑŒÐ½Ð°Ñ Ð´Ð»Ð¸Ð½Ð° Ð¿Ð°Ñ€Ð¾Ð»Ñ 4 ÑÐ¸Ð¼Ð²Ð¾Ð»Ð°.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module settings','Moduleinstellungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module settings','Ajustes del módulo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module settings','RÃ©glage des modules','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module settings','Opzioni modulo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module settings','Ustawienia moduÅ‚u','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module text settings','Ajustes de texto del módulo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module text settings','Opzioni testo modulo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Module text settings','Ustawienia tekstÃ³w moduÅ‚u','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My Inbox','Posteingang','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My Inbox','Mi bandeja de entrada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My Inbox','Boite e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My Inbox','Moja skrzynka odbiorcza','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My friends','Meine Kontakte','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My friends','Mis amigos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My friends','Mes contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My friends','Contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My groups','Meine Gruppen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My groups','Mis grupos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My groups','Mes grouppes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My groups','Gruppi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My inbox','Mein Posteingang','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My inbox','Mi bandeja de entrada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My inbox','Ma boite e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My inbox','Posta in arrivo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My memberships','Meine Mitgliedschaften','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My memberships','Mis membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My memberships','Options de mon compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My memberships','Iscrizioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My profile','Mein Profil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My profile','Mi perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My profile','Mon profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('My profile','Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship request','nueva solicitud de amistad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship request from {username}','neue Kontaktanfrage von {username}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship request from {username}','Nueva solicitud de amistad de {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship request from {username}','Nouvelle demande de contact de {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship request from {username}','Nuova richiesta di contatto da {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship requests','Neue Freundschaftsanfragen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship requests','Nueva solicitud de amistad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship requests','Nouvelle demande de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New friendship requests','Nuova richiesta contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New message from {from}: {subject}','Neue Nachricht von {from}: {subject}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New messages','Neue Nachrichten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New messages','Nuevos mensajes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New messages','Nouveaux mÃ©ssages','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New messages','Nuovo messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password','Neues Passwort','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password','Nueva contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password','Nouveau mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password','Nuovo Password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password is saved.','Neues Passwort wird gespeichert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password is saved.','La contraseña nueva ha sido guardada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password is saved.','Votre nouveau mot de passe a bien Ã©tÃ© mÃ©morisÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password is saved.','Nuova passowrd salvata','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password is saved.','Neues Passwort wird gespeichert.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New password is saved.','ÐÐ¾Ð²Ñ‹Ð¹ Ð¿Ð°Ñ€Ð¾Ð»ÑŒ ÑÐ¾Ñ…Ñ€Ð°Ð½ÐµÐ½.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New profile comment','Nuevo comentario de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New profile comment from {username}','Neuer Profilkommentar von {username}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New profile comment from {username}','Comentario nuevo tu perfil de {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New profile comment from {username}','Nouveau commentaire pour le profil de {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New profile comment from {username}','Nuovo commento per il profilo {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New settings profile','Neues Einstellungsprofil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New settings profile','Nuevos ajustes de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New settings profile','Nouvelle configuration de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New settings profile','Nuova preferenze profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New settings profile','Nowe ustawienia profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New translation','Neue Übersetzung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New translation','Nueva traducción','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New value','Neuer Wert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New value','Valor nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New value','Nouvelle valeur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New value','Nuovo valore','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('New value','Nowa wartoÅ›Ä‡','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No','Nein','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No','No','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No','Non','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No','No','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No','Nein','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No','ÐÐµÑ‚','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No friendship requested','Keine Freundschaft angefragt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No friendship requested','No hay solicitud de amistad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No friendship requested','Pas de demande de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No friendship requested','Contatto non richiesto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No new messages','Keine neuen Nachrichten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No new messages','No hay mensajes nuevos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No new messages','Pas de nouveaux mÃ©ssages','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No new messages','Nessun nuovo messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No profile changes were made','Keine Profiländerungen stattgefunden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No profile changes were made','No se hicieron cambios en el perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No profile changes were made','pas de rÃ©sultat pour les profils modifiÃ©s','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No profile changes were made','Nessun cambiamento al profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No profile changes were made','Nie dokonano zmian w profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No, but show on registration form','Ja, und auf Registrierungsseite anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No, but show on registration form','No, pero mostrar en formulario de registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No, but show on registration form','non et charger le formulaire d inscription','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No, but show on registration form','No, ma mostra nel form di registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No, but show on registration form','Nie, ale pokaÅ¼ w formularzu rejestracji','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('No, but show on registration form','ÐÐµÑ‚, Ð½Ð¾ Ð¿Ð¾ÐºÐ°Ð·Ð°Ñ‚ÑŒ Ð¿Ñ€Ð¸ Ñ€ÐµÐ³Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has commented your profile yet','Bisher hat niemand mein Profil kommentiert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has commented your profile yet','Nadie ha comentado el perfil a','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has commented your profile yet','Aucun commentaire pour votre profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has commented your profile yet','Nessuno ha commentato il tuo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has visited your profile yet','Bisher hat noch niemand ihr Profil angesehen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has visited your profile yet','Nadie ha visitado tu perfil todavía','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has visited your profile yet','Aucune visite rÃ©cente de votre profil.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Nobody has visited your profile yet','Fino ad ora nessuno ha visto il tuo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('None','Keine','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('None','Ninguno','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('None','Aucun','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('None','Nessuno','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('None','Å»aden','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not active','Nicht aktiv','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not active','Innactivo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not active','Non actif','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not active','Non attivo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not active','Nicht aktiv','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not active','ÐÐµ Ð°ÐºÑ‚Ð¸Ð²Ð¸Ñ€Ð¾Ð²Ð°Ð½','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not assigned','Nicht zugewiesen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not assigned','No asignado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not assigned','Non assignÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not assigned','Non assegnato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not assigned','Nie przypisano','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not visited','Non visitato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not yet payed','Noch nicht bezahlt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Not yet payed','Todav','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ok','Ok','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ok','Aceptar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ok','Ok','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ok','Ok','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ok','Ok','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ok','Ok','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Old value','Alter Wert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Old value','Valor antiguo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Old value','Ancienne valeur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Old value','Vecchio valore','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Old value','Stara wartoÅ›Ä‡','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('One of the recipients ({username}) has ignored you. Message will not be sent!','Einer der gewählten Benutzer ({username}) hat Sie auf seiner Ignorier-Liste. Die Nachricht wird nicht gesendet!','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('One of the recipients ({username}) has ignored you. Message will not be sent!','Uno de los destinatarios ({username}) te ha ignorado. ¡No se enviará el mensaje!','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('One of the recipients ({username}) has ignored you. Message will not be sent!','Un des membres sÃ©lectionnÃ© vous a mis sur sa liste noire ({username}). Ce message ne sera pas envoyÃ©!','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('One of the recipients ({username}) has ignored you. Message will not be sent!','Un destinatario ({username}) ti ha inserito nella lista degli ignorati. Messaggio non inviato!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only owner','Nur Besitzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only owner','Sólo el dueño','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only owner','PropriÃ©taire seulement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only owner','Solo proprietario','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only owner','Ð¢Ð¾Ð»ÑŒÐºÐ¾ Ð²Ð»Ð°Ð´ÐµÐ»ÐµÑ†','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only your friends are shown here','Nur ihre Kontakte werden hier angezeigt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only your friends are shown here','S','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only your friends are shown here','Seuls vos contacts seront visibles ici','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Only your friends are shown here','Solo i tuoi contatti verranno visualizzati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order confirmed','Bestellbestätigung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order confirmed','Orden confirmada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order confirmed','Ordini confermati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order date','Bestelldatum','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order date','Fecha de pedido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order date','Data ordine','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order membership','Mitgliedschaft bestellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order membership','Pedido de miembro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order membership','Ordine iscrizione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order number','Bestellnummer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order number','N','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Order number','Numero ordine','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered at','Bestellt am','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered at','Pedido en','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered at','Ordinato il','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered memberships','Bestellte Mitgliedschaften','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered memberships','Pedido de membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered memberships','Options complÃ©mentaires','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Ordered memberships','Iscrizioni ordinate','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other','Verschiedenes','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other','Otro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other','Divers','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other','Altro','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other','PozostaÅ‚e','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other Validator','Otro validador','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other Validator','Autre validation','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other Validator','Altro validatore','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Other Validator','Ð”Ñ€ÑƒÐ³Ð¾Ð¹ Ð²Ð°Ð»Ð¸Ð´Ð°Ñ‚Ð¾Ñ€','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Participant count','Anzahl Teilnehmer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Participant count','N','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Participants','Teilnehmer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Participants','Participantes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Participants','Partecipanti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password','Passwort','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password','Contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password','Passwort','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password','Password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password','HasÅ‚o','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password Expiration Time','Ablaufzeit von Passwörtern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password Expiration Time','Tiempo de expiración de la contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password Expiration Time','DurÃ©e de vie des mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password Expiration Time','Scadenza password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password Expiration Time','Czas waÅ¼noÅ›ci hasÅ‚a','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password is incorrect.','Passwort ist falsch.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password is incorrect.','Contraseña incorrecta','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password is incorrect.','Le mot de passe est incorrect.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password is incorrect.','Password incorretta','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password is incorrect.','Niepoprawne hasÅ‚o.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password is incorrect.','ÐÐµÐ²ÐµÑ€Ð½Ñ‹Ð¹ Ð¿Ð°Ñ€Ð¾Ð»ÑŒ.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password recovery','Passwort wiederherstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Password recovery','Recuperación de contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Passwords do not match','Las contraseñas no coinciden','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment','Zahlungsmethode','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment','Pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment','Pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment arrived','Zahlungseingang bestätigt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment arrived','El pago lleg','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment arrived','Pagamento arrivato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment date','Bezahlt am','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment date','Fecha de pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment date','Data pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment type','Zahlungstyp','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment types','Zahlungsarten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment types','Formas de pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment types','Options de paiement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payment types','Tipi pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payments','Zahlungsarten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payments','Pagos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Payments','Pagamenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Permissions','Berechtigungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Permissions','Permisos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Permissions','Permissions','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Permissions','Autorizzazioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please activate you account go to {activation_url}','Perfavore attiva il tuo accounto all\'indirizzo {activation_url}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. An instructions was sent to your email address.','Bitte überprüfen Sie Ihre E-Mails. Eine Anleitung wurde an Ihre E-Mail-Adresse geschickt.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. An instructions was sent to your email address.','Por favor verifica tu e-mail a donde se han enviado más instrucciones.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. An instructions was sent to your email address.','Controlez votre boite e-mail, d autres instructions vous ont Ã©tÃ© envoyÃ©es par e-mail. *IMPORTANT:pour le cas ou notre e-mail ne vous serais pas parvenu, il est possible que notre e-mail ai Ã©tÃ© filtrÃ© par votre fournisseur  d accÃ¨s internet et placÃ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. An instructions was sent to your email address.','Perfavore controlla la tua email con le istruzioni che ti abbiamo inviato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. An instructions was sent to your email address.','Bitte Ã¼berprÃ¼fen Sie Ihre E-Mails. Eine Anleitung wurde an Ihre E-Mail-Adresse geschickt.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. An instructions was sent to your email address.','ÐÐ° Ð’Ð°Ñˆ Ð°Ð´Ñ€ÐµÑ ÑÐ»ÐµÐºÑ‚Ñ€Ð¾Ð½Ð½Ð¾Ð¹ Ð¿Ð¾Ñ‡Ñ‚Ñ‹ Ð±Ñ‹Ð»Ð¾ Ð¾Ñ‚Ð¿Ñ€Ð°Ð²Ð»ÐµÐ½Ð¾ Ð¿Ð¸ÑÑŒÐ¼Ð¾ Ñ Ð¸Ð½ÑÑ‚Ñ€ÑƒÐºÑ†Ð¸ÑÐ¼Ð¸.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. Instructions have been sent to your email address.','Bitte schauen Sie in Ihr Postfach. Weitere Anweisungen wurden per E-Mail geschickt.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. Instructions have been sent to your email address.','Por favor revisa tu e-mail. Hemos enviado intrusiones a tu dirección de e-mail.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. Instructions have been sent to your email address.','Controlez votre boite e-mail. D autres instructions vous ont Ã©tÃ© envoyÃ©es par e-mail. *IMPORTANT:pour le cas ou notre e-mail ne vous serais pas parvenu, il est possible que notre e-mail ai Ã©tÃ© filtrÃ© par votre fournisseur  d accÃ¨s internet et placÃ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. Instructions have been sent to your email address.','Si prega di controllare la casella di posta. Ulteriori istruzioni sono state inviate via e-mail.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please check your email. Instructions have been sent to your email address.','ProszÄ™ sprawdÅº TwÃ³j mejl. Instrukcje zostaÅ‚y wysÅ‚ane na TwÃ³j adres mejlowy.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter a request Message up to 255 characters','Bitte geben Sie eine Nachricht bis zu 255 Zeichen an, die dem Benutzer bei der Kontaktanfrage mitgegeben wird','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter a request Message up to 255 characters','Por favor escribe un mensaje no mayor a 255 caracteres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter a request Message up to 255 characters','Vous pouvez ajouter un message personalisÃ© de 255 charactÃ¨res Ã  votre demande de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter a request Message up to 255 characters','Perfavore inserisci un messaggio di richiesta di massimo 255 caratteri','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter the letters as they are shown in the image above.','Bitte geben Sie die, oben im Bild angezeigten, Buchstaben ein.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter the letters as they are shown in the image above.','Por favor escribe las letras que se muestran en la imagen.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter the letters as they are shown in the image above.','Recopiez les charactÃ¨res apparaissant dans l image au dessus.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter the letters as they are shown in the image above.','Perfavore inserire le lettere mostrate nella seguente immagine.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter the letters as they are shown in the image above.','Bitte geben Sie die, oben im Bild angezeigten, Buchstaben ein.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter the letters as they are shown in the image above.','ÐŸÐ¾Ð¶Ð°Ð»ÑƒÐ¹ÑÑ‚Ð°, Ð²Ð²ÐµÐ´Ð¸Ñ‚Ðµ Ð±ÑƒÐºÐ²Ñ‹, Ð¿Ð¾ÐºÐ°Ð·Ð°Ð½Ð½Ñ‹Ðµ Ð½Ð° ÐºÐ°Ñ€Ñ‚Ð¸Ð½ÐºÐµ Ð²Ñ‹ÑˆÐµ.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email addres.','Perfavore inserisci il tuo username o l\'indirizzo mail.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email addres.','ÐŸÐ¾Ð¶Ð°Ð»ÑƒÐ¹ÑÑ‚Ð°, Ð²Ð²ÐµÐ´Ð¸Ñ‚Ðµ Ð’Ð°Ñˆ Ð»Ð¾Ð³Ð¸Ð½ Ð¸Ð»Ð¸ Ð°Ð´Ñ€ÐµÑ ÑÐ»ÐµÐºÑ‚Ñ€Ð¾Ð½Ð½Ð¾Ð¹ Ð¿Ð¾Ñ‡Ñ‚Ñ‹.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email address.','Bitte geben Sie Ihren Benutzernamen oder E-Mail-Adresse ein.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email address.','Por favor escribe tu nombre de usuario o dirección de e-mail.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email address.','Indiquez dans ce champ, votre nom d utilisateur ou votre adresse e-mail.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email address.','Inserisci il tuo nome utente o indirizzo e-mail.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your login or email address.','Bitte geben Sie Ihren Benutzernamen oder E-Mail-Adresse ein.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your password to confirm deletion:','Bitte geben Sie Ihr Passwort ein, um den Löschvorgang zu bestätigen:','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your password to confirm deletion:','Por favor escribe tu contraseña para confirmar la eliminación:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your password to confirm deletion:','Renseignez votre mot de passe, pour confirmer la suppression:','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your password to confirm deletion:','Si prega di inserire la password per confermare l\'eliminazione:','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your password to confirm deletion:','ProszÄ™ wprowadÅº swoje hasÅ‚o w celu potwierdzenia usuwania:','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your user name or email address.','Bitte geben Sie Ihren Benutzernamen oder E-mail Adresse ein','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your user name or email address.','Por favor, ingrese su nombre de usuario o direcci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your user name or email address.','Renseignez votre nom d utilisateur ou votre adresse e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please enter your user name or email address.','Inserisci il tuo nome utente o indirizzo e-mail','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please fill out the following form with your login credentials:','Bitte geben Sie ihre Login-Daten ein:','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please fill out the following form with your login credentials:','Por favor llena el formulario con tu información de inicio de sesión:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please fill out the following form with your login credentials:','Entrez dans le champ vos donnÃ©es de connection:','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please fill out the following form with your login credentials:','Perfavore inserisci le tue credenziali d\'accesso:','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please fill out the following form with your login credentials:','Bitte geben Sie ihre Login-Daten ein:','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please fill out the following form with your login credentials:','ÐŸÐ¾Ð¶Ð°Ð»ÑƒÐ¹ÑÑ‚Ð°, Ð·Ð°Ð¿Ð¾Ð»Ð½Ð¸Ñ‚Ðµ ÑÐ»ÐµÐ´ÑƒÑŽÑ‰ÑƒÑŽ Ñ„Ð¾Ñ€Ð¼Ñƒ Ñ Ð²Ð°ÑˆÐ¸Ð¼Ð¸ Ð›Ð¾Ð³Ð¸Ð½ Ð¸ Ð¿Ð°Ñ€Ð¾Ð»ÐµÐ¼:','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please log in into the application.','Por favor, entra a la aplicación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Please verify your E-Mail address','Por favor verifica tu dirección de correo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Position','Position','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Position','Posición','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Position','Position','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Position','Posizioe','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Position','ÐŸÐ¾Ð·Ð¸Ñ†Ð¸Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Predefined values (example: 1, 2, 3, 4, 5;).','Vordefinierter Bereich (z.B. 1, 2, 3, 4, 5),','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Predefined values (example: 1, 2, 3, 4, 5;).','Valores predefinidos (ejemplo: 1,2,3,4,5;).','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Predefined values (example: 1, 2, 3, 4, 5;).','Valeur prÃ©dÃ©finie (z.B. 1, 2, 3, 4, 5),','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Predefined values (example: 1, 2, 3, 4, 5;).','Valori predefiniti (es. 1, 2, 3, 4, 5),','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Predefined values (example: 1, 2, 3, 4, 5;).','ÐŸÑ€ÐµÐ´Ð¾Ð¿Ñ€ÐµÐ´ÐµÐ»ÐµÐ½Ð½Ñ‹Ðµ Ð·Ð½Ð°Ñ‡ÐµÐ½Ð¸Ñ (Ð¿Ñ€Ð¸Ð¼ÐµÑ€: 1;2;3;4;5;).','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Preseve Profiles','Profile aufbewahren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Preseve Profiles','Preservar Perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Preseve Profiles','Profile aufbewahren ???','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Preseve Profiles','Mantieni profili','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Preseve Profiles','Zachowaj profil','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Price','Preis','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Price','Precio','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Price','Prix','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Price','Prezzo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy','Privatsphäre','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy','Privacidad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy','DonnÃ©es privÃ©es','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy','Privacy','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy','PrivatsphÃ¤re','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings','Privatsphäre','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings','Configuración de Privacidad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings','Vos donnÃ©es personnelles','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings','Privacy','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings for {username}','Privatsphäreneinstellungen für {username}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings for {username}','Configuración de Privacidad para {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings for {username}','Configuration des donnÃ©es privÃ©es pour {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacy settings for {username}','Opzioni Privacy per {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacysettings','Privatsphäre','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacysettings','Configuración de Privacidad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacysettings','DonnÃ©es privÃ©es','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Privacysettings','Opzioni privacy','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile','Profil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile','Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile','Profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile','Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile','Profil','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile','ÐŸÑ€Ð¾Ñ„Ð¸Ð»ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Comments','Pinnwand','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Comments','COmentarios de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Comments','Pinnwand','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Comments','Commenti profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Fields','Profilfelder','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Fields','Campos de Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Fields','Champs des profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Fields','Campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Fields','Pola profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile Fields','ÐŸÐ¾Ð»Ñ Ð¿Ñ€Ð¾Ñ„Ð¸Ð»Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field groups','Profilfeldgruppen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field groups','Grupos de campos de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field groups','Champs des profils de groupes.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field groups','Campo profilo gruppi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field public options','Einstellungen der Profilfelder','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field public options','Opciones de campo de perfil p','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field public options','Configuration des champs publique du profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field public options','Opzioni pubbliche campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field {fieldname}','Profilfeld {fieldname}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field {fieldname}','Campo de perfil {fieldname}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field {fieldname}','Camp de profil {fieldname}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field {fieldname}','{fieldname} campo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile field {fieldname}','Pole profilu {fieldname}','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields','Profilfeldverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields','Campos de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields','Gestion des champs de profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields','Campi profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields','Pole profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields groups','Profilfeldgruppen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields groups','Grupos de campos de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields groups','Champ des profils de groupes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields groups','Campi profilo gruppi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile fields groups','Grupy pÃ³l w profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile history','Profilverlauf','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile history','Historial del perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile history','Chronique du profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile history','Storico profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile history','Historia profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile number','Profilnummer: ','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile number','Número de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile number','NumÃ©ro du profil: ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile number','Numero profilo: ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile number','Numer profilu: ','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile of ','Profil von ','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile of ','Perfil de','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile of ','Profil de ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile of ','Profilo di ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile visits','Profilbesuche','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile visits','Visitas del perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile visits','Visiteurs de mon profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profile visits','Visite profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profiles','Profile','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profiles','Perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profiles','Profiles','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profiles','Profili','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Profiles','Profile','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Range','Bereich','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Range','Rango','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Range','Intervallo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Range','Ð ÑÐ´ Ð·Ð½Ð°Ñ‡ÐµÐ½Ð¸Ð¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Read Only Profiles','Nur-Lese Profile','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Read Only Profiles','Perfiles de Sólo Lectura','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Read Only Profiles','Lecture seule des profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Read Only Profiles','Profilo sola lettura','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Read Only Profiles','Profile tylko do odczytu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email for new Friendship request','E-Mail Benachrichtigung bei neuer Kontaktanfrage','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email for new Friendship request','Recibir un correo cuando recibas una nueva solicitud de amistad','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email for new Friendship request','Informez moi par e-mail pour les nouvelles demandes de contact.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email for new Friendship request','Email di notifica per nuovo contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when a new profile comment was made','E-Mail Benachrichtigung bei Profilkommentar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when a new profile comment was made','Recibir un correo cuando comenten en tu perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when a new profile comment was made','Informez moi par e-mail e-mail pour les nouveaux commentaire de mon profil ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when a new profile comment was made','Email di notifica per nuovo commento al profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when new Message arrives','E-Mail Benachrichtigung bei neuer interner Nachricht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when new Message arrives','Recibir un correo cuanto te llegue un nuevo mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when new Message arrives','Informez moi par e-mail pour les nouveaux messages. ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Receive a Email when new Message arrives','Email di notifica per i nuovi messaggi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registered users','Registrierte Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registered users','Usuarios registrados','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registered users','Membre enregistrÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registered users','Utenti registrati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registered users','Ð—Ð°Ñ€ÐµÐ³Ð¸ÑÑ‚Ñ€Ð¸Ñ€Ð¾Ð²Ð°Ð½Ð½Ñ‹Ðµ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration','Registrierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration','Registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration','Inscription','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration','Reistrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration','Rejestracja','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration','Ð ÐµÐ³Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration date','Anmeldedatum','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration date','Fecha de registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration date','Date d inscription','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration date','Data registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration date','Anmeldedatum','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Registration date','Ð”Ð°Ñ‚Ð° Ñ€ÐµÐ³Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Regular expression (example: \"/^[A-Za-z0-9s,]+$/u\").','Expresión regular (ejemplo: \"/^[A-Za-z0-9s,]+$/u\")','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Regular expression (example: \'/^[A-Za-z0-9s,]+$/u\').','Regulärer Ausdruck (z. B.: \'/^[A-Za-z0-9s,]+$/u\')','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Regular expression (example: \'/^[A-Za-z0-9s,]+$/u\').','Expression regulaire (exemple.: \'/^[A-Za-z0-9s,]+$/u\')','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Regular expression (example: \'/^[A-Za-z0-9s,]+$/u\').','Espressione regolare (esempio: \'/^[A-Za-z0-9s,]+$/u\')','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Regular expression (example: \'/^[A-Za-z0-9s,]+$/u\').','Ð ÐµÐ³ÑƒÐ»ÑÑ€Ð½Ñ‹Ðµ Ð²Ñ‹Ñ€Ð°Ð¶ÐµÐ½Ð¸Ñ (Ð¿Ñ€Ð¸Ð¼ÐµÑ€: \'/^[A-Za-z0-9s,]+$/u\')','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remember me net time','ZapamiÄ™taj mnie nastÄ™pnym razem','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remember me next time','Angemeldet bleiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remember me next time','Recordarme la próxima vez','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remember me next time','Rester connectÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remember me next time','Ricordami','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remember me next time','Ð—Ð°Ð¿Ð¾Ð¼Ð½Ð¸Ñ‚ÑŒ Ð¼ÐµÐ½Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove','Entfernen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove','Quitar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove','Supprimer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove','Rimuovi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove Avatar','Profilbild entfernen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove Avatar','Borrar este Avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove Avatar','Supprimer l image de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove Avatar','Rimuovi avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove comment','Kommentar entfernen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove comment','Borrar comentario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove comment','Supprimer ce commentaire','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove comment','Rimuovi commento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove friend','Freundschaft kündigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove friend','Borrar amigo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove friend','Supprimer ce contact de ma liste','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Remove friend','Rimuovi contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply','Antwort','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply','Responder','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply','RÃ©pondre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply','Rispondi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply','Odpowiedz','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to Message','auf diese Nachricht antworten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to Message','Responder al Mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to Message','RÃ©pondre Ã  ce message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to Message','Rispondi al messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to Message','Odpowiedz','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to message','Responder al mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Reply to message','Rispondi al messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Request friendship for user {username}','Kontaktanfrage für {username}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Request friendship for user {username}','Solicitar amistar al usuario {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Request friendship for user {username}','Demande de contact pour {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Request friendship for user {username}','Richiesta contatto per {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required','Benötigt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required','Requerido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required','Recquis','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required','Obbligatorio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required','ÐžÐ±ÑÐ·Ð°Ñ‚ÐµÐ»ÑŒÐ½Ð¾ÑÑ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required field (form validator).','Campo obbligatorio (validazione form).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Required field (form validator).','ÐžÐ±ÑÐ·Ð°Ñ‚ÐµÐ»ÑŒÐ½Ð¾Ðµ Ð¿Ð¾Ð»Ðµ (Ð¿Ñ€Ð¾Ð²ÐµÑ€ÐºÐ° Ñ„Ð¾Ñ€Ð¼Ñ‹).','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Restore','Wiederherstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Restore','Recuperar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Restore','Restaurer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Restore','Ripristino','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Restore','Wiederherstellen','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Restore','Ð’Ð¾ÑÑÑ‚Ð°Ð½Ð¾Ð²Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype Password','ÐŸÐ¾Ð²Ñ‚Ð¾Ñ€Ð¸Ñ‚Ðµ Ð¿Ð°Ñ€Ð¾Ð»ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype Password is incorrect.','ÐŸÐ°Ñ€Ð¾Ð»Ð¸ Ð½Ðµ ÑÐ¾Ð²Ð¿Ð°Ð´Ð°ÑŽÑ‚.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password','Passwort wiederholen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password','Repite la contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password','Redonnez votre mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password','Conferma password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password','Passwort wiederholen','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password is incorrect.','Wiederholtes Passwort ist falsch.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password is incorrect.','Contraseña repetida incorrecta','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password is incorrect.','Le mot de passe est a nouveau incorrect.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password is incorrect.','Conferma password Ã¨ errata.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype password is incorrect.','Wiederholtes Passwort ist falsch.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype your new password','Wiederholen Sie Ihr neues Passwort','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype your new password','Vuelva a escribir su nueva contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype your new password','Confirmez votre nouveau mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retype your new password','Confermare la nuova password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retyped password is incorrect','Wiederholtes Passwort ist nicht identisch','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retyped password is incorrect','La contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retyped password is incorrect','Le mot de passe renseignÃ© n est pas identique au prÃ©cÃ©dent','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Retyped password is incorrect','Password di conferma non identica','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Role Administration','Rollenverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Role Administration','Administración de rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Role Administration','Gestion des rÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Role Administration','Gestione dei ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Role Administration','ZarzÄ…dzanie rolami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles','Rollen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles','Roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles','RÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles','Ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles','Role','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles / Access control','Rollen / Zugangskontrolle','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Roles / Access control','Funciones y de control de acceso','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save','Sichern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save','Guardar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save','MÃ©moriser','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save','Salva','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save','Sichern','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save','Ð¡Ð¾Ñ…Ñ€Ð°Ð½Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save payment type','Zahlungsart speichern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save payment type','Guardar el tipo de pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save payment type','Salva tipo pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save profile changes','Profiländerungen speichern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save profile changes','Guardar los cambios de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save profile changes','Salva modifiche profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save role','Rolle speichern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save role','Guardar funci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save role','MÃ©moriser ce rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Save role','Salva ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Search for username','Suche nach Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Search for username','B','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Search for username','Recherche par nom d\'utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Search for username','Cerca per username','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Searchable','Suchbar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Searchable','Investigable','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Searchable','visible','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Searchable','Ricercabile','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select a month','Monatsauswahl','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select a month','Seleccione un mes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select a month','Seleziona un mese','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select multiple recipients by holding the CTRL key','Wählen Sie mehrere Empfänger mit der STRG-Taste aus','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select multiple recipients by holding the CTRL key','Selecciona varios destinatarios manteniendo presionada la tecla CTRL','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select multiple recipients by holding the CTRL key','Choix multiple en laissant la touche STRG de votre clavier enfoncÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select multiple recipients by holding the CTRL key','Seleziona destinatari multipli con il tasto CTRL','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select the fields that should be public','Diese Felder sind öffentlich einsehbar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select the fields that should be public','Seleccione los campos que deben ser p','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select the fields that should be public','Ces champs sont publiques et seront visibles','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Select the fields that should be public','Scegli i campi da rendere publici','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Selectable on registration','Während der Registrierung wählbar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Selectable on registration','Seleccionable en el registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Selectable on registration','Option Ã  selectionner au cours de l inscription','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Selectable on registration','Selezionabile durante la registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send','Senden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send','Enviar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send','Envoyer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send','Invia','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send','Senden','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send a message to this User','Diesem Benutzer eine Nachricht senden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send a message to this User','Enviar un mensaje a este Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send a message to this User','Faire parvenir un message Ã  ce membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send a message to this User','Invia messaggio all\'utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send invitation','Kontaktanfrage senden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send invitation','Enviar invitación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send invitation','Envoyer la demande de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send invitation','Kontaktanfrage senden','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send message notifier emails','Benachrichtigungen schicken','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send message notifier emails','Enviar mensaje de e-mail de notificación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send message notifier emails','Envoie d une notification','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Send message notifier emails','Notifiche e-mail','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent at','Gesendet am','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent at','Enviado al','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent at','ENvoyÃ© le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent at','Pubblicato il','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent at','WysÅ‚ano','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent messages','Gesendete Nachrichten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent messages','Mensajes enviados','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent messages','Message envoyÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent messages','Messaggi inviati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Sent messages','WysÅ‚ane wiadomoÅ›ci','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Separate usernames with comma to ignore specified users','Benutzernamen mit Komma trennen, um sie zu ignorieren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Separate usernames with comma to ignore specified users','Separa con coma los nombres de los usuarios que deseas ignorar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Separate usernames with comma to ignore specified users','Ma liste noire, pour introduire plusieurs membres en une seule fois, sÃ©parer les noms d utilisateur avec une virgule','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Separate usernames with comma to ignore specified users','Separa gli username con una virgola, per ignorare gli utenti specificati','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Set payment date to today','Zahlungseingang bestätigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Set payment date to today','Establecer fecha de pago el d','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Set payment date to today','Imposta data pagamento ad oggi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings','Einstellungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings','Ajustes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings','RÃ©glage','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings','Impostazioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings','Ustawienia','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings profiles','Einstellungsprofile','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings profiles','Ajustes de perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings profiles','RÃ©glages des profiles','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings profiles','Impostazioni profili','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Settings profiles','Ustawienia profili','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show activities','Zeige Aktivitäten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show activities','Mostrar las actividades','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show activities','Voir la chronique des activitÃ©s','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show activities','Mostra attivitÃ ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show administration Hierarchy','Hierarchie','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show administration Hierarchy','Mostrar jerarquía de administración','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show administration Hierarchy','Hierarchie','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show administration Hierarchy','Gerarchia','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show administration Hierarchy','PokaÅ¼ hierarchiÄ™ administrowania','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show all','Mostra tutti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show friends','Kontaktliste veröffentlichen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show friends','Mostrar amigos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show friends','REndre ma liste de contacts visible','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show friends','Mostra contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show my online status to everyone','Meinen Online-Status veröffentlichen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show my online status to everyone','Mostrar mi estado de conexi','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show my online status to everyone','Montrer lorsque je suis en ligne','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show my online status to everyone','Mostra il mio stato a tutti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show online status','Online-Status anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show online status','Mostrar estado de conexi','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show online status','Status en ligne visible','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show online status','Mostra lo stato online','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show permissions','Berechtigungen anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show permissions','Mostrar permisos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show permissions','Montrer les permissions','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show permissions','Mostra autorizzazioni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show profile visits','Profilbesuche anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show profile visits','Mostrar perfil de visitas','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show profile visits','Montrer les visites de profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show profile visits','Visualizza visite profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show roles','Rollen anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show roles','Mostrar roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show roles','Voir les rÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show roles','Mostra ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show roles','PokaÅ¼ role','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show the owner when i visit his profile','Dem Profileigentümer erkenntlich machen, wenn ich sein Profil besuche','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show the owner when i visit his profile','Mostrar el due','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show the owner when i visit his profile','Montrer aux propriÃ©taires des profils lorsque je consulte leur profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show the owner when i visit his profile','Mostra al proprietario quando visito il suo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show users','Benutzer anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show users','Mostrar usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show users','Voir les membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show users','Mostra utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Show users','PokaÅ¼ uÅ¼ytkownikow','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Statistics','Benutzerstatistik','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Statistics','Estadísticas','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Statistics','Statistiques des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Statistics','Statistiche','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Statistics','Statystyki','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Status','Status','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Status','Estado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Status','Status','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Status','Stato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Status','Status','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Status','Ð¡Ñ‚Ð°Ñ‚ÑƒÑ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Street','Straße','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Street','Calle','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Street','Rue','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Street','Indirizzo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Street','Ulica','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Subject','Titel','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Subject','Tema','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Subject','Sujet','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Subject','Oggetto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Success','Erfolgreich','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Success','Exitoso','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Success','RÃ©ussi','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Success','Successo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Superuser','Superuser','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Superuser','Superusuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Superuser','Superuser','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Superuser','Superuser','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Superuser','Superuser','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Superuser','Ð¡ÑƒÐ¿ÐµÑ€ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Activation','Text Email Konto-Aktivierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Activation','Texto de activación por correo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Activation','Texte contenu dans l e-mail d activation de compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Activation','Testo email d\'attivazione account','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Recovery','Text E-Mail Passwort wiederherstellen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Recovery','Texto de recuperación de contraseña por correo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Recovery','Texte contenu dans l e-Mail de renouvellement de mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Recovery','Testo email recupero password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Registration','Text E-Mail Registrierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Registration','Texto de registro por correo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Registration','Texte contenu dans l e-Mail d enregistrement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Email Registration','Testo email di registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Footer','Text im Login-footer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Footer','Text im Login-footer','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Footer','Text im Login-footer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Footer','Testo nel piepagina del login','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Header','Text im Login-header','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Header','Text im Login-header','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Header','Texte de connection-header','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Login Header','Testo nell\'intestazione del login','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Footer','Text im Registrierung-footer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Footer','Text im Registrierung-footer','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Footer','Texte d enregistrement-footer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Footer','Testo nel piepagina della registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Header','Text im Registrierung-header','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Header','Text im Registrierung-header','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Header','Texte d enregistrement-header','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text Registration Header','Testo nell\'intestazione della registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new friendship request','Text für eine neue Kontaktanfrage','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new friendship request','Text für eine neue Kontaktanfrage','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new friendship request','Texte pour une nouvelle demande de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new friendship request','Testo per una nuova richiesta di contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new profile comment','Text für neuen Profilkommentar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new profile comment','Text für neuen Profilkommentar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new profile comment','Texte pour un nouveau commentaire dans un profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text for new profile comment','Testo per un nuovo commento al profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text translations','Übersetzungstexte','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Text translations','Traducciones de texto','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Contact Admin to activate your account.','Grazie per la tua registrazione. Contatta l\'ammnistratore per attivare l\'account','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email or login.','Vielen Dank für Ihre Anmeldung. Bitte überprüfen Sie Ihre E-Mails oder loggen Sie sich ein.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email or login.','Gracias por su registro. Por favor, compruebe su correo electr','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email or login.','Merci pour votre inscription.Controlez votre boite e-mail, le code d activation de votre compte vous a Ã©tÃ© envoyÃ© par e-mail.Attention! Par mesure de sÃ©curitÃ©, le lien contenu dans ce mail, n est valable que 48h *IMPORTANT:pour le cas ou notre e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email or login.','Grazie per la tua registrazione, controlla la tua email o effettua il login,','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email or login.','Vielen Dank fÃ¼r Ihre Anmeldung. Bitte Ã¼berprÃ¼fen Sie Ihre E-Mails oder loggen Sie sich ein.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email or login.','Ð ÐµÐ³Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ñ Ð·Ð°Ð²ÐµÑ€ÑˆÐµÐ½Ð°. ÐŸÐ¾Ð¶Ð°Ð»ÑƒÐ¹ÑÑ‚Ð° Ð¿Ñ€Ð¾Ð²ÐµÑ€ÑŒÑ‚Ðµ ÑÐ²Ð¾Ð¹ ÑÐ»ÐµÐºÑ‚Ñ€Ð¾Ð½Ð½Ñ‹Ð¹ ÑÑ‰Ð¸Ðº Ð¸Ð»Ð¸ Ð²Ñ‹Ð¿Ð¾Ð»Ð½Ð¸Ñ‚Ðµ Ð²Ñ…Ð¾Ð´.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email.','Vielen Dank für Ihre Anmeldung. Bitte überprüfen Sie Ihre E-Mails.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email.','Gracias por su registro. Por favor revise su email.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email.','Merci pour votre inscription.Controlez votre boite e-mail, le code d activation de votre compte vous a Ã©tÃ© envoyÃ© par e-mail. *IMPORTANT:pour le cas ou notre e-mail ne vous serais pas parvenu, il est possible que notre e-mail ai Ã©tÃ© filtrÃ© par votre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email.','Grazie per la tua registrazione, controlla la tua email,','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email.','Vielen Dank fÃ¼r Ihre Anmeldung. Bitte Ã¼berprÃ¼fen Sie Ihre E-Mails.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please check your email.','Ð ÐµÐ³Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ñ Ð·Ð°Ð²ÐµÑ€ÑˆÐµÐ½Ð°. ÐŸÐ¾Ð¶Ð°Ð»ÑƒÐ¹ÑÑ‚Ð° Ð¿Ñ€Ð¾Ð²ÐµÑ€ÑŒÑ‚Ðµ ÑÐ²Ð¾Ð¹ ÑÐ»ÐµÐºÑ‚Ñ€Ð¾Ð½Ð½Ñ‹Ð¹ ÑÑ‰Ð¸Ðº.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Thank you for your registration. Please {{login}}.','Grazie per la tua registrazone. Effettua il {{login}}.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The comment has been saved','Der Kommentar wurde gespeichert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The comment has been saved','Der Kommentar wurde gespeichert','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The comment has been saved','Le commentaire a bien Ã©tÃ© mÃ©morisÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The comment has been saved','Il commento Ã¨ stato salvato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The file \"{file}\" is not an image.','Die Datei {file} ist kein Bild.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The file \"{file}\" is not an image.','Este archivo {file} no es una imagen.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The file \"{file}\" is not an image.','DLe fichier {file} n est pas un fichier image.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The file \"{file}\" is not an image.','Il file {file} non Ã¨ un\'immagine.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The friendship request has been sent','Die Kontaktanfrage wurde gesendet','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The friendship request has been sent','La solicitud de amistad ha sido enviado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The friendship request has been sent','Votre demande de contact Ã  bien Ã©tÃ© envoyÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The friendship request has been sent','La richiesta di contatto Ã¨ stata inviata','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" height should be \"{height}px\".','Die Datei {file} muss genau {height}px hoch sein.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" height should be \"{height}px\".','La imagen {file} debe tener {height}px de largo.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" height should be \"{height}px\".','La photo {file} doit avoir une hauteur maximum de {height}px .','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" height should be \"{height}px\".','L\'immagine {file} deve essere {height}px.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" width should be \"{width}px\".','Die Datei {file} muss genau {width}px breit sein.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" width should be \"{width}px\".','La imagen {file} debe tener {width}px de ancho.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" width should be \"{width}px\".','La photo {file} doit avoir une largeur maximum de {width}px .','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image \"{file}\" width should be \"{width}px\".','L\'immagine {file} deve essere larga {width}px.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image has been resized to {max_pixel}px width successfully','Das Bild wurde beim hochladen automatisch auf eine Breite von {max_pixel} skaliert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image has been resized to {max_pixel}px width successfully','La imagen ha sido redimensionada a {max_pixel} px de ancho con ','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image has been resized to {max_pixel}px width successfully','Votre photo de profil a Ã©tÃ© retaillÃ©e automatiquement Ã  une taille de{max_pixel}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image has been resized to {max_pixel}px width successfully','Immagine ridimensionata a {max_pixel}px con successo.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image should have at least 50px and a maximum of 200px in width and height. Supported filetypes are .jpg, .gif and .png','das Bild sollte mindestens 50px und maximal 200px in der Höhe und Breite betragen. Mögliche Dateitypen sind .jpg, .gif und .png','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image should have at least 50px and a maximum of 200px in width and height. Supported filetypes are .jpg, .gif and .png','La imagen debe tener un mínimo de 50px y un máximo de 200px de ancho y largo. Los tipos de archivo soportados son .jpg, .gif y .png','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image should have at least 50px and a maximum of 200px in width and height. Supported filetypes are .jpg, .gif and .png','La foto chargÃ©e doit avoir une largeur maximum de 50px  et une hauteur maximale de 200px. Les fichiers acceptÃ©s sont; .jpg, .gif und .png','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image should have at least 50px and a maximum of 200px in width and height. Supported filetypes are .jpg, .gif and .png','L\'immagine deve essere almeno 50px e massimo 200px in larghezza e altezza. Tipi di file supportati .jpg, .gif e .png','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image was uploaded successfully','Das Bild wurde erfolgreich hochgeladen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image was uploaded successfully','La imagen se ha carregado correctamente','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image was uploaded successfully','L image a Ã©tÃ© chargÃ©e avec succÃ¨s','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The image was uploaded successfully','Immagine caricata con successo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The messages for your application language are not defined.','Los mensajes para el idioma de tu aplicación no están definidos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The minimum value of the field (form validator).','Minimalwert des Feldes (Form-Validierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The minimum value of the field (form validator).','El valor mínimo del campo (validador de formulario)','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The minimum value of the field (form validator).','Valeur minimum du champ (Validation du formulaire)','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The minimum value of the field (form validator).','Valore minimo del campo (validazione form).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The minimum value of the field (form validator).','ÐœÐ¸Ð½Ð¸Ð¼Ð°Ð»ÑŒÐ½Ð¾Ðµ Ð·Ð½Ð°Ñ‡ÐµÐ½Ð¸Ðµ Ð¿Ð¾Ð»Ñ (Ð¿Ñ€Ð¾Ð²ÐµÑ€ÐºÐ° Ñ„Ð¾Ñ€Ð¼Ñ‹).','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The new password has been saved','Das neue Passwort wurde gespeichert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The new password has been saved','La nueva contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The new password has been saved','Votre nouveau mot de passe a bien Ã©tÃ© mÃ©morisÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The new password has been saved','La nuova password Ã¨ stata salvata.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The new password has been saved.','La nueva contraseña ha sido guardada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The value of the default field (database).','Standard-Wert für die Datenbank','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The value of the default field (database).','El valor predeterminado del campo (base de datos).','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The value of the default field (database).','Valeur standard pour la banque de donnÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The value of the default field (database).','Valore del campo predefnito (database).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The value of the default field (database).','DomyÅ›lna wartoÅ›Ä‡ pola (bazodanowego).','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('The value of the default field (database).','Ð—Ð½Ð°Ñ‡ÐµÐ½Ð¸Ðµ Ð¿Ð¾Ð»Ñ Ð¿Ð¾ ÑƒÐ¼Ð¾Ð»Ñ‡Ð°Ð½Ð¸ÑŽ (Ð±Ð°Ð·Ð° Ð´Ð°Ð½Ð½Ñ‹Ñ…).','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are a total of {messages} messages in your System.','Es gibt in ihrem System insgesamt {messages} Nachrichten.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are a total of {messages} messages in your System.','Hay un total de {messages} mensajes en su sistema.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are a total of {messages} messages in your System.','Il existe dans votre systÃ¨me {messages} messages.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are a total of {messages} messages in your System.','Ci sno un totale di {messages} messaggi nel Sistema.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are a total of {messages} messages in your System.','Istnieje {messages} wiadomoÅ›ci w Twoim systemie.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {active_users} active and {inactive_users} inactive users in your System, from which {admin_users} are Administrators.',' Es gibt {active_users} aktive und {inactive_users} inaktive Benutzer in ihrem System, von denen {admin_users} Benutzer Administratoren sind.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {active_users} active and {inactive_users} inactive users in your System, from which {admin_users} are Administrators.','Hay {active_users} usuarios activos y {inactive_users} usuarios inactivos en su sistema, de los cuales {admin_users} son Administradores.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {active_users} active and {inactive_users} inactive users in your System, from which {admin_users} are Administrators.',' Il existe {active_users}  membres actifs et {inactive_users} membres inactifs dans votre systÃ©me, pour lesquels {admin_users} membres sont dÃ©signÃ©s en tant qu administrateurs.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {active_users} active and {inactive_users} inactive users in your System, from which {admin_users} are Administrators.',' Ci sono {active_users} utenti attivi e {inactive_users} utenti inattivi nel Sistema, di cui {admin_users} sono amministratori.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {active_users} active and {inactive_users} inactive users in your System, from which {admin_users} are Administrators.','IstniejÄ… {active_users} aktywni i {inactive_users} nieaktywni uÅ¼ytkownicy w Twoim systemie, w tym {admin_users} administratorzy.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {profiles} profiles in your System. These consist of {profile_fields} profile fields in {profile_field_groups} profile field groups','Es gibt {profiles} Profile in ihren System. Diese bestehen aus {profile_fields} Profilfeldern, die sich in {profile_field_groups} Profilfeldgruppen aufteilen.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {profiles} profiles in your System. These consist of {profile_fields} profile fields in {profile_field_groups} profile field groups','Hay {profiles} perfiles en su sistema. Estos consisten de {profile_fields} campos de perfiles en {profile_field_groups} grupos de campos de perfiles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {profiles} profiles in your System. These consist of {profile_fields} profile fields in {profile_field_groups} profile field groups','Il existe {profiles} profils dans votre systÃ¨me. Ils se composent de {profile_fields} champs de profils, qui se dÃ©composent {profile_field_groups} en grouppe de champs de profils.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {profiles} profiles in your System. These consist of {profile_fields} profile fields in {profile_field_groups} profile field groups','Ci sono {profiles} profili nel Sistema. sono costituiti da {profile_fields} campi profili, in {profile_field_groups} campo profili gruppi.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {profiles} profiles in your System. These consist of {profile_fields} profile fields in {profile_field_groups} profile field groups','IstniejÄ… {profiles} profile w Twoim systemie, ktÃ³re zawierajÄ… pola {profile_fields} w grupach {profile_field_groups}','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {roles} roles in your System.','Es gibt {roles} Rollen in ihrem System','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {roles} roles in your System.','Hay {roles} roles en su sistema.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {roles} roles in your System.','Il existe les {roles} rÃ´les suivant dans votre systÃ¨me','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {roles} roles in your System.','Ci sono {roles} ruoli nel Sistema','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There are {roles} roles in your System.','Istnieje {roles} rÃ³l w Twoim systemie','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There was an error saving the password','Fehler beim speichern des Passwortes','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There was an error saving the password','Hubo un error al guardar la contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There was an error saving the password','Erreur produite lors de la mÃ©morisation de votre mot de passe.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('There was an error saving the password','Impossibile salvare la password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have a ordered memberships of this role','Diese Benutzer haben eine Mitgliedschaft in dieser Rolle','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have a ordered memberships of this role','Ces membres sont assignÃ©s Ã  ce rÃ´le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have a ordered memberships of this role','Questi utenti hanno ordinato l\'iscrizione a questo ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this Role','Diese Nutzer gehören dieser Rolle an: ','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this Role','A ces membres ont Ã©tÃ© attribuÃ©s ce rÃ´le: ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this Role','Questi utenti sono assegnati al ruolo: ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this Role','UÅ¼ytkownik zostaÅ‚ przypisany do rÃ³l: ','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this role','Dieser Rolle gehören diese Benutzer an','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this role','Ce rÃ´le a bien Ã©tÃ© attribuÃ© Ã  ces membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this role','Questo ruolo Ã¨ assegnato  a questo utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have been assigned to this role','Uzytkownik zostaÅ‚ przypisany do rÃ³l','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have commented your profile recently','Diese Benutzer haben mein Profil kürzlich kommentiert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have commented your profile recently','Cet utilisateur Ã  commentÃ© rÃ©cemment votre profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have commented your profile recently','Questo utente ha recentemente commentato sul tuo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have visited my profile','Diese Benutzer haben mein Profil besucht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have visited my profile','Les membres ayant visitÃ© mon profil.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have visited my profile','Questi utenti hanno visitato il tuo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have visited your profile recently','Diese Benutzer haben kürzlich mein Profil besucht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have visited your profile recently','Cet utilisateur a visitÃ© votre profil rÃ©cemment','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('These users have visited your profile recently','Questi utenti hanno recentemente visitato il tuo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is blocked.','Ihr Konto wurde blockiert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is blocked.','Esta cuenta está bloqueada.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is blocked.','Votre compte a Ã©tÃ© bloquÃ©. Contactez nous.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is blocked.','Il tuo account Ã¨ stato bloccato.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is blocked.','To konto jest zablokowane.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is not activated.','Ihr Konto wurde nicht aktiviert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is not activated.','Esta cuenta no está activada.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is not activated.','Votre compte n a pas Ã©tÃ© activÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is not activated.','Il tuo account non Ã¨ attivato.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This account is not activated.','To konto nie zostaÅ‚o jeszcze aktywowane.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This membership is still active {days} days','Die Mitgliedschaft ist noch {days} Tage aktiv','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This membership is still {days} days active','Esta membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This membership is still {days} days active','L\'iscrizione Ã¨ ancora attiva per {days} giorni','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This message will be sent to {username}','Diese Nachricht wird an {username} versandt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This message will be sent to {username}','Este mensaje será enviado a {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This message will be sent to {username}','Ce message sera envoyÃ© Ã  {username}','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This message will be sent to {username}','Questo messaggio verrÃ  inviato a {username}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This role can administer users of this roles','Este rol puede administrar usuarios de estos roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This role can administer users of this roles','Membres ayant ce rÃ´le peuvent administrer ces utilisateurs','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This role can administer users of this roles','Questo ruolo puÃ² amministrare utenti di questo ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user belongs to these roles:','Benutzer gehört diesen Rollen an:','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user belongs to these roles:','Este usuario pertenece a estos roles:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user belongs to these roles:','A ce membre a Ã©tÃ© attribuÃ© ces rÃ´les:','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user belongs to these roles:','L\'Utente appartiene a questi ruoli:','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user belongs to these roles:','UÅ¼ytkownik posiada role:','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users','Dieser Benutzer kann diese Nutzer administrieren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users','Este usuario puede administrar estos usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users','Ce membre peut gÃ©rer ces utilisateurs.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users','Gli utenti possono gestire questi utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users:','Benutzer kann diese Benutzer verwalten:','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users:','Este usuario puede administrar estos usuarios:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users:','Ce membre peut administrer ces membres:','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users:','Gli utenti possono gestire questi utenti:','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administer this users:','UÅ¼ytkownik moÅ¼e zarzÄ…dzaj nastÄ™pujÄ…cymi uÅ¼ytkownikami:','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user can administrate this users','UÅ¼ytkownik moÅ¼e administrowaÄ‡ podanymi uÅ¼ytkownikami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email address already exists.','Indirizzo email esistente.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email adress already exists.','Der Benutzer E-Mail-Adresse existiert bereits.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email adress already exists.','La dirección de e-mail de este usuario ya existe.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email adress already exists.','Cette adresse e-mail existe dÃ©jÃ  dans notre banque de donnÃ©e.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email adress already exists.','Indirizzo e-mail giÃ  esistente.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email adress already exists.','Podany adres melopwy jest w uÅ¼yciu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s email adress already exists.','ÐŸÐ¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÑŒ Ñ Ñ‚Ð°ÐºÐ¸Ð¼ ÑÐ»ÐµÐºÑ‚Ñ€Ð¾Ð½Ð½Ñ‹Ð¼ Ð°Ð´Ñ€ÐµÑÐ¾Ð¼ ÑƒÐ¶Ðµ ÑÑƒÑ‰ÐµÑÑ‚Ð²ÑƒÐµÑ‚.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s name already exists.','Der Benutzer Name existiert bereits.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s name already exists.','Este nombre de usuario ya existe.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s name already exists.','Ce nom d utilisateur existe dÃ©jÃ  dans notre banque de donnÃ©e.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s name already exists.','Nome esistenze','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s name already exists.','Podana nazwa uÅ¼ytkownika jest w uÅ¼yciu.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This user\'s name already exists.','ÐŸÐ¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÑŒ Ñ Ñ‚Ð°ÐºÐ¸Ð¼ Ð¸Ð¼ÐµÐ½ÐµÐ¼ ÑƒÐ¶Ðµ ÑÑƒÑ‰ÐµÑÑ‚Ð²ÑƒÐµÑ‚.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This users have a ordered memberships of this role','Estos usuarios tienen una membres','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This users have been assigned to this Role','Este usuario ha sido asignado a este Rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This users have been assigned to this role','Este usuario ha sido asignado a este rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This users have commented your profile recently','Estos usuarios han comentado su perfil recientemente','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This users have visited my profile','Estos usuarios han visitado mi perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('This users have visited your profile recently','Estos usuarios han visitado tu perfil recientemente','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time left','Zeit übrig','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time left','Tiempo restante','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time sent','Gesendet am','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time sent','Hora de envío','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time sent','EnvoyÃ© le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time sent','Pubblicato su','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Time sent','WysÅ‚ano','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Title','Titel','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Title','Título','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Title','Titre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Title','Titolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Title','ÐÐ°Ð·Ð²Ð°Ð½Ð¸Ðµ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('To','An','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('To','Para','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('To','A','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('To','A','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Translation','Übersetzung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Translation','Traducción','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Translations have been saved','Die Übersetzungen wurden gespeichert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Translations have been saved','Las traducciones han sido salvadas','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Try again','Erneut versuchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Try again','Intenta de nuevo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Try again','Essayer Ã  nouveau','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Try again','Prova di nuovo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Try again','SprÃ³buj jeszcze raz','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update','Bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update','Actualizar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update','Modifier','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update','Aggiorna','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update','ZmieÅ„','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update Profile Field','Profilfeld bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update Profile Field','Actualizar Campo del Perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update Profile Field','Modifier le champ du profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update Profile Field','Aggiorna campo Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update Profile Field','ZmieÅ„ pole w profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update Profile Field','ÐŸÑ€Ð°Ð²Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update User','Benutzer bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update User','Actualizar Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update User','GÃ©rer les membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update User','Aggiorna utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update User','ÐŸÑ€Ð°Ð²Ð¸Ñ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update my profile','Mein Profil bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update my profile','Actualizar mi perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update my profile','Aggiorna profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update payment','Zahlungsart bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update payment','Actualizar el pago','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update payment','Aggiorna pagamento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update role','Rolle bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update role','Actualizar rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update role','Modifier les rÃ´les','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update role','Aggiorna ruolo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update role','Edytuj rolÄ™','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update user','Benutzer bearbeiten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update user','Actualizar usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update user','Modifier un membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update user','Aggiorna utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Update user','ZmieÅ„ uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upgrade to {role}','Wechsle auf {role}','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload Avatar','Subir un Avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload Avatar','Charger une image de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload Avatar','Carica avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar','Profilbild hochladen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar','Subir un avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar','Charger une image de profil maintenant','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar','Carica avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar Image','Carica avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar image','Profilbild hochladen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar image','Cargar imagen de perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar image','Charger une image pour votre profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Upload avatar image','Carica immagine avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Use my Gravatar','Meinen Gravatar benutzen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Use my Gravatar','Usar mi Gravatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User','Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User','Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User','Utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User','Utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Administration','Benutzerverwaltung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Administration','Administración de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Administration','Gestion des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Administration','Gestione utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Administration','ZarzÄ…dzanie uÅ¼ytkownikami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management Home','Benutzerverwaltung Startseite','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management Home','Administración de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management Home','Page de gestion des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management Home','Home gestione utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management Home','Strona startowa profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management settings configuration','Einstellungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management settings configuration','Ajustes de configuración de la Administración de usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management settings configuration','Options de configuration des profils','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Management settings configuration','Configurazione impostazioni gestione utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Operations','Benutzeraktionen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Operations','Operaciones de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Operations','Action de l utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Operations','Azioni utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User Operations','CzynnoÅ›ci uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User activation','User-Aktivierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User activation','Activación de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User activation','Activation du compte utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User activation','Attivazione utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User activation','User-Aktivierung','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User activation','ÐÐºÑ‚Ð¸Ð²Ð°Ñ†Ð¸Ñ Ð¿Ð¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration Panel','Benutzerkontrollzentrum','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration Panel','Panel de administración de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration Panel','Centre de controle des membres','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration Panel','Pannello di controllo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration Panel','Panel zarzÄ…dzania uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration panel','Kontrollzentrum','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration panel','Panel de administración de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration panel','Centre de controle user','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration panel','Pannello di controllo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User administration panel','Panel zarzÄ…dzania uÅ¼ytkownikiem','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to Roles','Benutzer gehört diesen Rollen an','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to Roles','El usuario pertenece al los Roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to Roles','Attribuer des rÃ´les Ã  un membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to Roles','Utente appartiene a questi ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to Roles','UÅ¼ytkownik posiada role','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to these roles','Benutzer gehört diesen Rollen an','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to these roles','El usuario pertenece a estos roles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to these roles','Attribuer ce rÃ´le Ã  un membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to these roles','Utente appartiene a questi ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User belongs to these roles','UÅ¼ytkownik posiada role','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users','Kann keine Benutzer verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users','El usuario no puede administrar ningún usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users','Ne peut pas gÃ©rer les utilisateurs','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users','Impossibile gestire gli utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users','UÅ¼ytkownik nie moÅ¼e zarzÄ…dzaÄ‡ Å¼adnymi uÅ¼ytkownikami','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users of any role','Kann keine Rollen verwalten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users of any role','El usuario no puede administrar ningún usuario o ningún rol','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users of any role','Ne peut pas gÃ©rer les rolles','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users of any role','Impossibile gestire i ruoli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not administer any users of any role','UÅ¼ytkownik nie moÅ¼e zarzÄ…dzaÄ‡ Å¼adnymi rolami uÅ¼ytkownikÃ³w','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User can not be found','Benutzer kann nicht gefunden werden','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User is Online!','Benutzer ist Online!','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User is Online!','El usuario est','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User is Online!','Utilisateur en ligne!','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User is Online!','Utente online!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User is not active','Benutzer ist nicht aktiv','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User module settings','Moduleinstellungen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User module settings','Ajustes del módulo de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User module settings','RÃ©glages du module user','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User module settings','Modulo impostazioni utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('User module settings','Ustawienia moduÅ‚u uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Usergroups','Benutzergruppen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Usergroups','Grupos del usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Usergroups','Utilisateur des grouppes','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Usergroups','Gruppi utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username','Benutzername','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username','Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username','Benutzername','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username','Username','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username','UÅ¼ytkownik','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username is incorrect.','Benutzername ist falsch.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username is incorrect.','Nombre de usuario incorrecto','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username is incorrect.','Le nom d utilisateur est incorrect.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username is incorrect.','Username non corretto.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username is incorrect.','Nazwa uÅ¼ytkownika jest niepoprawna.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username is incorrect.','ÐŸÐ¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»ÑŒ Ñ Ñ‚Ð°ÐºÐ¸Ð¼ Ð¸Ð¼ÐµÐ½ÐµÐ¼ Ð½Ðµ Ð·Ð°Ñ€ÐµÐ³Ð¸ÑÑ‚Ñ€Ð¸Ñ€Ð¾Ð²Ð°Ð½.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Email','Benutzername oder E-mail','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Email','Nombre de usuario o Email','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Email','Nom d utilisateur ou adresse e-mail.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Email','Username o email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Password is incorrect','Benutzername oder Passwort ist falsch','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Password is incorrect','Usuario o contraseña incorrectos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Password is incorrect','Nom d utilisateur ou mot passe incorrect','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or Password is incorrect','Username o password errato/a','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or email','Benutzername oder E-Mail','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or email','Nombre de usuario o correo electr','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or email','Nom d utilisateur ou adresse e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Username or email','Username o email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users','Usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users','Utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users','Utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users','ÐŸÐ¾Ð»ÑŒÐ·Ð¾Ð²Ð°Ñ‚ÐµÐ»Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users: ','Benutzer: ','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users: ','Usuarios:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users: ','Membres: ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users: ','Utenti: ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Users: ','UÅ¼ytkownicy: ','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Variable name','Variablen name','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Variable name','Nombre de variable','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Variable name','Nom de la variable','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Variable name','Nome variabile','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Variable name','Ð˜Ð¼Ñ Ð¿ÐµÑ€ÐµÐ¼ÐµÐ½Ð½Ð¾Ð¹','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification Code','Codice verifica','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification Code','Kod weryfikujÄ…cy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification Code','ÐŸÑ€Ð¾Ð²ÐµÑ€Ð¾Ñ‡Ð½Ñ‹Ð¹ ÐºÐ¾Ð´','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification code','Verifizierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification code','Código de verificación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification code','Code de verification','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Verification code','Codice verifica','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View','Anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View','Ver','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View','Editer','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View','Visualizza','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View','PolaÅ¼','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Details','Zur Gruppe','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Details','Ver detalles','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Details','Mostra dettagli','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Profile Field','Mostra campo Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Profile Field','ÐŸÑ€Ð¾ÑÐ¼Ð¾Ñ‚Ñ€','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Profile Field #','Mostra # campo Profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View Profile Field #','ÐŸÐ¾Ð»Ðµ Ð¿Ñ€Ð¾Ñ„Ð¸Ð»Ñ #','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View User','Benutzer anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View User','Ver Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View User','Consulter le profil du membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View User','Mostra utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View User','ÐŸÑ€Ð¾ÑÐ¼Ð¾Ñ‚Ñ€ Ð¿Ñ€Ð¾Ñ„Ð¸Ð»Ñ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View admin messages','Administratornachrichten anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View admin messages','Ver mensajes de admin','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View admin messages','Voir les messages de l administateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View admin messages','Visualizza messaggi amministratore','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View admin messages','PokaÅ¼ wiadomoÅ›ci administratora','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View my messages','Meine Nachrichten ansehen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View my messages','Ver mis mensajes','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View my messages','Voir mes messages','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View my messages','Visualizza messaggi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View my messages','WyÅ›wietl moje wiadomoÅ›ci','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View user \"{username}\"','Benutzer \"{username}\"','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View user \"{username}\"','Ver usuario \"{username}\"','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View user \"{username}\"','Membre \"{username}\"','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View user \"{username}\"','Visualizza utente \"{username}\"','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View user \"{username}\"','UÅ¼ytkownik \"{username}\"','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View users','Benutzer anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View users','Ver usuarios','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View users','Montrer les utilisateurs','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View users','Visualizza utenti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('View users','PokaÅ¼ uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visible','Sichtbar','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visible','Visible','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visible','Visible','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visible','Visibile','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visible','Ð’Ð¸Ð´Ð¸Ð¼Ð¾ÑÑ‚ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visit profile','Profil besuchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visit profile','Ver el perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visit profile','Visiter le profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Visit profile','Visita profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Warning: there have been {count} failed login attempts','Achtung: Es gab {count} fehlgeschlagene Anmeldeversuche','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('When selecting searchable, users of this role can be searched in the \"user Browse\" function','Wenn \"suchbar\" ausgewählt wird, kann man Nutzer dieser Rolle in der \"Benutzer durchsuchen\"-Funktion suchen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('When selecting searchable, users of this role can be searched in the \"user Browse\" function','Al seleccionar b','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('When selecting searchable, users of this role can be searched in the \"user Browse\" function','Si le status de \"visible\" est choisi, un membre de ce rÃ´le pourra apparaitre dans les rÃ©sultats d une recherche','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('When selecting searchable, users of this role can be searched in the \"user Browse\" function','Quando selezioni \"Ricercabile\", gli utenti di questo ruolo sono ricercabili nella funzione \"Browser utenti\" ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('When the membership expires','Wenn die Mitgliedschaft abläuft','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a comment','Kommentar hinterlassen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a comment','Escribir un comentario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a comment','Laisser un commentaire','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a comment','Scrivi commento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message','Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message','Escribir un mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message','Ecrire un message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message','Scrivi messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message','Napisz wiadomoÅ›Ä‡','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to this User','Diesem Benutzer eine Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to this User','Escribir un mensaje a este Usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to this User','Ecrire un message Ã  ce membre','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to this User','Scrivi messaggio a questo utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to {username}','Nachricht an {username} schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to {username}','Escribir un mensaje a {username}','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to {username}','Message Ã©crire Ã  {username} ','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write a message to {username}','Scrivi messaggio a {username} ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write another message','Eine weitere Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write another message','Escribir otro mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write another message','Ecrire un autre message','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write another message','Scrivi un\'altro messaggio','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write another message','Eine weitere Nachricht schreiben','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write comment','Kommentar schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write comment','Escribir comentario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write comment','Ecrire un commentaire','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write comment','Scrivi commento','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write message','Nachricht schreiben','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Write message','Escribir un mensaje','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written at','Geschrieben am','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written at','Escrito el','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written at','Ecrit le','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written at','Scritto a ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written from','Geschrieben von','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written from','Escrito por','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written from','Ecrit par','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Written from','Scritto da ','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Wrong password confirmation! Account was not deleted','Falsches Bestätigugspasswort! Zugang wurde nicht gelöscht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Wrong password confirmation! Account was not deleted','¡Contraseña para confirmación incorrecta! Lacuenta no ha sido eliminada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Wrong password confirmation! Account was not deleted','Confirmation incorrecte! Le compte n a pas Ã©tÃ© supprimÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Wrong password confirmation! Account was not deleted','Password id oconferma errata! Account non cancellato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Wrong password confirmation! Account was not deleted','Niepoprawne hasÅ‚o! Konto nie zostaÅ‚o usuniÄ™te','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes','Ja','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes','Sí','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes','Oui','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes','Si','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes','Ja','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes','Ð”Ð°','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes and show on registration form','Ja, und auf Registrierungsseite anzeigen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes and show on registration form','Si y mostrar en formulario de registro','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes and show on registration form','oui et charger le formulaire d inscription','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes and show on registration form','Si e mostra nel form di registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes and show on registration form','Tak i pokaÅ¼ w formularzu rejestracji','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yes and show on registration form','Ð”Ð° Ð¸ Ð¿Ð¾ÐºÐ°Ð·Ð°Ñ‚ÑŒ Ð¿Ñ€Ð¸ Ñ€ÐµÐ³Ð¸ÑÑ‚Ñ€Ð°Ñ†Ð¸Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Yii-user-management is already installed. Please remove it manually to continue','Yii-user-management ist bereits installiert. Bitte löschen Sie es manuell, um fortzufahren','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is activated.','Ihr Konto wurde aktiviert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is activated.','Su cuenta está activada.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is activated.','Votre compte a bien Ã©tÃ© activÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is activated.','Account attivato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is activated.','Ihr Konto wurde aktiviert.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is activated.','Ð’Ð°ÑˆÐ° ÑƒÑ‡ÐµÑ‚Ð½Ð°Ñ Ð·Ð°Ð¿Ð¸ÑÑŒ Ð°ÐºÑ‚Ð¸Ð²Ð¸Ñ€Ð¾Ð²Ð°Ð½Ð°.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is active.','Ihr Konto ist aktiv.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is active.','Su cuenta está activa.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is active.','Votre compte est actif.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is active.','Account attivo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is active.','Ihr Konto ist aktiv.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is active.','Ð’Ð°ÑˆÐ° ÑƒÑ‡ÐµÑ‚Ð½Ð°Ñ Ð·Ð°Ð¿Ð¸ÑÑŒ ÑƒÐ¶Ðµ Ð°ÐºÑ‚Ð¸Ð²Ð¸Ñ€Ð¾Ð²Ð°Ð½Ð°.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is blocked.','Account bloccato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is blocked.','Ð’Ð°Ñˆ Ð°ÐºÐºÐ°ÑƒÐ½Ñ‚ Ð·Ð°Ð±Ð»Ð¾ÐºÐ¸Ñ€Ð¾Ð²Ð°Ð½.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is not activated.','Account non attivo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You account is not activated.','Ð’Ð°Ñˆ Ð°ÐºÐºÐ°ÑƒÐ½Ñ‚ Ð½Ðµ Ð°ÐºÑ‚Ð¸Ð²Ð¸Ñ€Ð¾Ð²Ð°Ð½.','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You already are friends','Ihr seid bereits Freunde','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You already are friends','Ya son amigos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You already are friends','Ce membre figure dÃ©jÃ  dans votre liste de contact','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You already are friends','Siete giÃ  in contatto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are not allowed to view this profile.','Sie dürfen dieses Profil nicht ansehen.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are not allowed to view this profile.','No tiene permiso para ver este perfil.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are not allowed to view this profile.','VOus ne pouvez pas consulter ce profil.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are not allowed to view this profile.','Non puoi vedere questo profilo.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are not allowed to view this profile.','Nie masz uprawnie do przeglÄ…dania tego profilu','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are running the Yii User Management Module {version} in Debug Mode!','Dies ist das Yii-User-Management Modul in Version {version} im Debug Modus!','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are running the Yii User Management Module {version} in Debug Mode!','¡Está ejecutando el Módulo de Administración de Usuarios Yii {version} en modo de depuración!','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are running the Yii User Management Module {version} in Debug Mode!','Dies ist das Yii-User-Management Modul in Version {version} im Debug Modus!','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are running the Yii User Management Module {version} in Debug Mode!','Questo Ã¨ il modulo di YUM versione {version} in modalitÃ  debug!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You are running the Yii User Management Module {version} in Debug Mode!','Uruchamiasz moduÅ‚ Yii User Management Modul, wersja {version}, w trybie DEBUG!','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have any friends yet','Ihre Kontaktliste ist leer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have any friends yet','No tienes ningún amigo todavía','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have any friends yet','Votre liste de contact est vide','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have any friends yet','Lista contatti vuota','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have set an avatar image yet','Es wurde noch kein Profilbild hochgeladen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have set an avatar image yet','Aún no has subido tu imágen de Avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have set an avatar image yet','Aucune photo de votre profil disponible','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You do not have set an avatar image yet','Non hai settato un\'avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have joined this group','Sie sind dieser Gruppe beigetreten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have joined this group','Te has unido a este grupo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have left this group','Du hast diese Gruppe verlassen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new Messages !','Sie haben neue Nachrichten !','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new Messages !','¡Tienes Mensajes nuevos!','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new Messages !','Vous avez de nouveaux messages !','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new Messages !','Hai un nuovo messaggio!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new messages!','Sie haben neue Nachrichten!','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new messages!','¡Tienes mensajes nuevos!','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new messages!','Vous n avez pas de messages!','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new messages!','Hai un nuovo messaggio!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have new messages!','Masz nowÄ… wiadomoÅ›Ä‡!','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have no messages yet','Sie haben bisher noch keine Nachrichten','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have no messages yet','Usted no tiene mensajes a','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have no messages yet','Aucun message rÃ©cent','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have no messages yet','Non hai messaggi','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have {count} new Messages !','Sie haben {count} neue Nachricht(en)!','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have {count} new Messages !','¡Tienes {count} mensajes nuevos!','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have {count} new Messages !','Vous avez {count} nouveau(x) message(s)!','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have {count} new Messages !','Hai {count} nuovi messaggi!','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You have {count} new Messages !','Masz {count} nowych wiadomoÅ›ci !','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('You registered from {site_name}','Sei registrato su {site_name}','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Account has been activated. Thank you for your registration','Ihr Zugang wurde aktiviert. Danke für die Registierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Account has been activated. Thank you for your registration','Su cuenta ha sido activada. Gracias por su inscripci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Account has been activated. Thank you for your registration.','Votre compte a bien Ã©tÃ© activÃ©. Merci pour votre inscription.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Account has been activated. Thank you for your registration.','Il tuo account Ã¨ stato attivato. Grazie per la tua registrazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Avatar image','Ihr Avatar-Bild','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Avatar image','Tu imagen de Avatar','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Avatar image','Votre image de profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Avatar image','Il tuo avatar','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Message has been sent.','El Mensaje ha sido enviado.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Message has been sent.','Votre mÃ©ssage a Ã©tÃ© envoyÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your Message has been sent.','Messaggio inviato.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated.','Tu cuenta ha sido activada.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated. Thank you for your registration','Ihr Zugang wurde aktiviert. Danke für ihre Registrierung','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated. Thank you for your registration','Su cuenta ha sido activada. Gracias por su inscripci','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated. Thank you for your registration','VOtre compte est maintenant actif. Merci de vous Ãªtre enregistrÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated. Thank you for your registration','Il tuo account Ã¨ stato attivato. Grazie per esserti registrato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated. Thank you for your registration.','Tu cuenta ha sido activada. Gracias por registrarte.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been activated. Thank you for your registration.','Twoje konto zostaÅ‚o aktywowane. DziÄ™kujemy za rejestracjÄ™.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been deleted.','Ihr Zugang wurde gelöscht','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been deleted.',' Su cuenta ha sido borrada.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been deleted.','Votre compte a bien Ã©tÃ© supprimÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your account has been deleted.','Il tuo account Ã¨ stato cancellato.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your activation succeeded','Ihre Aktivierung war erfolgreich','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your activation succeeded','','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your activation succeeded','Votre compte a Ã©tÃ© activÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your activation succeeded','Attivazione riuscita','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your changes have been saved','Ihre Änderungen wurden gespeichert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your changes have been saved','Los cambios han sido guardados','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your changes have been saved','Vos modification ont Ã©tÃ© mÃ©morisÃ©es','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your changes have been saved','Le modifiche sono state salvate','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your changes have been saved','Twoje zmiany zostaÅ‚y zapisane','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password','Ihr aktuelles Passwort','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password','Su contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password','Votre mot de passe actuel','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password','La tua password corrente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password is not correct','Ihr aktuelles Passwort ist nicht korrekt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password is not correct','Su contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password is not correct','Votre mot de passe actuel n est pas correct','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your current password is not correct','La tua password corrente non Ã¨ corretta','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your friendship request has been accepted','Ihre Freundschaftsanfrage wurde akzeptiert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your friendship request has been accepted','Su solicitud de amistad ha sido aceptada','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your friendship request has been accepted','Votre demande de contact a bien Ã©tÃ© acceptÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your friendship request has been accepted','La richiesta di contatto Ã¨ stata accettata','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your message has been sent','Ihre Nachricht wurde gesendet','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your message has been sent','El mensaje ha sido enviado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your message has been sent','Votre mÃ©ssage a bien Ã©tÃ© envoyÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your message has been sent','Il tuo messaggio Ã¨ stato inviato.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your message has been sent','Twoja wiadomoÅ›Ä‡ zostaÅ‚a wysÅ‚ana','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your new password has been saved.','Ihr Passwort wurde gespeichert.','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your new password has been saved.','La nueva contraseña ha sido guardada.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your new password has been saved.','La modification de votre mot de passe a bien Ã©tÃ© mÃ©morisÃ©.','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your new password has been saved.','La nuova password Ã¨ stata salvata.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your new password has been saved.','Twoje nowe hasÅ‚o zostaÅ‚o zapisane.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your password has expired. Please enter your new Password below:','Ihr Passwort ist abgelaufen. Bitte geben Sie ein neues Passwort an:','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your password has expired. Please enter your new Password below:','La contraseña ha expirado. Por favor escribe una contraseña nueva abajo:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your password has expired. Please enter your new Password below:','La durÃ©e de vie de votre mot de passe est arrivÃ©e Ã  Ã©chÃ©ance. Veuillez en definir un nouveau:','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your password has expired. Please enter your new Password below:','La password Ã¨ scaduta. Si prega di inserire una nuova password:','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your privacy settings have been saved','Ihre Privatsphären-einstellungen wurden gespeichert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your privacy settings have been saved','Sus opciones de privacidad se han salvado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your privacy settings have been saved','La configuration de vos donnÃ©es privÃ©es a bien Ã©tÃ© enregistrÃ©e','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your privacy settings have been saved','Le tue opzioni Privacy sono state salvate','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your profile','Ihr Profil','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your profile','Tu perfil','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your profile','Ihr Profil','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your profile','Il tuo profilo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your profile','Ihr Profil','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your profile','Ð’Ð°Ñˆ Ð¿Ñ€Ð¾Ñ„Ð¸Ð»ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your registration didn\'t work. Please try another E-Mail address. If this problem persists, please contact our System Administrator. ','Tu proceso de registro falló. Por favor intenta con otra cuenta de correo. Si el problema persiste por favor contáctanos.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your request succeeded. Please enter below your new password:','Tu solicitud fué exitosa. Por favor, escribe a continuación tu nueva contraseña:','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('Your subscription setting has been saved','Ihre Einstellungen wurden gespeichert','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('about','information me concernant','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('about','Informazioni su','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('activation key','Aktivierungsschlüssel','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('activation key','clave de activación','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('activation key','ClÃ© d activation de votre compte','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('activation key','chiave di attivazione','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('activation key','AktivierungsschlÃ¼ssel','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('activation key','ÐšÐ»ÑŽÑ‡ Ð°ÐºÑ‚Ð¸Ð²Ð°Ñ†Ð¸Ð¸','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthdate','Geburtstag','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthdate','fecha de nacimiento','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthdate','anniversaire','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthdate','Compleanno','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthday','Geburtstag','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthday','cumplea','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthday','date de naissance','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('birthday','Compleanno','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change Password','Passwort ändern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change Password','cambiar Contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change Password','Changer le mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change Password','ZmieÅ„ hasÅ‚o','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change password','Passwort ändern','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change password','cambiar contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change password','Modifier le mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('change password','Cambia password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('do not make my friends public','Meine Kontakte nicht veröffentlichen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('do not make my friends public','no hacer mis amigos p','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('do not make my friends public','Ne pas rendre publique la liste de mes contacts','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('do not make my friends public','Non mostrare i miei contatti pubblicamente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email','E-Mail','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email','correo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email','e-Mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email','email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email','mejl','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email address','correo electrónico','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('email address','Adres mejlowy','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('firstname','Vorname','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('firstname','primer nombre','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('firstname','prÃ©nom','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('firstname','Cognome','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('friends only','Nur Freunde','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('friends only','sólo amigos','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('friends only','A mes contacts seulement','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('friends only','Solo contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('lastname','Nachname','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('lastname','apellido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('lastname','nom de famille','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('lastname','Nome','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('make my friends public','Meine Kontakte veröffentlichen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('make my friends public','hacer mi amigos p','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('make my friends public','Rendre visibles mes contacts','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('make my friends public','Rendi pubblici i miei contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('no','Nein','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('no','no','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('no','Non','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('no','No','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('of user','von Benutzer','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('of user','de usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('of user','de l utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('of user','dell\'utente','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('only to my friends','Nur an meine Freunde veröffentlichen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('only to my friends','s','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('only to my friends','Visible seulement pour mes contacts','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('only to my friends','solamente ai miei contatti','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('password','Passwort','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('password','contraseña','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('password','mot de passe','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('password','password','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('password','hadÅ‚o','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('password','ÐŸÐ°Ñ€Ð¾Ð»ÑŒ','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('private','Privat','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('private','privado','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('private','PrivÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('private','Privato','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('private','prywatny','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('protected','Geschützt','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('protected','protegido','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('protected','ProtÃ¨gÃ©','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('protected','Protetto','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('protected','chroniony','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('public','Öffentlich','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('public','público','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('public','Publique','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('public','Pubblico','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('public','publiczny','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('street','rue','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('street','Indirizzo','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('timestamp','Zeitstempel','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('timestamp','marca de tiempo','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('timestamp','tempon de date et heure','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('timestamp','timestamp','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username','Benutzername','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username','usuario','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username','nom d utilisateur','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username','username','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username','nazwa uÅ¼ytkownika','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username','Ð›Ð¾Ð³Ð¸Ð½','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username or email','Benutzername oder E-Mail Adresse','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username or email','nombre de usuario o email','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username or email','nom d utilisateur ou adresse e-mail','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username or email','username or email','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username or email','nazwa uÅ¼ytkowniak lub mejl','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('username or email','Ð›Ð¾Ð³Ð¸Ð½ Ð¸Ð»Ð¸ email','ru','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('verifyPassword','Passwort wiederholen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('verifyPassword','verifique su contrase','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('yes','Ja, diese Daten veröffentlichen','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('yes','s','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('yes','Oui, rendre publique ces donnÃ©es','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('yes','Si','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('zipcode','Postleitzahl','de','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('zipcode','c','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('zipcode','code postal','fr','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('zipcode','CAP','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} is too long (max. {num} characters).','{attribute} es muy larga (max. {num} caracteres).','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} is too long (max. {num} characters).','{attribute} troppo lungo (max. {num} caratteri).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} is too long (max. {num} characters).','{attribute} jest zbyt dÅ‚ugi (max. {num} znakÃ³w).','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} is too short (min. {num} characters).','{attribute} es muy corta (min. {num} caracteres).','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} is too short (min. {num} characters).','{attribute} troppo corto (min. {num} caratteri).','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} is too short (min. {num} characters).','{attribute} jest zbyt krÃ³tki (min. {num} znakÃ³w).','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} digits.','{attribute} debe tener al menos {num} dígitos.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} digits.','{attribute}deve includere almeno {num} numeri.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} digits.','{attribute} musi zawieraÄ‡ co najmniej {num} cyfr.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} lower case letters.','{attribute} debe tener al menos {num} caracteres en minúscula.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} lower case letters.','{attribute} deve includere almeno {num} lettere minuscole.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} lower case letters.','{attribute} musi zawieraÄ‡ co najmniej {num} maÅ‚ych liter.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} symbols.','{attribute} debe tener al menos {num} símbolos.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} symbols.','{attribute} deve includere almeno {num} simboli.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} symbols.','{attribute} musi zawieraÄ‡ co najmniej {num} symboli.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} upper case letters.','{attribute} debe tener al menos {num} caracteres en mayúscula.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} upper case letters.','{attribute} deve includere almeno {num} lettere maiuscole.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must include at least {num} upper case letters.','{attribute} musi zawieraÄ‡ co najmniej {num} duÅ¼ych liter.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must not contain more than {num} sequentially repeated characters.','{attribute} no debe tener más de {num} caracteres repetidos secuencialmente.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must not contain more than {num} sequentially repeated characters.','{attribute} non deve contenere {num} caratteri ripetuti sequenzialmente.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must not contain more than {num} sequentially repeated characters.','{attribute} nie moÅ¼e zawieraÄ‡ wiÄ™cej niÅ¼ {num} sekwencji znakÃ³w.','pl','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must not contain whitespace.','{attribute} no debe contener espacios.','es','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must not contain whitespace.','{attribute} non deve contenere spazi.','it','yum')~
INSERT INTO `translation` (`message`,`translation`,`language`,`category`) VALUES
('{attribute} must not contain whitespace.','{attribute} nie moÅ¼e zawieraÄ‡ biaÅ‚ych znakÃ³w.','pl','yum')~



-- -------------------------------------------~
-- TABLE DATA user~
-- -------------------------------------------~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('1','admin','d25072a73a0334c3eb70bd09284dd63a13b47d8958d86d23e385fa388fa5df0f2d1759ddeabd3e47cf67d472f0da2e9c2b3c8b563aaf566c390863a812c7cd2b','NmdJ9FJuI6+aZ48iwGBdHgDExJt+r3E1RmbpmLCyvoWH+TxCgjrrI9JqcJ7/MnXghTnsIo4ABmXDRTx85aCpOw==','','1361032777','1371719505','0','0','0','1','0','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('2','demo','5d8bec00933747a9c32698e358b6bc1e12befa94574517e3d15e071719bc0d0260c134452d53c046c619d4d4e9c0af2cb93e93c3f473facdf6aa8d64fe87ee0f','qkbGr8rCH2FVUcsMI5rRDz/H5Tpfk3Sp/Ncs4MQnYslGOM7gC96afvjd8p/cLb8irst9SZTGx1IB7yBSSjysWQ==','','1361032777','1366882143','0','0','0','0','0','1','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('3','dexter','bfa8baf8e30cffabd9be5d338748fd60daa33d551488b44a6cdd498fcb528347e5883cfcd719ca2580577b7297c3d4f21a82c81222b83353ccfbb708a9e01447','Hp/WpG3F4/OHYjCF5OYbsEgqMYuEAJO7eTvCQOiFN76zqllsluKZaHQJecMnulZq/w5tUAfqpcT0IDv9zi7lFQ==','dabe871085c6d7445a9e1eb46ec4aa584a06682c1d4cd4b5f227ea7761905bcd3a157e8286c9257c061d88dce8b32052b353f1851a5b9b235f810b774b99cf8e','1361034451','1371617319','0','1361034743','0','0','0','1','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('4','2007-04-05297','f7d3bf8c6ceec437d65c691f431424e57e58029ffc37addf37a965968f1dff37c7458bf23b254483f883fb294fd53f06648608627a555b8bfb2f93788fe26f03','BPRnK5FFiQ28yCX4BSOWcXfgSDsYGhU4GtvPh+WpU3fiwvPTx83n7twp6B3ndpUCpQJVjArNy5dTZs+iBNRzKQ==','d32dbd958ec1a8204b0bcf2286149ddbec4c605fe6072a3c0561c6b9b5e5de4fb1d86368bdca49f1335056c9a0d36b9e554aaa714f791e7fd15dd713826a66a5','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('5','2009-04-00234','87e01b97bbb1ea70e99db020615cf4460d557465ee9d0819c08fb176a56d0f44df8f187d4492d91f5e823ecbcc443d2041a18355f249504a07335bd9f51afb3f','ITtnMq/U9Sdpy46PxN1+SXKBY9LcHdAeUu/yhoM05KCnbNOlWraqDar0jCw2DATJCpmjL9x2Bc8QmSqdHDUk4A==','9611ab227353c49c13debd5ee58949a520a619bb04c8660ed017654daead2837227d272748a6305b31f1c8ce453e9a8ccbba8f8f81bb4fd484557dec8e675f05','1361363195','1371708329','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('6','2009-04-00277','16d672ab5cb4e7188e0a04602672b58bfa0da409ad642a2fc79214b114fbc94527b5eee638a1cec19686ae0dad2962ef64e566023b200ee5bcd5a747c9da04fa','B1CMX7qE1sptxCBzlSMXqr4PIsO3zRg1tNU3Wyg5v5mKOjyRN8foR2rCw60T9+yIZ61O2afVFfQBIEr0r/S79w==','37a7918c954321c43c8d474ad3a9b23113d16346f23b289534dad4fed69c976fdb5f1911ec069a54d000689f1ad3aff7cd11396adfc2fa9f5af11caab122b843','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('7','2009-04-00387','87143c863d58e6f2c743fa447e3b976569f58c65496f4b361b620ac3e057e41354bc19b35824b7db19c6ca3a4088bc9014e319a483f907413128bb7ce31ba6b9','+7+LS6a8X83SQWZ8crIH5s4xuz031mR2dYsz7nWxkHyRSNPI7XGh8uuwK0uPI/ugj1ZRKQxZ3wQt7HCu3/DBYQ==','f5c42db4adca38f9ec99db68660b71ba54b6871918e9fb88e027ceffca4cef704d6101b229225abf0ed8626ee9637f5ede0c2da9dc4e70f5672a94c34df4445d','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('8','2009-04-00462','22bfc0ed800f1206023ca2ae96f1ec5dc5bbf173e52409d49638ccdfc716ca8a03a08fdb24e2e0e23ae1d6727fb47735b6f9453c2347848c2f560b4fb4580b51','GJZ8ob4duyH9BJ0vomw7mIFpsHL0WVsLrQBQgYWySTc226YgzJFuEu3BcrmRjPppbffVgsE/amw8PBM92lhCWQ==','ff75afb77b8aeb3e574e7fa9c20cba91506538e53cf66d27a9153d2d11d8f63dacca1c39325b98f2fce5e5912cf6e47d56cd3d4547d74377a2103d81a63cae1e','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('9','2009-04-00691','f1350c0a66c5b762b0243da38ac1ea298cd21c60bd25c7431e099a6dec64084c69a45da57df0f017ef9846821b8244d40e82028d73525077adb9d7dcd6bdce43','Si1CLhOXE4ca6v4iYfJHpC3C0yDJ1Dgypzne97DnSIR6Gq0fQHvS1wgOKJVchMTGGZLPP6iVn/XDiUk7m6EFfg==','8ff3ce43122719da9be5fe39054a3ca12b7daffc0bfc98e1c9166612cf6a14fcedb41dfca42fbaa91fd91c8d952d798d3c5a97d44ed5bc96a5fdd5b7142cb1f8','1361363195','1368179122','1368179263','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('10','2009-04-00977','ad2a13a4faee9d094863027fab542283b6abcf80ab32b79ddb84512f2ea0ee48b7321bc7bdca2e3ceb061fa392ddccab843a91650666d4ca3add95c949f5a034','UxlVRcmGTXXQPaia5ZTxG/XqbE9Tjki+xj2rI1R1/G8rpQnqWR3MEx1pHZsDn9KKdr0hAFk715TFXgrmkF4fwg==','0bc6c6f4c66375acf4103e037b1101b7a6c91017541d705ff72400a2cc9d767d8c2085f84c7c648624e36c812cbfa5bfbeac6329b30eefc05bc8200c0475232d','1361363195','1367251754','1367252002','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('11','2009-04-01054','77c8db3b7a859cf814720f3b0cb73167af634fedbecd9a373dd0da481c290fc521530771cc61fd0825d8c1bcd21ea5fd500d63e0ff70bba39b3f039df8c7b804','YfSKiEtnrFCL0YXQ4r+SJ9UpH1qx/O/ZjsOCbnf44oGo0rDBS4c/5mTp57ka1e1acje2tDnyw1JTOUu8YumfXA==','8b014dcfaa13f29f366accc82662423d18921316cbb13c678c58d5a1cf491e4557a632b3978f0e85e6ca3fd07d03f6706a97d27c42b818731fbb55560262bb69','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('12','2009-04-01296','686c613420fa6371f98053c173bc5fee398098aabbfbe9f00b3c180eca948343654165e535fcc9f3edf6c192c3a5d9d72022845d68ed39c7214cbba9825123c2','HCFOnlgtMbF0T4Hg0vBJPrF2caBjhRV8oH7iYJaQSaakGdeEbbwXkpj03NdtRm4BsT/jtLuJ/wLUUHDvV65ekA==','922ca581f828d83a0aef41abc99bdd7454bcac473e1dd03e0ad69ff6f512ad15e66fa3b71711f2253c1bd2e19d481c68d41dca4dd3588c2afe36dace746cb31c','1361363195','1365658177','1365614660','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('13','2009-04-01337','41e35e4da76e5ecd3f5cfe79fd4fe7ae29e42864daee5a85700918835d1ab081a6a4b3947b2521bb6ff3388f9f113445febfb92ebf70661c25a535ddd4b5e140','WoorupQ3AJmmwCCmg2iT4LF11inEtym2WvPFUZuw99uIG4JqxJ9GsV/QKMqNjByLMO6zCXbo1gpCQc25ay0M3g==','54a9e8867420e443cbe906955d23ce71c2bc9e3bdbf8cb813fce81ce77980a6d78f11667e7e98539820d446f8c33a89db51f7b4e93129773998afbc3a9c891ea','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('14','2009-04-01407','cb6e3700d417ee14198f2b63016667efe75bd89930f8ef4e7319b8fc1bd2c9b85f5ba47d7a47e15080dce39788495e6a4461530c4cbf692bfaebdceb6bc78d5b','D5iBuT2PX8MA+hMzBKLZX2nQ6ehNEfE8ROmdm/FEShtxvGdLVqotwG5LUlQwHF1Jo4mCDAkUunbhzKnPG5ecLg==','978ba773c8cbedc85bac20d53c54f17a74eef0fb20bb065c6ae55e807158ffc690d10618533bfdd18f1de7d78a53880854857b3ef5c5dc23f26c0ec4c1df26f3','1361363195','1366520453','1366524902','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('15','2009-04-01517','f67332549aa6f54ce82b0e65a3a1fc5444defca3bb2a3ecc4358ef18d36c51a1c44b4c456a89d6d0ce9e910db44180a0116bb3d03f087d72ddefbcc344998414','6ilN1aWcRICFP5Vqd+GdtxBXT96Jlmx7/N7i7xEJts9yh8cA0hkdIpLBjMu2hXlboxvyAnbesD1aBDXqmgktTQ==','b35cc3d060ceed66ebbbd1bd6cc659ec958bc52055eccc33b8b69c6b07fbecb3739e8e35cc9518dfbd02128e6b29b43f706ba5bcf614ccea0d53cf4d501f7817','1361363195','1366865944','1366866004','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('16','2009-04-01526','c2e6d27f79b8adea848c80e98a2e22d4de76e81d082f0a10d371fbaf32957152f450484cacc13865130e09791cbb8e50883b9c092e9467131b2fb8b50a1e892f','uAT+1cKhBC0fHU8rDClCIBAeHRrEWdWJMKqFYT8dI03yQnM6FJJwxd9sEv90iADj+c2zJrjYRFFd3xAySRMImw==','1e2206baae7de3bb366fe39a17bd4fdc0ad0373931b75b39b69d1bc17c121de5e4242d870f094bba80f81fc7259abdf8445b09f35d1aa06af0a3f4538d2e87e4','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('17','2009-04-01601','6655c6e8d3d7ae9c4f4eb05a6b759918250c7b390cfecef8567ac7b56a332a2c8037b6d640a20d9bb2d73a172a03a9907438eaee442b9a4db2915f90066b931e','jp87+QR1OnIf787M/N2OBNUGvDvzICVVc57eEdnPpbZviEf+dsjPDEsrdYo8UGCFuPAKiIKivGbWqtWNyZKndQ==','1c9f436a60d4ee3e4ce6432bafe05934d439d61ef06598a8b8c5ce5cc6741d1f9a8f5bcc17935930b0969f8765ca54aa7fae9afba02e9ff69d1f2b84f2bd24fe','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('18','2009-04-01603','23d7e3d1299b2b0faacb3fd16e3ee6b2097e64ac4b2be3e07ea01bfd76d8d1e27ab16e5db7f74514c06b29cf4a53b3515268cfd32de672fdf31ac6d24417583d','/oyq0kQVX+5Vejm0EoW86DDPWy9uEaKvu8L5yJIex5I5Tf6rHWfm26/vNzKNIsrUMrd6eagda+wdspEOAa94BQ==','0d0f43b27b4b5c7daa4201b83aa10d0de5dfc3044cfbcff39251d22f45da06ffd9a2c082bb0a2f0315f00007c5705cd1998a241df38058ea82408abe27713991','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('19','2009-04-01677','fb444a054148c46c3a5b175dcfea6ab6484dcec1236d8bc70008e1e3eb731c9e776b2a2b9fc0a658be27bfc4fffd2d069207bcc3033dadc48a966dd1e9dca342','izSpeIhCj/SCEOhy76uyNjbOaJZo9x3PZAlFJOuMw+rX5CjXaf9EWuxGAuhKxXCITzhNRWXPRQ+DLPDn1TOy7g==','4bd3388217d15f97bc4ed09380f6da2a860ec28c488778761c87f454a9974ae3b2dcb3eb6b88f52b52f3293dd9d000b13763a3d0fac6b9f181fc79f4ded1fb62','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('20','2009-04-01733','a3ea384fdec72e0e0b027102c5ce02cb7c2e656ba6d5d1dae9ab08c184696765040b8a822c7977bd4679cbf99e20ac28536a8ffb380ef15767756f92e832af00','OgL4qBK4RfPT38CwCaaShpj1e1MLDewDisFOsNuiMsXPQGu+ivxBUM7ohcj7taqv9W2JtEmhJznafjXsDDnZ6w==','c31087181a0f70aa6a3e4a7180bdcf557febfcd44178aea12453e57330d153c7617f216ff42c5be12f78b7ecd94a43d2c431e2a639c9359da5e17daf6d23c3bc','1361363195','1366877965','1366878265','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('21','2009-04-01791','3be3884d745ec582777578b7be5ffd806ffaf381314651e4941b8c1d779e453645d8d620eb1489eb395a98325ac5d4b3fae906c1f8bac09c881275155dc4d09d','dk1JuVFSHdX5RxBBvqWQ7wjK0FFAaLFEB//bCy8w1qMPJ7/bK5HOC2/MwLp1Y2X4Lk8DGhYtshmqWNQTb+pR6Q==','2b415de232ceae8d387c6c752312c4084812a8a8581991df9290aa5f5aa9a2e4502ef47bc3a544c1318e010bdfae4f940220be13cffaf57984df8389995d42f0','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('22','2009-04-01805','11b4f0b1c0acb0a7739f1073e0a41fa9cd2e65620edf1e8d7cd0842bfc46591c00b3436d7c3bda46ac238577d8e957c9f980e594639bbbf04d25da88b82aa573','8UDRj06LQ92LAj/Z8YiC7b1JuKQFe7QFlZ2lmR1WrWYcylH2g/JMcU7ipalbbUM+co9XAK/ELCLItJLG2V69Vw==','55a625fe5bc816f2ad4b1c32fbc618750c24be7f93d19f72a7ef1a62b7605d4870d11fead767d95f20ca03accb7297ddbabb146c27318621403344e14dafc8a9','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('23','2009-04-01971','d93440ccb8da514b6c34d4b0aa7c57ea182bc56a5ef63ddf3d15312e180f8c85386c5338474558b13915d7e92839beef07f58f0afdcb4daab90163442cdb0aa9','ifaJN77Aq3hnJslddXKUJsceW0+bRUwiJl/CxeFyq23sf8ee9Y2+sY1cysBYkdNlr79bFvorvO7QsVJ0AYuigw==','e1a419c187850b77f952a564a164187afcb2a5fe30e1b1e9e47ffa19936a15e8a8d657c84163b706ef34b382a5146cd85b41431cdd44eed4ad13bfe5f775e0f2','1361363195','1366972770','1366972800','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('24','2009-04-01986','8263f70cc36515afa0512b57117b3a065e8944c7537d5604550fa33427713dbd90d1362fb1301316084707da450ccd56b8031f6a10dd747745f22f6049a91dbf','hdYfc93o+2DW1+7pV7xF73FzWiGNQGgVZ4iDIdM7T9D4TRGvg9z8wBEVqQb9xQ9VTOFo0ZY6PD7ZSwq02czlWA==','9edbba819512fe4a644846b2782dff063ac6d05c97189332ca17cb8984ce6a42ac63f46bff4a5543080a8a6aeb1ab9810a8352730cb2701090f24a156b4c1bc3','1361363195','1366866015','1366866084','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('25','2009-04-02039','b3644fff9e8d7beb1ecc87f4a9bba6cc10c349b8a616cfdcb526dcff84f95adc965a6bf6367052022d3f3422e72c3be0b139252664bd000591a5761423d2608d','UxAK42sr9E22gH7I0xCSzr9fmwZeGNDCCYqaPuOFbqJYncG+Em3NUWhPZEwtGIYFXjxlvMUVq9IdtIDajNbPvw==','ddf8a935557af044801a5cbe766a914d865d15f75a4792f17a5120d11c9ed0026379e1986cdc9f503b807af0c18afdda11a7a5a2daa8d7ce9743c21b121775e1','1361363195','1368184194','1368187225','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('26','2009-04-02109','5795248690a0e1de3fc88adf9b003f9869ce67428449e23c351e01dba24960de35213a94cd21ce5a839ab49ed912312685626e3c030e27b90018576f7087d65c','khDh0c5VBN3Va6/up8T7Gq7rIrQ5TP+vu4sRlML9CY8QHmIYDZIUDhXGSMi/jpDTDRFQao3ZdbasMHOyPmtJ8w==','22dab24ed087c2429cf19aceaa317acc66cb9094fed9930236d188f402674285ec2a826bc8c953a6044e6e30e3cb5da7dc05adff6ddb359ef84f19e65c06a45e','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('27','2009-04-02163','27ec313597f6cc170d2f387672c2fe3005bca73e70563d05d9dcfb276279e8d051038ae3833e2c65cffa126bbcc36373f46ab775b2941a66b4a188ec5b74373b','+kFAv1I2FLB+EtiKwixiTZNJCDIvnDm9MXN81Qvff4NIqTdT0/VX4JHfsPxz/TsSc5B8csYwuoOesfP8fgk7tg==','9617561060ae4a5651fb8dfb942b92bd21aeaaf073558e8125607fc48d853496969203f728f9f7dc7025148b861bee50b73b2eceecf60a646a47bc3413a5b52f','1361363195','1368187272','1368187289','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('28','2009-04-02183','72b0a8acfbe565f4e3c5e968e73afab15eb965dcfeb816248379f94abdddaef00a9a206b7e5e26f69b756dae7fdc40dd4400f61759c15ec51702175ab37d79b8','ZCTNpWm+OMKcceOHrGlHZ509bNHsIoYK5ekVLvLaPL3zOS3VlkhwYTiaCfM7BIY30UgqWV8qWP5IUt/9M+F7OA==','02d796b946727ed205b812d004fc9174cb61520ac780655909b24649449e3bd58b640e2ecbda8ed4f3f6a23ec7c3495c12578c13d7dc391c6dae96cab8ca5c64','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('29','2009-04-02185','c685cea2f70f04d72b638846d9de1c950e575bbd33fe19ff4b53484c0d5522cbd978fd76a5a20e1f4210eb4b70294040c5be52bf847cbf0a76a5b6e7111fd06d','BW2LZwS1KInKvRlIewGNPaUcpxUGNR4/JxQlRXTbOSHh2ophFMPVI5Qh8etuYJLOamc8dg0TLzDlyOKRdREHmw==','738162bec0b91d3a477a5bc2af40d0f6fcc3104f9b4118104bd469f162b8e812fe718827e6480e14846f7d34236f898bbcc4ec27a3cee4f1630ab842a70ed570','1361363195','1368187301','1368190043','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('30','2009-04-02347','0fca080e72d86a585b7593c6dc84a42e4d218f3f5a98b4c4e777fbeb1b425dd6719f1016ef33ddd0e5a1f39cf5ad0033c1e47bc0392759f8cd4b99852d9a7714','zeuzstDQmJSCDCVm7PVuPsV7gAvSJqq7QZ1hDf6+o926sIFc22dg/KXzmYRTTgwFnpD0lmJ8eVZKjqFg/wwA1g==','56bb207e9d24d7202a14892a757111df7e314ea21a16dfae2a09da99c807717ce14f86ffb127e5cd9964e71034af0ca314eebbfe6fdab7910680a4033fb4c541','1361363195','1366866104','1366866222','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('31','2009-04-02426','34dee5f78bdd155172bd7c08a97742f9a1d91119140f5a2639a92e711bd0f4b6d4e0ad33303b3e824421e2f879ba25a14bf264b7d8062778163d3430f4f9e979','//faF/Fz0TbErp/rZRxRl6jtENiPTyTPISvg454rs+SdPNHVHRNdDg0RjrrnhaT3Y8rXmvY3vc9XqBvqLtElAw==','25e594564044f44a45748946db9fe0b5040bcc9bb6f98915cd14f939f79b0639b84dd6946a9ea78653226d615ac67d343cffcd2e2d5afad113165d8181c59a04','1361363195','0','0','1361363195','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('32','2009-04-02636','ccf65955be61f7af9e8027213797d09f97a59373e9315cc076790529f8238e7dedcdadf30df993d5a5043d3add72cbb462b8dbd633162c98f7ae6917c7bca23c','p2l1u6TsECCg9daf48UDheQbv1jj+5See/uxNJ0+Wq5JPiT3AOZ6nxX1R37WEg8JEt0BH3hOnKb6tF89e623dw==','cc80e2fe978258bffe9b434dd2b320de726d437f790af80166b44cd4d1237371f9f4d0beef73c7b45a6445980ec7793a7aa36f76b5668cc32ec85309650aaa77','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('33','2009-04-02638','82597f03071fc0cf506d217708a0e7868e9f9b417ee0274e48d161ca763e43e1b18f8c61657b76c8c041e94c284e62283131238775973b518177c1f188c25e2e','K1ksjG/AtI5cY3CSxaA+k1BUuz5y0UyawQCmzCBFFYZgCCRMGDf+4AyDy/k3LTUvhFA67HF3KY5wbs8BwVWsJA==','4a9448aab05576400eceda702208eaf3b54cded59b527ca8c848f3f98909adc344e6fa5d80dbfee2257b22a42284da9521af56e4001affacc643608b54fca3ac','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('34','2009-04-02714','bd2e393211c4a4dcc0fb0da21b8fda12f80ae1145b34c9af05ab19f5ccec8e4abe6f72933b9958c23744aa81de6c4e31993a2497525f31427741142e66b9b98a','LFbUKXtC9bohyuylMKnJ37fF5DXd6BKf5sNKXsmzq5lN/EeY1JxwsfNgI93fo65Yzm7HmNtxjvMZXr65izJPcQ==','2e547c90274f3841206b7a3f56f225df742fcd7b045b841cb1a81f8e5b2ca72ff8517c70d4e3fcadc2996823162fc919f1d915de0c4755eaa915de1a7ebbea36','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('35','2009-04-02747','1a2d6cbd77448a552107d82a129c8a57c26da324f95812e1e3274a3c6c90ee26991c0b322160010852f532800a54b5fd42cf4bb3aca415153b822169991d6833','VsMVoKHWDAQREEBayifkbCqBc2olebN/4eRtur14Rwz6UvkJyGDK4mYOYqKujJg6o6pmYsE6VbXPqg7Aw46Fow==','298815ae74c601e66c94e5ef99048ce07796afcf5ce2b15aa96b9948446b10345989731bf37a82d6f5d04ce66f916c48ebbaf4baa9b1038b0a95a607b248e8c1','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('36','2009-04-02750','880b2748ec81c7b41efb4568664405fa6c00ff7a0a425c97aa34a5b93b52e2319615e3a250cd605eeecc0fa184b3cd75afdb19e851007763f3bdc6c86b58c07d','CqSRUEK2Uxm2/5dwhly6AyE97H3w/0AbPbDqoAvy3YTSo8GUBeoMGQsZDncNZyenkb82UhF/oJRDat2rsLy2Kg==','9c3ac52897250ab76e0e94dd1910b0fb592b7e3d2571419e867a5175f57851e3fe5b951526822632c7f4c23b41879577821dc0f283a9454157fc1573166b833f','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('37','2009-04-03092','e654c061770a5afb6052b5b6370f9fd07b4d26f3f8d5f81058be59ba5ea048e2c57ff5955dc0de57619ee61c02847f7a7f110d205e7f87a875aabb37ed714178','TPpid1ARinR6IugV2oUfOAt7hLOk/8PjyzYFEOQ0LbRzbuUoMoDQQKxRBeFsaRVGSjxa5AZS0HT5G6nCvJE4nQ==','2afb4c9d90bbc8a17a2e395d4ea6a9ce907025c44cb9205e768d0cf0b52dc82f9c65ff18878e774123f61f51249edb8f6cd88ec1707084c0911b03231c7000d0','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('38','2009-04-03325','6460c371bfff6bbf8a42f2c68fb792a5bb5951a823609c6abbac41d70975704576e738eebc246baf6e724fb97a2d5a053ea584d7ce3b6c22c258fec5c1ac570c','xWhfscmyqFNT3m8zXAmmWgOMvy0Gp38FyxNLzlO0SA/S7bs3y5+PW7g7953sCXuBvl/NuShfgxsTk3JcHfo2DQ==','786ea476d3a4ccdd7a7e1e8e58e1c90af14abc26a694af783f528931d1d561f11faf08346a036d0ad249c48367e8f5a3b952c1c9fba76efe11eaec39f1397525','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('39','2009-04-03342','5475ed01cf8956fa6a660e54ad13f1c5e173d5b848d28eb93a737dc03694924235bf87668e0f7a5fb43d40ba71960c1366ae61c55c476f2bdf2d520e779ac66b','c3KBJdgxB1IlJfJIT+YVfxF2yrtAgOHTbUG8GVUCTLzoyGojfwZHiti7IfwviEqqk5B1yGzLnxTfhbYmHEgJuA==','d3e934d1fab630039ad2c2c82b07171773546a5fafd187f22fc4f3f656a1c05f5f3bae95f2aa7c61bbd3ed3211ab11bf669e3ae8dc263787544d1042cdab66bb','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('40','2009-04-03417','7d7d7742aa323eb0801dc82f9160da5fb6b5eb6c2a7c4bda54fef032cbc684a186aba5bbb73134106c0732fd466f4e994dd1c6b61c3e6c7dfd8e09536a956038','e2dHD/aa0PBwOWRg1Pfm9rjPyICKhND7VStH20u7jbG2yyOx9f54ToDwDPXJLdt9KrGNCyu2IWos50xWt+6zag==','bf9bd997e4dd7829dc42e31a5c2d333adce4afb8990ee0428efc8a5d411ff224b53755b5bcb79365e8e1979315c438489f35e2181a996f8d0ec400af7ed71271','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('41','2009-04-03493','80fe0e50e39047b66e0d1ebcbb7a2aa99e8b544421151b59a10d23d338ec433ff0c7cde0064f589b3b3f656bfd150df57418ace2da2f0a9e11ae136a2b432fb8','e1qB1bCRMX+fe466HswaEalsmnOvrsldbvQ1swjazTUz9Xj5zyTo4c1LcUiJ3goNLrAtc+DZ6AiJ/noEkr1M5Q==','0c2daf2ad822098a445306744956f2ce9f5119a03ccd55d478879a10d3eb0625fee45e0f28dd2000f7fa91db0d290b0869c164f14e65cff40cde71d3d00619e7','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('42','2009-04-03683','c5a8b9f531e2f8219c02493c71488ceb6f446149a89418e637bfc9851fc307fd1f154fb45c2505baed818c12bca56e8b7357b44fb5c0c6199b928951f8bcec5c','pF+bLTodMIG0ZdGBSdJqp/2KsVUyYay/UGRm9L+uiY+IoNNSNmtL7WevU3dimRqsi0aj4BXALQi0QhgUmYf2pA==','00efb87101b6557d24900b963ecbcff46e189c4d0a1e0d4d3937eb1bd4bd572b2a06ccba42ab13a26c3e7c2cf8a370a8b05867eb06639fa1ed385c6524ba900e','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('43','2009-04-03944','19bed78ab0257493d61a31b087bec9fcece540436bb9ffa7cccb0942dd1e624b699c6039b6a32b6ce3f797517f57b2f6dcb0e72b26b281030408379f01e9652b','fAsoGEgYWOYeNUpbJkcKBI8OVJjzONHd5RYswVYlpxmeWETByeFinrgGq4Trkvit+soXowRMFBTmiuGdVsgvdA==','7ed9aef54563f55157f53e26ac26297c92100a6345afe8151b53f784396a7e3a7ff98c6553aa63e3c2a032542b47a902a9b7509b387851cbceca1f8a5977a7d2','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('44','2009-04-04105','a8eb9c70a3c9f1f03a1da73c599a2e07c7b6b5c378959994da5f2ea3ed3492dd2f21aa0d0081b842eeee95444769b46b648920ab7394d47f44f0e9ed434c9d10','3bxOJXBzXZpzoqaYzxzrDwFefOX3t/PoZg86ZopI/Ok1e6kSU/rgb7LOMw2Lhuu7RlN0+cxrtcj9B0wMOc7eng==','50576f9ab372a0572d72d83f0f138191dee5f8093da4f2b910a1a6ceac4719d1db08c95dc1e6c79c7d3c7bd00bde8dba363698ea63813df34cfed704f2d3d0cc','1361363196','1369729578','1369729656','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('45','2009-04-04113','9627005bb42f26b19fb9d4e1712db4a7a428507f3c43e7ce5a27e077084ad05c3c15ddb8c407048ec56818eb21f7e5d408fe3b2122fb0c70962a0983c68aa3fa','k144dMT4d9DTBqggyuZi2EOXWOQXUqrDwkvAqASb1X2sIsdQVYLbrqTcNkO2q+1dbWZ5jyPhVQblQE7851w17A==','e01ef60bf329761be7d5f48970bc188759d195285d46b5d6c9932e071f1dd188425f387b558639f6a9f33353718f06b5f957f8da8a7642911e47dbacb85963b6','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('46','2009-04-04216','2036fa484a9818822f4d0079e3a423b57938f69a61b4d43565cf51f78571fb68e91d9c457403423b4157f871497092450c34c6fa21c8ffb3a3b5b3b3e9f975ac','14GrWRYOwcb6paFnvr0W/0XMQmx0MJ0yBB4ohwF/jGLuPs8TseSMkv6Nusyz1AZgvyBUeZH1+iJm9n3PYqZloA==','c9d0f06704a589d7599e050d1bdac9674a552954ab4d3f619c4e6203290f3351c060b2fe66215618263f4ba05d0c2bb2edb61928aa38d56dad83cddf0987db61','1361363196','1366866989','1366877953','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('47','2009-04-04570','095fd783494bfaa3637b97a05859b3e307b949ffb6ad275f3471f8e359c56a1698042fed920d4deb09d03a489199e047448307103a3e9e142e6ad92ecc6cc3f1','cEN46Yl2nZEEs6SX1bldDrlOLnUbzyQc3Qa7a1kciqE8KnxwPleFVUWAZ3jx+HaoPEL/ZgiyzSAiG0mGvP4iRw==','8bc12a986ee8c661043c8caa5b7ba724d4128e65d31fd8d31e29047e4ffa745f94594b1b18929524bf7aa75051c15608ed383e1ad37c12ed93ccf79ca98bf0c2','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('48','2009-04-04669','3513d90ac4f812600ac3c028ec45e31119c54171910b4226e1ef9797167112acc4e437eb9d874819f5fba3b37a75079706d56f82d5bffc190a2ab5d87e0a415f','9g/FUmWCA5WEYtZsOKRXEMj/p+ICklxs6oIEVMveZRQkWTfndq0kZ37NZB88xEY4O4YkWqiR1+JC7gH71VrGIA==','113510dd327fb27f9ebfe9a06d7bacd5e7093afb7e06aae0f99302fc5f9dabf65a5096c3c8283b12045f9b15833ea07dd48b989d1cd51941551f7c4a9844c747','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('49','2009-04-04754','0f57fe09bfeebbf53731aa6978e54813344612c57e30176949870066979dece5ddc8002f18158d0aaa31d66dd9901634cedea520e24020d91323ac32dd88c4bd','VleuwxbXlK0d46GqxTXkykcduPA18b42BSRw05DLV83mukihlUtGyUf3lS9uGgoiLQ+/mi9ibqJas498PWNQSQ==','9977f9f51842ac90fe6248b246bc2fccb2aa8819b7d1de7082b6a80e382275649ade94a501f2431b7f1e38c495b0fc436a84290dc985efeaa637854613ac7872','1361363196','1366866815','1366866895','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('50','2009-04-04850','5983f7e671509654cfe41a9b0cd2a1f3d45e0674cf999c0d5a716a9a56641c7a7bba8ea06d1bb0e5f61500252ac3390315d59b6c122f4489e7bedc8330d4dcb3','jao7ZkK8dgkwT2+9waKOzAfUoT7xCGevHPs3Idb9gRJLhvzPRpWCuOoRdpvZ4L+Us5sXKu5yaSE8WX4iFLNzOw==','d0ccfa333c42141146930bf8dbc38ab9d33700b186d1c045cd3d0a80a2f64d587ef6fa19cc40e8901e4d2c18a415c7d29fc33d3117752ecd7ad49751aa3b6c5b','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('51','2009-04-04863','2c31875d1d439cbd1c6be502fcb2c9fc0c7b966c5c1a408dbd613a097713426d5f8d259fc0f82c012e59974115800e48be86f41cdf4def615c547cac552ca740','h+LrxVPGqdJuDRJ4u7yKJXOjUjNjXeBvQtQZ4RiwJkELcaktjZG0i7Q2uhY8ZimwWNu2Sx1Z8HoLg48oOzi+9A==','af5453668af949178bb582d40022300a1f0327a84af97c844d551912a9ccac9e741ed408afd07037c2dc94794bd0093ceb641f4b526b2aad6307e9296e1cd016','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('52','2009-04-05031','dc8d2e085c3dd3b7586b10d7a5f8375a6b2113227d2b0babc8e4cadaee95d82f360be05dd78507632c2679bd214cdff13a58fb1d6ecceec0345c011cbff1e6b1','tRwXiBhuIrYksNmcwhZ91qijZVcZDCf77/ZE2M9usulKMpU2jgoWXHuLQB/eryE/G8B+TpQBt+aO3zSpFjAMRA==','f59e0629f9c33269de8bd9e0f253c2afe7aafb0cec9553a29d7f2bf1721f2b374ad642e9dab45064303faf42bd671c4fbef7cce9a7d5ac3dd0eb7c3d2bcd270b','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('53','2009-04-05052','d6dff0d59e47bde510d97342c015327501e13ffe41dff3d559410baf93876c1751dc5c1d6bef79c8ab76ccad9d4514d98500085224a109f338eb708f4de8c4d4','npZJkirFLDhAH0n0qAJgMQir7nKpRZDSCfAonFwvsUkEtyKf8XZskSgBRhk2o/3xhCqqOtSNOBrzdgpK2kFtJA==','38381bdb466d49756b1d90f5be02df218cdb52c4302be45fbad6999c05c8d4aee74f3e344361d33a89eab2fe55bd5a9c54e14a90e8a0e7d2f151ec59f295040f','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('54','2009-04-05160','0a2c1833436e981b7af2753228d0db4f8da673c7523b5b3e489ffc5d503a31919e7dfee9e3d9b757aebcc52d771f639ec8cde49f2d04c67c18003ed60675db46','uY6xikc6u0ZOGa1ROSJHTz1U3lwTvUQo/9qnbcTwEWsbbpFJbGykBlVlr6KGIJN8dRb5nTmGEvP15R8o9pUDww==','3df911a7218eb841c3761d6b26f2363cd8470b988e0d824e787addbb8b0782828672a6dbf5f29ab0c645c17ba4113022e1111a7fe091f0e65b0ce4651faa1183','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('55','2009-04-05259','c8ec39b4e93c1f617aa5153950a57136189155ddf6c5eda5d1df7f654c9df117243c7c640299b4bb457e5061a9ec3e8d671812ccdc057b2918b67b0f9d1f5b73','EQSBFbmuB+RIw0A9QPBPR2DN2PWYGxYNnLWjUjWZB+jY6X2wf+vZHr2csS5VzQPMmvB/8H8mjsVikPuo+8tlMQ==','7fbeb546ceac27c044c94c23afec87b2feb5b3ff8138f99186774404387607f2e18ba8a26f6315228f9736cfcb8606266b36f7cc8c663be795b036a299dda319','1361363196','0','0','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('56','2009-04-05865','a2989f6320999bab563260888ecda71af89bacb054581b450938ccd3afb5fbe0af9f63ab4fdb99da198f80c782f85361de5509b66f4b4250abb6a282f249c7cc','ibOCfY928FrASaInpgkr6kWb78xxWKpC1pMCjhkl6KUUdFxPK0hZgcdwsX8Z+a2tpm/IbD3h9jPqgm+uP/RPrQ==','ae7c564bf9c3f344a9b71b285d310bd64ef309dac608d4d7f96d70d6bbb9f6634ba87df56e035306b2bdb4c5f02f02fd31afb63a018c877e9afe051482b5565b','1361363196','1366866513','1366866804','1361363196','0','0','1','0','1','','Instant')~
INSERT INTO `user` (`id`,`username`,`password`,`salt`,`activationKey`,`createtime`,`lastvisit`,`lastaction`,`lastpasswordchange`,`failedloginattempts`,`superuser`,`student`,`staff`,`status`,`avatar`,`notifyType`) VALUES
('57','mwase','8426280373e43530b1c283a0e0809d8f415f490c1a8034e63f14fee383ca59ebbea266d2aef5f7647666230679acc03e8ba9b93e18b1221e5470895f538e35a4','bJCzx0myLdN2EnyD3hxo1NNBG3WaOwZPPuImwg/Ob4VSgV44my6CBaXGo9i6tzGKSCHvJS/RQ6O2TXfswD0v9g==','a53238818b3a8e7604353a73bfbd5e4352df59034f5f32fe356038e29f0f0182c51d7cf07feb00ca176414af3ed4feadaf6a4b6ba4deb4bd8a4f2af0428ff875','1366878371','1371711866','0','1366878371','0','0','0','1','1','','Instant')~



-- -------------------------------------------~
-- TABLE DATA user_role~
-- -------------------------------------------~
INSERT INTO `user_role` (`user_id`,`role_id`) VALUES
('1','1')~
INSERT INTO `user_role` (`user_id`,`role_id`) VALUES
('1','2')~
INSERT INTO `user_role` (`user_id`,`role_id`) VALUES
('2','4')~
INSERT INTO `user_role` (`user_id`,`role_id`) VALUES
('3','4')~



-- -------------------------------------------~
-- TABLE DATA usergroup~
-- -------------------------------------------~
INSERT INTO `usergroup` (`id`,`owner_id`,`participants`,`title`,`description`) VALUES
('1','3','[\"3\",\"2\",\"1\"]','Students','This is the group of all students')~
INSERT INTO `usergroup` (`id`,`owner_id`,`participants`,`title`,`description`) VALUES
('2','1','[\"32\",\"33\",\"34\",\"35\",\"36\",\"37\",\"38\",\"39\",\"40\",\"41\",\"42\",\"43\",\"44\",\"45\",\"46\",\"47\",\"48\",\"49\",\"50\",\"51\"]','admin','This is the group of administrators')~
INSERT INTO `usergroup` (`id`,`owner_id`,`participants`,`title`,`description`) VALUES
('3','1','[\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\"]','leo','Testing if it works..')~
INSERT INTO `usergroup` (`id`,`owner_id`,`participants`,`title`,`description`) VALUES
('4','1','[\"29\",\"30\",\"31\",\"3\",\"1\",\"2\"]','lala','Group la watu wanaopenda sana kulala mchana')~



-- -------------------------------------------~
-- TABLE DATA usergroup_role~
-- -------------------------------------------~
INSERT INTO `usergroup_role` (`usergroup_id`,`role_id`) VALUES
('1','6')~



-- -------------------------------------------~
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS~
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS~
-- -------------------------------------------~
-- -------------------------------------------~
-- END BACKUP~
-- -------------------------------------------~
